<?php

declare(strict_types=1);

use plugin\jackett\app\JackettPlugin;

/**
 * PHP 资源插件 manifest。
 *
 * 字段由核心注册表严格校验；class 只能来自部署者安装包，不能被 HTTP 请求覆盖。版本变化必须同步任务
 * 兼容说明和契约测试，不能让新实现静默消费语义未知的旧下载任务。
 */
return [
    'key' => 'jackett',
    'name' => 'Jackett + qBittorrent',
    'version' => '0.0.1',
    'protocolVersion' => 1,
    'capabilities' => ['admin_page_search', 'admin_page_download', 'admin_page_subscription', 'worker', 'transcode_worker', 'database_lifecycle'],
    'adminPage' => [
        'path' => '/admin/plugins/jackett',
        'title' => 'Jackett',
        'description' => '音乐资源搜索、PT 订阅与 qBittorrent 下载入库',
        'entry' => 'public/plugin-pages/jackett.html',
        'capability' => 'manage_system',
    ],
    'metadata' => [
        'introduction' => 'Jackett + qBittorrent 是一个音乐资源搜索与下载入库插件，通过 Jackett 聚合索引并由 qBittorrent 负责下载。',
        'author' => [
            'name' => 'Velin Music 开发团队',
            'url' => 'https://github.com/ttyob/velin-music-plugins',
        ],
        'usage' => [
            '在插件设置中配置 Jackett 地址和 API Key，并确认索引器可用。',
            '配置 qBittorrent 地址、账号和下载目录，先使用状态检查确认连接正常。',
            '搜索歌曲或专辑资源，核对资源来源、大小和格式后选择目标结果。',
            '在订阅区域配置 PT 关键词、质量、目标音乐库和检查间隔，启用后由 Worker 自动发现新种。',
            '自动任务沿用下载记录，完成后执行受控入库和扫描；保种时不要选择会移动源文件的策略。',
        ],
    ],
    'class' => JackettPlugin::class,
];
