<?php

declare(strict_types=1);

/**
 * Jackett 不再注册私有 Workerman 进程。
 *
 * 下载任务由核心 ResourcePluginWorker 动态发现 `worker` 钩子并单步消费；这使首次安装在下一轮自动
 * 启动，也保证注册表和业务数据库依赖首次创建于非协程 timer 上下文。保留空配置文件只为旧 Webman
 * 插件扫描兼容，不产生第二消费者，也不改变停机时的耐久任务状态。
 */
return [];
