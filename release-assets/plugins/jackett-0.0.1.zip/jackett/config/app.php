<?php

declare(strict_types=1);

/**
 * Jackett 插件总开关。
 *
 * 插件目录只有在后台完成 ZIP 校验、原子发布和数据库初始化后才会进入活动根。核心固定 API 与通用
 * Worker 支持首次安装热发现；这里仅保留旧 Webman 插件扫描兼容。停用、升级代际切换、卸载和删除由
 * 核心包管理器控制，插件自身不能根据请求或环境变量绕过生命周期。
 */
return ['enable' => is_file(dirname(__DIR__) . '/.velin-installed')
    && !is_link(dirname(__DIR__) . '/.velin-installed')];
