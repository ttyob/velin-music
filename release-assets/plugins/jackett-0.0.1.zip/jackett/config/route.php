<?php

declare(strict_types=1);

use app\middleware\VerifyCsrfToken;
use plugin\jackett\app\controller\Admin\JackettController;
use plugin\jackett\app\controller\Admin\QbittorrentController;
use Webman\Route;

/*
 * 这些旧地址仅兼容 1.0.1 页面和已打开的后台标签；1.0.2 页面使用核心固定的动态插件 API，因此首次
 * 安装无需重启注册路由。所有写入仍要求同源后台 Session、manage_system 与 CSRF，注册表逐请求复验
 * 安装标记和数据库版本；卸载开始后旧路由也立即失败关闭。
 */
if (!is_file(dirname(__DIR__) . '/.velin-installed') || is_link(dirname(__DIR__) . '/.velin-installed')) return;

/*
 * Webman 启动时可能通过核心配置扫描和动态插件目录两次发现同一活动包。旧兼容路由没有业务状态，使用
 * 进程内常量保证只注册一次；第二次加载直接返回，不影响核心动态插件 API，也不会跨进程隐藏路由。
 */
if (defined('VELIN_JACKETT_LEGACY_ROUTES_REGISTERED')) return;
define('VELIN_JACKETT_LEGACY_ROUTES_REGISTERED', true);

Route::get('/api/v1/admin/resource-search/jackett/status', [JackettController::class, 'status']);
Route::get('/api/v1/admin/resource-search/jackett/config', [JackettController::class, 'configuration']);
Route::put('/api/v1/admin/resource-search/jackett/config', [JackettController::class, 'updateConfiguration'])
    ->middleware(VerifyCsrfToken::class);
Route::post('/api/v1/admin/resource-search/jackett/search', [JackettController::class, 'search'])
    ->middleware(VerifyCsrfToken::class);
Route::get('/api/v1/admin/download-clients/qbittorrent/status', [QbittorrentController::class, 'status']);
Route::get('/api/v1/admin/download-clients/qbittorrent/config', [QbittorrentController::class, 'configuration']);
Route::put('/api/v1/admin/download-clients/qbittorrent/config', [QbittorrentController::class, 'updateConfiguration'])
    ->middleware(VerifyCsrfToken::class);
Route::get('/api/v1/admin/download-clients/qbittorrent/downloads/options', [QbittorrentController::class, 'downloadOptions']);
Route::post('/api/v1/admin/download-clients/qbittorrent/downloads', [QbittorrentController::class, 'createDownload'])
    ->middleware(VerifyCsrfToken::class);
Route::get('/api/v1/admin/download-clients/qbittorrent/jobs', [QbittorrentController::class, 'jobs']);
