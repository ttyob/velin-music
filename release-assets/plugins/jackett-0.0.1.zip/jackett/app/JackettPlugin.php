<?php

declare(strict_types=1);

namespace plugin\jackett\app;

use app\application\ResourcePlugin\Contract\ExternalDownloadHook;
use app\application\ResourcePlugin\Contract\TypedExternalMusicSearchHook;
use app\application\ResourcePlugin\Contract\AdminSubscriptionHook;
use app\application\ResourcePlugin\Contract\AdminSubscriptionDiagnosticsHook;
use app\application\ResourcePlugin\Contract\PluginWorkerHook;
use app\application\ResourcePlugin\Contract\PluginTranscodeWorkerHook;
use app\application\ResourcePlugin\Contract\PluginDatabaseLifecycle;
use app\application\ResourcePlugin\Contract\PluginDatabaseBaselineCollapse;
use plugin\jackett\app\application\DownloadClient\QbittorrentSettingsService;
use plugin\jackett\app\application\DownloadClient\QbittorrentStatusService;
use plugin\jackett\app\application\DownloadClient\ResourceDownloadJobService;
use plugin\jackett\app\application\DownloadClient\ResourceDownloadInvalid;
use plugin\jackett\app\application\DownloadClient\ResourceDownloadWorkerService;
use plugin\jackett\app\application\ResourceSearch\JackettSearchService;
use plugin\jackett\app\application\ResourceSearch\JackettSettingsService;
use plugin\jackett\app\application\Subscription\JackettSubscriptionService;
use support\Db;

/**
 * JackettPlugin 是 Jackett 0.0.1 基线包，装配搜索、PT 订阅、qBittorrent 下载及本地/远程受控入库。
 *
 * 插件沿用既有安全边界：Jackett 只产生 actor 绑定的加密租约，浏览器拿不到 torrent/磁力/URL；下载
 * 新任务只能进入固定 `/storage/downloads/jackett/downloads`，再发布到管理员可管理的本地或受支持
 * 远程库；旧路径只用于升级期历史任务前缀兼容。实现运行在 Webman 权限域中，必须
 * 作为部署者审查后的受信代码安装。显式卸载会删除插件任务、租约、配置和凭据密文；必须先停服执行
 * 卸载命令，再移除目录，不能把“直接删目录”误认为完成了数据清理。历史包版本已经折叠；以后升级以
 * 本类为唯一入口并继续依赖独立数据库版本账本，不需要保留旧 PHP 类才能升级既有数据库。
 */
final readonly class JackettPlugin implements TypedExternalMusicSearchHook, ExternalDownloadHook, AdminSubscriptionHook, AdminSubscriptionDiagnosticsHook, PluginWorkerHook, PluginTranscodeWorkerHook, PluginDatabaseBaselineCollapse
{
    public function descriptor(): array
    {
        return [
            'key' => 'jackett',
            'name' => 'Jackett + qBittorrent',
            'version' => '0.0.1',
            'capabilities' => ['admin_page_search', 'admin_page_download', 'admin_page_subscription', 'worker', 'transcode_worker', 'database_lifecycle'],
            'description' => '在 Jackett 插件页面搜索、订阅 PT 资源，并由 qBittorrent 下载后受控入库。',
        ];
    }

    public function probe(): array
    {
        $search = $this->searchStatus();
        $download = $this->downloadStatus();
        $available = ($search['available'] ?? false) === true && ($download['available'] ?? false) === true;
        return ['available' => $available, 'errorCode' => $available ? null
            : (is_string($search['errorCode'] ?? null) ? $search['errorCode'] : ($download['errorCode'] ?? 'PLUGIN_UNAVAILABLE'))];
    }

    public function searchStatus(): array
    {
        return (new JackettSearchService())->status();
    }

    public function searchConfiguration(): array
    {
        return (new JackettSettingsService())->snapshot();
    }

    public function updateSearchConfiguration(array $payload, array $actor, string $requestId): array
    {
        return (new JackettSettingsService())->update($payload, (string) $actor['id'], $requestId);
    }

    public function search(string $query, int $limit, string $actorId): array
    {
        return (new JackettSearchService())->search($query, $limit, $actorId);
    }

    /** Jackett 音乐分类可按管理员明确意图搜索单曲资源或专辑资源。 */
    public function searchTypes(): array { return ['track', 'album']; }

    /**
     * 把显式资源类型交给 Jackett 搜索服务。
     *
     * Torznab 音乐结果缺少可靠的曲目/专辑结构字段，因此类型来自本次搜索意图并固定写入租约投影，
     * 不根据发布标题猜测；未知类型在网络请求前拒绝。
     */
    public function searchTyped(string $resourceType, string $query, int $limit, string $actorId): array
    {
        return (new JackettSearchService())->search($query, $limit, $actorId, $resourceType);
    }

    public function downloadStatus(): array
    {
        return (new QbittorrentStatusService())->status();
    }

    public function downloadConfiguration(): array
    {
        return (new QbittorrentSettingsService())->snapshot();
    }

    public function updateDownloadConfiguration(array $payload, array $actor, string $requestId): array
    {
        return (new QbittorrentSettingsService())->update($payload, (string) $actor['id'], $requestId);
    }

    public function downloadOptions(array $actor): array
    {
        return (new ResourceDownloadJobService())->options($actor);
    }

    public function createDownload(array $command, array $actor, string $requestId): array
    {
        $keys = array_keys($command);
        sort($keys);
        if (!in_array($keys, [['leaseId', 'libraryId'], ['importMode', 'leaseId', 'libraryId']], true)
            || !is_string($command['leaseId'] ?? null) || !is_string($command['libraryId'] ?? null)
            || (isset($command['importMode']) && !is_string($command['importMode']))) {
            throw new ResourceDownloadInvalid();
        }
        return (new ResourceDownloadJobService())->create(
            $command['leaseId'], $command['libraryId'], $command['importMode'] ?? null, $actor, $requestId,
        );
    }

    public function downloadJobs(int $limit = 50): array
    {
        return (new ResourceDownloadJobService())->list($limit);
    }

    /** 返回管理员创建的 PT 订阅和目标音乐库选项；不返回任何上游资源引用。 */
    public function subscriptions(array $actor): array
    {
        return (new JackettSubscriptionService())->snapshot($actor);
    }

    /** 创建订阅规则；网络轮询由 Worker 在下一轮执行。 */
    public function createSubscription(array $payload, array $actor, string $requestId): array
    {
        return (new JackettSubscriptionService())->create($payload, $actor, $requestId);
    }

    /** 更新订阅规则；已经提交的下载任务继续使用创建时的配置快照。 */
    public function updateSubscription(string $subscriptionId, array $payload, array $actor, string $requestId): array
    {
        return (new JackettSubscriptionService())->update($subscriptionId, $payload, $actor, $requestId);
    }

    /** 删除规则和发现账本，不删除外部下载器任务或已发布媒体。 */
    public function deleteSubscription(string $subscriptionId, array $actor, string $requestId): array
    {
        return (new JackettSubscriptionService())->delete($subscriptionId, $actor, $requestId);
    }

    /** 标记立即检查，不在 HTTP 请求中访问 Jackett。 */
    public function runSubscription(string $subscriptionId, array $actor, string $requestId): array
    {
        return (new JackettSubscriptionService())->runNow($subscriptionId, $actor, $requestId);
    }

    public function subscriptionRuns(string $subscriptionId, array $actor, int $limit = 20): array
    {
        return (new JackettSubscriptionService())->runs($subscriptionId, $actor, $limit);
    }

    public function trialSubscription(string $subscriptionId, array $actor, string $requestId): array
    {
        return (new JackettSubscriptionService())->trial($subscriptionId, $actor, $requestId);
    }

    public function processNext(string $workerId): bool
    {
        $subscriptions = new JackettSubscriptionService();
        if ($subscriptions->processNext($workerId)) return true;
        return (new ResourceDownloadWorkerService())->processNext($workerId);
    }

    /** 将已完成下载交给独立发布/转码 Worker，避免 qBittorrent 轮询被 FFmpeg 阻塞。 */
    public function processTranscodeNext(string $workerId): bool
    {
        return (new ResourceDownloadWorkerService())->processTranscodeNext($workerId);
    }

    public function databaseVersion(): int { return 1; }

    /** 历史 1-3 账本均可由最终 Jackett schema 幂等接管；未知未来账本必须失败关闭。 */
    public function supportsLegacyDatabaseVersion(int $fromVersion): bool
    {
        return $fromVersion >= 0 && $fromVersion <= 3;
    }

    /**
     * 创建或接管 Jackett 插件数据库结构和默认设置。
     *
     * 旧 Velin 数据库可能已由核心基线创建两张资源表；此时只新增并回填 plugin_key，不改任务内容或
     * 密文。卸载后重装则完整创建表、索引和默认关闭配置。方法由核心 DDL 事务调用，不访问网络、下载器
     * 或文件系统；任何 SQL 失败会连同迁移账本一起回滚。
     */
    public function installDatabase(int $fromVersion): void
    {
        if (!$this->supportsLegacyDatabaseVersion($fromVersion)) {
            throw new \RuntimeException('JACKETT_DATABASE_VERSION_INVALID');
        }
        $this->createSearchLeases();
        $this->createDownloadJobs();
        $this->createSubscriptions();
        $this->createSubscriptionItems();
        $this->createSubscriptionRuns();
        $this->ensureColumn('jackett_subscription_runs', 'trial_mode', 'INTEGER NOT NULL DEFAULT 0');
        $this->ensureColumn('jackett_subscription_runs', 'filtered_count', 'INTEGER NOT NULL DEFAULT 0');
        $this->ensureColumn('jackett_subscription_runs', 'duplicate_count', 'INTEGER NOT NULL DEFAULT 0');
        $this->ensureColumn('jackett_subscription_runs', 'details_json', "TEXT NOT NULL DEFAULT '{}'");
        $this->ensurePluginColumn('resource_search_result_leases');
        $this->ensurePluginColumn('resource_download_jobs');
        $this->ensureColumn('resource_download_jobs', 'subscription_id', 'TEXT NULL');
        $this->ensureColumn('resource_download_jobs', 'subscription_item_id', 'TEXT NULL');
        // 版本 2 的订阅没有清理策略；升级时默认“不自动删除”，避免历史规则意外删除远端种子。
        // 新任务会在入队时把这三项复制到 resource_download_jobs，后续修改订阅不追溯已创建任务。
        $this->ensureColumn('jackett_subscriptions', 'cleanup_policy', "TEXT NOT NULL DEFAULT 'never'");
        $this->ensureColumn('jackett_subscriptions', 'cleanup_delay_hours', 'INTEGER NOT NULL DEFAULT 24');
        $this->ensureColumn('jackett_subscriptions', 'minimum_seed_time_hours', 'INTEGER NOT NULL DEFAULT 72');
        Db::connection()->statement('CREATE INDEX IF NOT EXISTS idx_resource_search_plugin_expiry ON resource_search_result_leases(plugin_key, expires_at)');
        Db::connection()->statement('CREATE INDEX IF NOT EXISTS idx_resource_download_plugin_queue ON resource_download_jobs(plugin_key, status, updated_at)');
        Db::connection()->statement('CREATE INDEX IF NOT EXISTS idx_jackett_subscriptions_due ON jackett_subscriptions(enabled, next_run_at)');
        Db::connection()->statement('CREATE INDEX IF NOT EXISTS idx_jackett_subscription_items_status ON jackett_subscription_items(subscription_id, status, updated_at)');
        Db::connection()->statement('CREATE INDEX IF NOT EXISTS idx_jackett_subscription_runs_created ON jackett_subscription_runs(subscription_id, started_at DESC)');
        $now = gmdate('Y-m-d\TH:i:s\Z');
        if (!Db::table('system_settings')->where('setting_key', 'integration.jackett')->exists()) {
            Db::table('system_settings')->insert(['setting_key' => 'integration.jackett',
                'value_json' => '{"enabled":false,"baseUrl":"","apiKeyCiphertext":null}',
                'version' => 1, 'updated_by' => null, 'updated_at' => $now]);
        }
        if (!Db::table('system_settings')->where('setting_key', 'integration.qbittorrent')->exists()) {
            Db::table('system_settings')->insert(['setting_key' => 'integration.qbittorrent',
                'value_json' => '{"enabled":false,"baseUrl":"","username":"","passwordCiphertext":null,"defaultImportMode":"copy","monitorMode":"qbittorrent_api","cleanupPolicy":"never","cleanupDelayHours":24,"minimumSeedTimeHours":72,"transcodeFormat":"opus","transcodeBitrateKbps":192}',
                'version' => 1, 'updated_by' => null, 'updated_at' => $now]);
        }
    }

    /**
     * 删除 Jackett 插件拥有的全部数据库状态。
     *
     * 下载任务先于搜索租约删除以满足外键 RESTRICT；设置行包含凭据密文并在同一事务删除，随后移除
     * 索引和表。用户、音乐库、扫描历史、已发布媒体和核心审计不属于插件所有权，不会删除。已提交到
     * 外部 qBittorrent 的任务无法由 SQLite 回滚，部署者必须在停服后自行核对远端残留。
     */
    public function uninstallDatabase(): void
    {
        Db::table('system_settings')->whereIn('setting_key', [
            'integration.jackett', 'integration.qbittorrent',
        ])->delete();
        Db::connection()->statement('DROP INDEX IF EXISTS idx_resource_download_plugin_queue');
        Db::connection()->statement('DROP INDEX IF EXISTS idx_resource_search_plugin_expiry');
        Db::connection()->statement('DROP INDEX IF EXISTS idx_jackett_subscription_runs_created');
        Db::connection()->statement('DROP INDEX IF EXISTS idx_jackett_subscription_items_status');
        Db::connection()->statement('DROP INDEX IF EXISTS idx_jackett_subscriptions_due');
        Db::connection()->statement('DROP TABLE IF EXISTS jackett_subscription_runs');
        Db::connection()->statement('DROP TABLE IF EXISTS jackett_subscription_items');
        Db::connection()->statement('DROP TABLE IF EXISTS jackett_subscriptions');
        Db::connection()->statement('DROP TABLE IF EXISTS resource_download_jobs');
        Db::connection()->statement('DROP TABLE IF EXISTS resource_search_result_leases');
    }

    /** 新库或卸载后重装时创建搜索租约表；已存在表保持原数据并由后续步骤升级。 */
    private function createSearchLeases(): void
    {
        Db::connection()->statement(<<<'SQL'
CREATE TABLE IF NOT EXISTS resource_search_result_leases (
    id TEXT PRIMARY KEY NOT NULL,
    plugin_key TEXT NOT NULL DEFAULT 'jackett' CHECK (length(plugin_key) BETWEEN 2 AND 48),
    actor_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    indexer TEXT NOT NULL,
    size_bytes INTEGER NULL CHECK (size_bytes IS NULL OR size_bytes >= 0),
    download_ref_ciphertext TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    created_at TEXT NOT NULL
)
SQL);
        Db::connection()->statement('CREATE INDEX IF NOT EXISTS idx_resource_search_leases_expiry ON resource_search_result_leases(expires_at)');
    }

    /**
     * 创建下载任务状态机表。
     *
     * schema 保留既有 qBittorrent、转码和清理字段，以便重装后继续使用相同协议；目标库与扫描任务仍由
     * 核心外键保护。表初始为空，默认值不能替代任务创建时固化的下载器配置快照。
     */
    private function createDownloadJobs(): void
    {
        Db::connection()->statement(<<<'SQL'
CREATE TABLE IF NOT EXISTS resource_download_jobs (
    id TEXT PRIMARY KEY NOT NULL,
    plugin_key TEXT NOT NULL DEFAULT 'jackett' CHECK (length(plugin_key) BETWEEN 2 AND 48),
    subscription_id TEXT NULL,
    subscription_item_id TEXT NULL,
    search_lease_id TEXT NOT NULL UNIQUE REFERENCES resource_search_result_leases(id) ON DELETE RESTRICT,
    requested_by TEXT NULL REFERENCES users(id) ON DELETE SET NULL,
    library_id TEXT NOT NULL REFERENCES music_libraries(id) ON DELETE RESTRICT,
    title TEXT NOT NULL,
    indexer TEXT NOT NULL,
    expected_size_bytes INTEGER NULL CHECK (expected_size_bytes IS NULL OR expected_size_bytes >= 0),
    import_mode TEXT NOT NULL CHECK (import_mode IN ('copy', 'move', 'hardlink', 'symlink', 'transcode')),
    transcode_keep_source INTEGER NOT NULL DEFAULT 0 CHECK (transcode_keep_source IN (0, 1)),
    monitor_mode TEXT NOT NULL DEFAULT 'qbittorrent_api' CHECK (monitor_mode = 'qbittorrent_api'),
    cleanup_policy TEXT NOT NULL DEFAULT 'never' CHECK (cleanup_policy IN ('never', 'after_import', 'after_delay', 'after_seeding')),
    cleanup_delay_hours INTEGER NOT NULL DEFAULT 24 CHECK (cleanup_delay_hours BETWEEN 1 AND 8760),
    minimum_seed_time_hours INTEGER NOT NULL DEFAULT 72 CHECK (minimum_seed_time_hours BETWEEN 1 AND 8760),
    cleanup_status TEXT NOT NULL DEFAULT 'not_required' CHECK (cleanup_status IN ('not_required', 'pending', 'waiting', 'processing', 'retrying', 'succeeded')),
    cleanup_due_at TEXT NULL,
    cleanup_attempt INTEGER NOT NULL DEFAULT 0 CHECK (cleanup_attempt >= 0),
    cleanup_error_code TEXT NULL,
    cleanup_finished_at TEXT NULL,
    status TEXT NOT NULL CHECK (status IN ('queued', 'submitting', 'downloading', 'importing', 'succeeded', 'failed')),
    download_ref_ciphertext TEXT NULL,
    torrent_hash_ciphertext TEXT NULL,
    progress_basis_points INTEGER NOT NULL DEFAULT 0 CHECK (progress_basis_points BETWEEN 0 AND 10000),
    downloaded_bytes INTEGER NOT NULL DEFAULT 0 CHECK (downloaded_bytes >= 0),
    total_bytes INTEGER NOT NULL DEFAULT 0 CHECK (total_bytes >= 0),
    speed_bytes_per_second INTEGER NOT NULL DEFAULT 0 CHECK (speed_bytes_per_second >= 0),
    eta_seconds INTEGER NULL CHECK (eta_seconds IS NULL OR eta_seconds >= 0),
    downloader_state TEXT NULL,
    imported_files INTEGER NOT NULL DEFAULT 0 CHECK (imported_files >= 0),
    scan_job_id TEXT NULL REFERENCES library_scan_jobs(id) ON DELETE SET NULL,
    error_code TEXT NULL,
    worker_id TEXT NULL,
    attempt INTEGER NOT NULL DEFAULT 0 CHECK (attempt >= 0),
    heartbeat_at TEXT NULL,
    started_at TEXT NULL,
    finished_at TEXT NULL,
    request_id TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    transcode_format TEXT NULL CHECK (transcode_format IS NULL OR transcode_format IN ('opus', 'aac', 'mp3', 'flac')),
    transcode_bitrate_kbps INTEGER NULL CHECK (transcode_bitrate_kbps IS NULL OR transcode_bitrate_kbps IN (96, 128, 160, 192, 256, 320))
)
SQL);
        Db::connection()->statement('CREATE INDEX IF NOT EXISTS idx_resource_download_jobs_cleanup ON resource_download_jobs(cleanup_status, cleanup_due_at)');
        Db::connection()->statement('CREATE INDEX IF NOT EXISTS idx_resource_download_jobs_created ON resource_download_jobs(created_at DESC)');
        Db::connection()->statement('CREATE INDEX IF NOT EXISTS idx_resource_download_jobs_library ON resource_download_jobs(library_id, created_at DESC)');
        Db::connection()->statement('CREATE INDEX IF NOT EXISTS idx_resource_download_jobs_queue ON resource_download_jobs(status, updated_at)');
    }

    /** 旧基线表缺少归属列时以固定 Jackett key 回填；ALTER 只在安装事务内执行一次。 */
    private function ensurePluginColumn(string $table): void
    {
        $columns = Db::connection()->select("PRAGMA table_info('{$table}')");
        foreach ($columns as $column) {
            if ((string) $column->name === 'plugin_key') return;
        }
        Db::connection()->statement("ALTER TABLE {$table} ADD COLUMN plugin_key TEXT NOT NULL DEFAULT 'jackett'");
    }

    /** 创建订阅规则表；规则只保存筛选和调度事实，不保存 PT URL 或账号秘密。 */
    private function createSubscriptions(): void
    {
        Db::connection()->statement(<<<'SQL'
CREATE TABLE IF NOT EXISTS jackett_subscriptions (
    id TEXT PRIMARY KEY NOT NULL,
    owner_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name TEXT NOT NULL CHECK (length(name) BETWEEN 1 AND 120),
    query TEXT NOT NULL CHECK (length(query) BETWEEN 2 AND 200),
    indexer TEXT NULL CHECK (indexer IS NULL OR length(indexer) BETWEEN 1 AND 120),
    quality_floor TEXT NOT NULL CHECK (quality_floor IN ('any', '128k', '320k', 'flac', 'flac24')),
    min_seeders INTEGER NULL CHECK (min_seeders IS NULL OR min_seeders BETWEEN 0 AND 1000000),
    max_size_bytes INTEGER NULL CHECK (max_size_bytes IS NULL OR max_size_bytes BETWEEN 1 AND 1099511627776),
    interval_minutes INTEGER NOT NULL CHECK (interval_minutes BETWEEN 5 AND 1440),
    max_items_per_run INTEGER NOT NULL CHECK (max_items_per_run BETWEEN 1 AND 20),
    library_id TEXT NOT NULL REFERENCES music_libraries(id) ON DELETE RESTRICT,
    import_mode TEXT NOT NULL CHECK (import_mode IN ('copy', 'move', 'hardlink', 'symlink', 'transcode')),
    cleanup_policy TEXT NOT NULL DEFAULT 'never' CHECK (cleanup_policy IN ('never', 'after_import', 'after_delay', 'after_seeding')),
    cleanup_delay_hours INTEGER NOT NULL DEFAULT 24 CHECK (cleanup_delay_hours BETWEEN 1 AND 8760),
    minimum_seed_time_hours INTEGER NOT NULL DEFAULT 72 CHECK (minimum_seed_time_hours BETWEEN 1 AND 8760),
    enabled INTEGER NOT NULL DEFAULT 1 CHECK (enabled IN (0, 1)),
    version INTEGER NOT NULL DEFAULT 1 CHECK (version >= 1),
    last_run_at TEXT NULL,
    next_run_at TEXT NOT NULL,
    last_error_code TEXT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
)
SQL);
    }

    /** 创建订阅发现去重账本；删除规则时只级联账本，不触碰下载任务和媒体。 */
    private function createSubscriptionItems(): void
    {
        Db::connection()->statement(<<<'SQL'
CREATE TABLE IF NOT EXISTS jackett_subscription_items (
    id TEXT PRIMARY KEY NOT NULL,
    subscription_id TEXT NOT NULL REFERENCES jackett_subscriptions(id) ON DELETE CASCADE,
    fingerprint TEXT NOT NULL,
    title TEXT NOT NULL,
    indexer TEXT NOT NULL,
    size_bytes INTEGER NULL CHECK (size_bytes IS NULL OR size_bytes >= 0),
    seeders INTEGER NULL CHECK (seeders IS NULL OR seeders >= 0),
    published_at TEXT NULL,
    status TEXT NOT NULL CHECK (status IN ('discovered', 'queued', 'downloading', 'importing', 'succeeded', 'failed', 'skipped')),
    job_id TEXT NULL,
    error_code TEXT NULL,
    discovered_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    UNIQUE (subscription_id, fingerprint)
)
SQL);
    }

    /** 保存每次轮询的脱敏计数和稳定错误码，禁止写入搜索词、URL 或上游正文。 */
    private function createSubscriptionRuns(): void
    {
        Db::connection()->statement(<<<'SQL'
CREATE TABLE IF NOT EXISTS jackett_subscription_runs (
    id TEXT PRIMARY KEY NOT NULL,
    subscription_id TEXT NOT NULL REFERENCES jackett_subscriptions(id) ON DELETE CASCADE,
    status TEXT NOT NULL CHECK (status IN ('running', 'succeeded', 'failed')),
    discovered_count INTEGER NOT NULL DEFAULT 0 CHECK (discovered_count >= 0),
    queued_count INTEGER NOT NULL DEFAULT 0 CHECK (queued_count >= 0),
    skipped_count INTEGER NOT NULL DEFAULT 0 CHECK (skipped_count >= 0),
    error_code TEXT NULL,
    started_at TEXT NOT NULL,
    finished_at TEXT NULL
)
SQL);
    }

    /** 旧版本升级时按固定 SQL 增加单个兼容列；不存在的列不会覆盖历史任务。 */
    private function ensureColumn(string $table, string $column, string $definition): void
    {
        $columns = Db::connection()->select("PRAGMA table_info('{$table}')");
        foreach ($columns as $current) {
            if ((string) $current->name === $column) return;
        }
        Db::connection()->statement("ALTER TABLE {$table} ADD COLUMN {$column} {$definition}");
    }
}
