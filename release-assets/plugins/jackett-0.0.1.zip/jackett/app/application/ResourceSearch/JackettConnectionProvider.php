<?php

declare(strict_types=1);

namespace plugin\jackett\app\application\ResourceSearch;

/**
 * 向只读搜索适配器提供经过持久化校验的 Jackett 连接。
 *
 * `snapshot()` 只返回后台可见的脱敏配置；`connection()` 才短暂返回明文 API Key，调用方负责清理。
 * 实现不得缓存明文、访问 tracker 或把连接写入任务。该边界也允许单元测试注入内存配置而不创建真实
 * 数据库或外部 Jackett。
 */
interface JackettConnectionProvider
{
    /** @return array{enabled:bool,baseUrl:string,configured:bool,version:int,updatedAt:string} */
    public function snapshot(): array;

    /** @return array{baseUrl:string,apiKey:string} */
    public function connection(): array;
}
