<?php

declare(strict_types=1);

namespace plugin\jackett\app\application\ResourceSearch;

use RuntimeException;

/**
 * 使用用途隔离的 Sodium secretbox 加密外部 Jackett API Key。
 *
 * 根密钥来自部署级 `VELIN_CREDENTIAL_KEY`，再通过 HKDF 派生 Jackett 专用子密钥，因此密文不能与
 * Subsonic、WebDAV 或其他集成互换。明文只允许在保存校验和一次 Jackett 请求调用栈中存在；不得进入
 * API、日志、审计、异常记录、缓存或任务。密文损坏、版本未知或密钥轮换后统一失败关闭。
 */
final readonly class JackettCredentialCipher
{
    private string $key;

    /** 测试可注入根密钥；生产使用至少 16 字节的独立部署密钥。 */
    public function __construct(?string $deploymentSecret = null)
    {
        $root = $deploymentSecret ?? getenv('VELIN_CREDENTIAL_KEY') ?: 'velin-development-credential-key-change-me';
        if (strlen($root) < 16) {
            throw new RuntimeException('VELIN_CREDENTIAL_KEY must contain at least 16 bytes.');
        }
        $this->key = hash_hkdf(
            'sha256',
            $root,
            SODIUM_CRYPTO_SECRETBOX_KEYBYTES,
            'velin-jackett-credentials-v1',
        );
    }

    /** 加密已经通过格式校验的 API Key；随机 nonce 保证相同 Key 不产生相同数据库值。 */
    public function encrypt(string $apiKey): string
    {
        if (preg_match('/^[A-Za-z0-9_-]{16,128}$/D', $apiKey) !== 1) {
            throw new RuntimeException('Jackett credential is outside the supported boundary.');
        }
        $nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        $ciphertext = sodium_crypto_secretbox($apiKey, $nonce, $this->key);

        return 'v1:' . base64_encode($nonce . $ciphertext);
    }

    /** 解密并认证 API Key；调用方必须在请求完成后尽快使用 `sodium_memzero()` 清理返回值。 */
    public function decrypt(?string $payload): string
    {
        if (!is_string($payload) || !str_starts_with($payload, 'v1:')) {
            throw new RuntimeException('Jackett credential is unavailable.');
        }
        $decoded = base64_decode(substr($payload, 3), true);
        if (!is_string($decoded) || strlen($decoded) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES) {
            throw new RuntimeException('Jackett credential is unavailable.');
        }
        $plaintext = sodium_crypto_secretbox_open(
            substr($decoded, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES),
            substr($decoded, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES),
            $this->key,
        );
        if (!is_string($plaintext) || preg_match('/^[A-Za-z0-9_-]{16,128}$/D', $plaintext) !== 1) {
            throw new RuntimeException('Jackett credential is unavailable.');
        }

        return $plaintext;
    }
}
