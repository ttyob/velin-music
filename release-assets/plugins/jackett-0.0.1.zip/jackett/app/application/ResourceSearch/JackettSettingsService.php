<?php

declare(strict_types=1);

namespace plugin\jackett\app\application\ResourceSearch;

use app\infrastructure\Audit\AuditLogger;
use JsonException;
use RuntimeException;
use stdClass;
use support\Db;

/**
 * 管理外部 Jackett 的全局连接设置。
 *
 * 地址和启停状态保存在版本化 `system_settings` 对象，API Key 使用 Jackett 专用 secretbox 密文。读取
 * 只向后台投影地址和 `configured` 布尔值；更新使用单行 CAS 与同事务脱敏审计，旧表单不会覆盖另一
 * 管理员修改。服务不安装、启动或配置 Jackett，也不在数据库事务中访问网络。
 */
final readonly class JackettSettingsService implements JackettConnectionProvider
{
    private const KEY = 'integration.jackett';

    public function __construct(
        private JackettCredentialCipher $cipher = new JackettCredentialCipher(),
        private AuditLogger $audit = new AuditLogger(),
    ) {
    }

    /**
     * 返回后台表单所需的脱敏配置快照。
     *
     * 缺行、损坏 JSON、非法 URL 或异常密文字段表示迁移/数据故障并失败关闭；方法不会解密 API Key，
     * 也没有网络、文件或写库副作用。
     *
     * @return array{enabled:bool,baseUrl:string,configured:bool,version:int,updatedAt:string}
     */
    public function snapshot(): array
    {
        $setting = $this->setting();

        return [
            'enabled' => $setting['enabled'],
            'baseUrl' => $setting['baseUrl'],
            'configured' => is_string($setting['apiKeyCiphertext']) && $setting['apiKeyCiphertext'] !== '',
            'version' => $setting['version'],
            'updatedAt' => $setting['updatedAt'],
        ];
    }

    /**
     * 为一次状态探测或搜索解密连接。
     *
     * 调用前配置必须启用且地址、密文完整；返回的明文 Key 只能立即交给 Jackett 客户端，并由调用方在
     * finally 中清理。解密失败不包含密文、URL 或底层 Sodium 消息。
     *
     * @return array{baseUrl:string,apiKey:string}
     */
    public function connection(): array
    {
        $setting = $this->setting();
        if (!$setting['enabled'] || $setting['baseUrl'] === '' || !is_string($setting['apiKeyCiphertext'])) {
            throw new JackettSettingsUnavailable();
        }
        try {
            $apiKey = $this->cipher->decrypt($setting['apiKeyCiphertext']);
        } catch (RuntimeException) {
            throw new JackettSettingsUnavailable();
        }

        return ['baseUrl' => $setting['baseUrl'], 'apiKey' => $apiKey];
    }

    /**
     * 原子保存启停、外部地址和可选的新 API Key。
     *
     * `apiKey` 省略时保留旧密文；显式空字符串只允许在关闭连接时清除。启用状态要求地址和有效 Key
     * 同时存在。URL 允许管理员明确配置 HTTP/HTTPS 的局域网或公网 Jackett，并支持反向代理子路径，
     * 但拒绝凭据、查询、片段、点段和控制字符。审计只记录布尔变化，不保存地址或 Key。
     *
     * @return array{enabled:bool,baseUrl:string,configured:bool,version:int,updatedAt:string}
     */
    public function update(array $command, string $actorId, string $requestId): array
    {
        return Db::transaction(function () use ($command, $actorId, $requestId): array {
            $before = $this->setting();
            $allowed = ['enabled', 'baseUrl', 'expectedVersion', 'apiKey'];
            $requiredCount = array_key_exists('apiKey', $command) ? 4 : 3;
            if (array_is_list($command) || array_diff(array_keys($command), $allowed) !== []
                || count($command) !== $requiredCount || !is_bool($command['enabled'] ?? null)
                || !is_string($command['baseUrl'] ?? null) || !is_int($command['expectedVersion'] ?? null)) {
                throw new JackettSettingsInvalid();
            }
            if ($command['expectedVersion'] !== $before['version']) {
                throw new JackettSettingsConflict();
            }

            $baseUrl = $this->normalizeBaseUrl($command['baseUrl'], $command['enabled']);
            $ciphertext = $before['apiKeyCiphertext'];
            if (array_key_exists('apiKey', $command)) {
                if (!is_string($command['apiKey'])) {
                    throw new JackettSettingsInvalid();
                }
                $apiKey = trim($command['apiKey']);
                if ($apiKey === '') {
                    $ciphertext = null;
                } elseif (preg_match('/^[A-Za-z0-9_-]{16,128}$/D', $apiKey) !== 1) {
                    throw new JackettSettingsInvalid();
                } else {
                    $ciphertext = $this->cipher->encrypt($apiKey);
                    sodium_memzero($apiKey);
                }
            }
            if ($command['enabled'] && ($baseUrl === '' || !is_string($ciphertext))) {
                throw new JackettSettingsInvalid();
            }

            $value = ['enabled' => $command['enabled'], 'baseUrl' => $baseUrl, 'apiKeyCiphertext' => $ciphertext];
            $changed = Db::table('system_settings')->where('setting_key', self::KEY)
                ->where('version', $command['expectedVersion'])->update([
                    'value_json' => json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR),
                    'version' => Db::raw('version + 1'),
                    'updated_by' => $actorId,
                    'updated_at' => gmdate('Y-m-d\TH:i:s\Z'),
                ]);
            if ($changed !== 1) {
                throw new JackettSettingsConflict();
            }
            $this->audit->record(
                $actorId,
                'integration.jackett.update',
                'system_setting',
                self::KEY,
                'success',
                $requestId,
                [
                    'enabled' => $command['enabled'],
                    'configured' => is_string($ciphertext),
                    'url_changed' => $baseUrl !== $before['baseUrl'],
                    'credential_replaced' => array_key_exists('apiKey', $command),
                    'version' => $command['expectedVersion'] + 1,
                ],
            );

            return $this->snapshot();
        });
    }

    /** @return array{enabled:bool,baseUrl:string,apiKeyCiphertext:?string,version:int,updatedAt:string} */
    private function setting(): array
    {
        $row = Db::table('system_settings')->where('setting_key', self::KEY)->first();
        if (!$row instanceof stdClass) {
            throw new JackettSettingsUnavailable();
        }
        try {
            $value = json_decode((string) $row->value_json, true, 8, JSON_THROW_ON_ERROR);
        } catch (JsonException) {
            throw new JackettSettingsUnavailable();
        }
        if (!is_array($value) || array_is_list($value)
            || array_diff(array_keys($value), ['enabled', 'baseUrl', 'apiKeyCiphertext']) !== []
            || count($value) !== 3 || !is_bool($value['enabled'] ?? null)
            || !is_string($value['baseUrl'] ?? null)
            || (!is_null($value['apiKeyCiphertext'] ?? null) && !is_string($value['apiKeyCiphertext']))) {
            throw new JackettSettingsUnavailable();
        }
        try {
            $baseUrl = $this->normalizeBaseUrl($value['baseUrl'], $value['enabled']);
        } catch (JackettSettingsInvalid) {
            throw new JackettSettingsUnavailable();
        }

        return [
            'enabled' => $value['enabled'],
            'baseUrl' => $baseUrl,
            'apiKeyCiphertext' => $value['apiKeyCiphertext'],
            'version' => (int) $row->version,
            'updatedAt' => (string) $row->updated_at,
        ];
    }

    /** 校验并规范化外部 Jackett 根地址；关闭时允许空地址以清除配置。 */
    private function normalizeBaseUrl(string $input, bool $enabled): string
    {
        $url = rtrim(trim($input), '/');
        if ($url === '') {
            if ($enabled) {
                throw new JackettSettingsInvalid();
            }
            return '';
        }
        if (strlen($url) > 2048 || preg_match('/[\x00-\x20\x7F]/', $url) === 1) {
            throw new JackettSettingsInvalid();
        }
        $parts = parse_url($url);
        if (!is_array($parts)) {
            throw new JackettSettingsInvalid();
        }
        $path = (string) ($parts['path'] ?? '');
        $decodedPath = rawurldecode($path);
        if (!in_array($parts['scheme'] ?? null, ['http', 'https'], true)
            || !is_string($parts['host'] ?? null) || $parts['host'] === ''
            || isset($parts['user']) || isset($parts['pass']) || isset($parts['query']) || isset($parts['fragment'])
            || (isset($parts['port']) && ((int) $parts['port'] < 1 || (int) $parts['port'] > 65535))
            || preg_match('~(^|/)(?:\.|\.\.)(?:/|$)~', $decodedPath) === 1) {
            throw new JackettSettingsInvalid();
        }

        return $url;
    }
}

/** 外部 Jackett 设置请求字段、URL 或密钥不符合固定契约。 */
final class JackettSettingsInvalid extends \RuntimeException {}

/** 外部 Jackett 设置的 expectedVersion 已过期。 */
final class JackettSettingsConflict extends \RuntimeException {}

/** 外部 Jackett 设置缺失、损坏或无法解密。 */
final class JackettSettingsUnavailable extends \RuntimeException {}
