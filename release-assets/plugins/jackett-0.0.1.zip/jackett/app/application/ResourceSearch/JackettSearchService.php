<?php

declare(strict_types=1);

namespace plugin\jackett\app\application\ResourceSearch;

use plugin\jackett\app\application\DownloadClient\ResourceDownloadCipher;
use DOMDocument;
use DOMElement;
use DOMXPath;
use GuzzleHttp\Client;
use GuzzleHttp\ClientInterface;
use JsonException;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\StreamInterface;
use Throwable;
use Symfony\Component\Uid\Ulid;
use support\Db;

/**
 * 通过管理员配置的外部 Jackett 执行只读 Torznab 音乐资源搜索。
 *
 * Jackett 地址和加密 API Key 来自版本化系统设置；本服务只在一次请求调用栈中解密 Key，禁止把明文
 * 写入响应、审计或日志。查询仅向浏览器返回经过白名单投影的展示事实；可获取资源的字段会加密为
 * 15 分钟、绑定当前管理员的服务端租约，浏览器只能获得不可反查的随机 ID。租约不触发下载或文件
 * 副作用，过期后无法创建任务。
 *
 * 上游请求关闭重定向并设置连接、总时长和响应体上限。外部根地址在保存和调用边界重复校验，只能
 * 使用无凭据、无查询或片段的 HTTP(S) URL；XML 使用 LIBXML_NONET 解析并限制条目数量。任何网络、
 * 认证、配置或协议错误都转换为稳定领域错误，原始 URI（含 apikey）、响应正文和第三方异常消息不会
 * 向外传播。
 */
final readonly class JackettSearchService
{
    private const MAX_RESPONSE_BYTES = 2_097_152;

    public function __construct(
        private ?ClientInterface $http = null,
        private JackettConnectionProvider $connections = new JackettSettingsService(),
        private ResourceDownloadCipher $downloadCipher = new ResourceDownloadCipher(),
    ) {
    }

    /**
     * 返回不含秘密的 Jackett 配置与可用性快照。
     *
     * 状态读取是尽力而为的只读探测：配置尚未生成时返回 `configured=false`；配置存在但 sidecar 暂时
     * 不可达时返回稳定 errorCode。该方法自身不抛出预期的集成故障，避免 Jackett 启动顺序阻断整个系统
     * 设置页面；成功只证明当前 caps 请求可用，不承诺后续站点查询一定成功。
     *
     * @return array{bundled:false,enabled:bool,baseUrl:string,configured:bool,available:bool,downloadEnabled:true,version:int,updatedAt:string,errorCode:?string}
     */
    public function status(): array
    {
        try {
            $settings = $this->connections->snapshot();
        } catch (JackettSettingsUnavailable) {
            // 配置行缺失或部署密钥尚未注入时仍返回稳定状态，不能让插件探测异常冒泡成页面 503。
            return ['bundled' => false, 'enabled' => false, 'baseUrl' => '', 'configured' => false,
                'available' => false, 'downloadEnabled' => true, 'version' => 0, 'updatedAt' => '',
                'errorCode' => 'JACKETT_NOT_CONFIGURED'];
        }
        if (!$settings['enabled']) {
            return $this->statusProjection($settings, false, 'JACKETT_DISABLED');
        }
        if (!$settings['configured']) {
            return $this->statusProjection($settings, false, 'JACKETT_NOT_CONFIGURED');
        }

        try {
            $connection = $this->connections->connection();
        } catch (JackettSettingsUnavailable) {
            return $this->statusProjection($settings, false, 'JACKETT_NOT_CONFIGURED');
        }
        $apiKey = $connection['apiKey'];
        try {
            $response = $this->request($connection['baseUrl'], ['t' => 'caps', 'apikey' => $apiKey]);
            $xml = $this->responseXml($response);
            $document = $this->xml($xml);
            if ($document->documentElement?->localName !== 'caps') {
                throw new JackettUnavailable('JACKETT_PROTOCOL_INVALID');
            }

            return $this->statusProjection($settings, true, null);
        } catch (JackettUnavailable $failure) {
            return $this->statusProjection($settings, false, $failure->errorCode);
        } finally {
            sodium_memzero($apiKey);
        }
    }

    /**
     * 读取 Jackett 当前已配置且可用的索引器清单。
     *
     * Jackett 的 `all/results/torznab/api` 只返回搜索结果，不能用于生成订阅表单的索引器选项；
     * 本方法使用只读 `/api/v2.0/indexers` 管理接口获取名称和稳定 ID。返回值只保留展示和筛选所需
     * 的两个字段，不把站点地址、账号、Cookie、API Key 或完整配置回传给后台页面。上游不可用、认证
     * 失败或响应结构异常时抛出稳定错误码，由订阅快照降级为空清单，不影响已有订阅规则继续运行。
     *
     * @return list<array{id:string,name:string}> 按 Jackett 返回顺序去重的已配置索引器
     * @throws JackettNotConfigured 配置未启用或缺少 API Key
     * @throws JackettUnavailable 上游网络、认证或 JSON 协议失败
     */
    public function indexers(): array
    {
        $connection = $this->connections->connection();
        $apiKey = $connection['apiKey'];
        try {
            $response = $this->request(
                $connection['baseUrl'],
                ['apikey' => $apiKey, 'configured' => 'true'],
                '/api/v2.0/indexers',
                'application/json',
            );
            $payload = json_decode($this->responseBody($response), true, 8, JSON_THROW_ON_ERROR);
            if (!is_array($payload) || !array_is_list($payload)) {
                throw new JackettUnavailable('JACKETT_INDEXERS_PROTOCOL_INVALID');
            }

            $result = [];
            $seen = [];
            foreach ($payload as $entry) {
                if (!is_array($entry)) continue;
                if (array_key_exists('configured', $entry) && $entry['configured'] !== true) continue;
                $id = $this->safeText((string) ($entry['id'] ?? ''), 120);
                $name = $this->safeText((string) ($entry['name'] ?? $entry['title'] ?? ''), 120);
                if ($id === '' || $name === '') continue;
                $identity = strtolower($id);
                if (isset($seen[$identity])) continue;
                $seen[$identity] = true;
                $result[] = ['id' => $id, 'name' => $name];
                if (count($result) >= 100) break;
            }

            return $result;
        } catch (JsonException) {
            throw new JackettUnavailable('JACKETT_INDEXERS_PROTOCOL_INVALID');
        } finally {
            sodium_memzero($apiKey);
        }
    }

    /**
     * 搜索当前 Jackett 已配置 indexer 的音乐分类并返回有界脱敏结果。
     *
     * query 必须是 2-200 个 UTF-8 字符，limit 为 1-50；POST Controller 在进入本方法前已完成
     * `manage_system` 与 CSRF 校验，本方法仍重复业务边界以保护未来调用方。所有 indexer 由管理员在
     * Jackett 内自行授权配置，Velin 不接收站点账号、Cookie 或 Passkey。成功无持久化副作用，失败不会
     * 返回部分结果，也不会把查询或秘密写入异常。
     *
     * @return array{query:string,resourceType:string,total:int,limited:bool,items:list<array{id:string,resourceType:string,title:string,indexer:string,sizeBytes:?int,seeders:?int,leechers:?int,publishedAt:?string,downloadable:bool}>}
     */
    public function search(
        string $query,
        int $limit = 30,
        ?string $actorId = null,
        string $resourceType = 'track',
    ): array
    {
        $query = trim($query);
        if ($query === '' || !mb_check_encoding($query, 'UTF-8')
            || mb_strlen($query, 'UTF-8') < 2 || mb_strlen($query, 'UTF-8') > 200
            || preg_match('/[\x00-\x1F\x7F]/u', $query) === 1 || $limit < 1 || $limit > 50
            || !in_array($resourceType, ['track', 'album'], true)) {
            throw new JackettSearchInvalid();
        }

        $settings = $this->connections->snapshot();
        if (!$settings['enabled'] || !$settings['configured']) {
            throw new JackettNotConfigured();
        }
        $connection = $this->connections->connection();
        $apiKey = $connection['apiKey'];
        try {
            $response = $this->request($connection['baseUrl'], [
                't' => 'search',
                'apikey' => $apiKey,
                'q' => $query,
                'cat' => '3000',
                'limit' => (string) $limit,
            ]);
            $items = $this->leaseResults(
                $this->parseResults($this->responseXml($response), $limit),
                $actorId,
                $resourceType,
            );

            return [
                'query' => $query,
                'resourceType' => $resourceType,
                'total' => count($items),
                'limited' => count($items) === $limit,
                'items' => $items,
            ];
        } finally {
            sodium_memzero($apiKey);
        }
    }

    /**
     * 为后台订阅执行一次内部搜索，并保留仅供插件 Worker 使用的下载引用。
     *
     * 本方法不接受 actor，也不创建浏览器租约；调用者必须在后续同一轮事务中把引用加密进下载任务。
     * 返回值永远不会离开 Jackett 插件边界，订阅日志只能保存计数和稳定错误码。查询、响应大小、XML
     * 禁网解析和 URL 校验与普通搜索完全一致，避免 Worker 形成更宽的外部请求器。
     *
     * @return list<array{id:string,fingerprint:string,title:string,indexer:string,sizeBytes:?int,seeders:?int,leechers:?int,publishedAt:?string,downloadReference:?string}>
     */
    public function searchForSubscription(string $query, int $limit = 50): array
    {
        $query = trim($query);
        if ($query === '' || !mb_check_encoding($query, 'UTF-8')
            || mb_strlen($query, 'UTF-8') < 2 || mb_strlen($query, 'UTF-8') > 200
            || preg_match('/[\x00-\x1F\x7F]/u', $query) === 1 || $limit < 1 || $limit > 100) {
            throw new JackettSearchInvalid();
        }
        $settings = $this->connections->snapshot();
        if (!$settings['enabled'] || !$settings['configured']) throw new JackettNotConfigured();
        $connection = $this->connections->connection();
        $apiKey = $connection['apiKey'];
        try {
            $response = $this->request($connection['baseUrl'], [
                't' => 'search', 'apikey' => $apiKey, 'q' => $query, 'cat' => '3000', 'limit' => (string) $limit,
            ]);
            return $this->parseResults($this->responseXml($response), $limit);
        } finally {
            sodium_memzero($apiKey);
        }
    }

    /**
     * @param array{enabled:bool,baseUrl:string,configured:bool,version:int,updatedAt:string} $settings
     * @return array{bundled:false,enabled:bool,baseUrl:string,configured:bool,available:bool,downloadEnabled:true,version:int,updatedAt:string,errorCode:?string}
     */
    private function statusProjection(array $settings, bool $available, ?string $errorCode): array
    {
        return [
            'bundled' => false,
            'enabled' => $settings['enabled'],
            'baseUrl' => $settings['baseUrl'],
            'configured' => $settings['configured'],
            'available' => $available,
            'downloadEnabled' => true,
            'version' => $settings['version'],
            'updatedAt' => $settings['updatedAt'],
            'errorCode' => $errorCode,
        ];
    }

    /**
     * 向固定回环 Torznab 端点发出一个受约束 GET。
     *
     * query 仅由本类固定键和已校验搜索词组成；Guzzle 异常可能含完整 URI，因此全部在这里截断为不携带
     * previous 的稳定错误。401/403 单独归类为 API Key 失效，其他非 200、重定向或网络错误均不可用。
     *
     * @param array<string,string> $query
     */
    private function request(
        string $baseUrl,
        array $query,
        string $path = '/api/v2.0/indexers/all/results/torznab/api',
        string $accept = 'application/xml, text/xml;q=0.9',
    ): ResponseInterface
    {
        $baseUrl = $this->validatedBaseUrl($baseUrl);
        try {
            $response = ($this->http ?? new Client(['http_errors' => false]))->request(
                'GET',
                $baseUrl . $path,
                [
                    'query' => $query,
                    'allow_redirects' => false,
                    'connect_timeout' => 2.0,
                    'timeout' => 15.0,
                    'stream' => true,
                    'proxy' => '',
                    'headers' => ['Accept' => $accept],
                ],
            );
        } catch (Throwable) {
            throw new JackettUnavailable('JACKETT_CONNECTION_FAILED');
        }
        if (in_array($response->getStatusCode(), [401, 403], true)) {
            throw new JackettUnavailable('JACKETT_AUTH_FAILED');
        }
        if ($response->getStatusCode() !== 200) {
            throw new JackettUnavailable('JACKETT_UPSTREAM_FAILED');
        }

        return $response;
    }

    /** 重复校验持久化外部地址，防止损坏数据库把本适配器变成任意 URL 请求器。 */
    private function validatedBaseUrl(string $value): string
    {
        $value = rtrim(trim($value), '/');
        $parts = parse_url($value);
        if (!is_array($parts)) {
            throw new JackettUnavailable('JACKETT_CONFIG_INVALID');
        }
        $path = rawurldecode((string) ($parts['path'] ?? ''));
        if (strlen($value) > 2048 || preg_match('/[\x00-\x20\x7F]/', $value) === 1
            || !in_array($parts['scheme'] ?? null, ['http', 'https'], true)
            || !is_string($parts['host'] ?? null) || $parts['host'] === ''
            || isset($parts['user']) || isset($parts['pass']) || isset($parts['query']) || isset($parts['fragment'])
            || (isset($parts['port']) && ((int) $parts['port'] < 1 || (int) $parts['port'] > 65535))
            || preg_match('~(^|/)(?:\.|\.\.)(?:/|$)~', $path) === 1) {
            throw new JackettUnavailable('JACKETT_CONFIG_INVALID');
        }

        return $value;
    }

    /**
     * 从 PSR-7 流有界读取 XML，禁止 Content-Length 或分块正文绕过 2 MiB 上限。
     *
     * Guzzle 的正常 HTTP 流是阻塞流；若上游适配器在尚未 EOF 时返回空块，继续循环既无法取得进展，
     * 也可能永久占用 Webman Worker，因此立即按损坏响应失败。失败前不会解析或记录已读取的部分正文。
     */
    private function responseBody(ResponseInterface $response): string
    {
        $length = trim($response->getHeaderLine('Content-Length'));
        if ($length !== '' && preg_match('/^\d+$/D', $length) === 1 && (int) $length > self::MAX_RESPONSE_BYTES) {
            throw new JackettUnavailable('JACKETT_RESPONSE_TOO_LARGE');
        }
        $stream = $response->getBody();
        $body = '';
        while (!$stream->eof() && strlen($body) <= self::MAX_RESPONSE_BYTES) {
            $chunk = $this->readChunk($stream, min(65_536, self::MAX_RESPONSE_BYTES + 1 - strlen($body)));
            if ($chunk === '') {
                throw new JackettUnavailable('JACKETT_RESPONSE_INVALID');
            }
            $body .= $chunk;
        }
        if ($body === '' || strlen($body) > self::MAX_RESPONSE_BYTES) {
            throw new JackettUnavailable('JACKETT_RESPONSE_INVALID');
        }

        return $body;
    }

    /** 读取并校验有界 XML 响应；XML 解析器仍在调用方使用 LIBXML_NONET。 */
    private function responseXml(ResponseInterface $response): string
    {
        return $this->responseBody($response);
    }

    private function readChunk(StreamInterface $stream, int $length): string
    {
        try {
            return $stream->read(max(1, $length));
        } catch (Throwable) {
            throw new JackettUnavailable('JACKETT_RESPONSE_INVALID');
        }
    }

    /** 使用禁网 XML 解析器读取 Torznab，不解析外部实体或容忍损坏文档。 */
    private function xml(string $xml): DOMDocument
    {
        $document = new DOMDocument();
        $previous = libxml_use_internal_errors(true);
        try {
            if (!$document->loadXML($xml, LIBXML_NONET | LIBXML_NOBLANKS | LIBXML_COMPACT)) {
                throw new JackettUnavailable('JACKETT_PROTOCOL_INVALID');
            }
        } finally {
            libxml_clear_errors();
            libxml_use_internal_errors($previous);
        }

        return $document;
    }

    /**
     * 把 Torznab item 裁剪成允许浏览器查看的固定字段。
     *
     * 获取字段只形成内部 `downloadReference`，随后必须加密为 actor 绑定租约；该字段绝不能直接进入
     * Controller 响应。优先使用 magneturl，其次 link、enclosure、HTTP(S) guid，最后把规范 infohash
     * 组装为磁力引用。损坏条目被跳过；有效条目按上游顺序最多返回 limit 个。
     *
     * @return list<array{id:string,fingerprint:string,title:string,indexer:string,sizeBytes:?int,seeders:?int,leechers:?int,publishedAt:?string,downloadReference:?string}>
     */
    private function parseResults(string $xml, int $limit): array
    {
        $document = $this->xml($xml);
        $xpath = new DOMXPath($document);
        $nodes = $xpath->query('/*[local-name()="rss"]/*[local-name()="channel"]/*[local-name()="item"]');
        if ($nodes === false) throw new JackettUnavailable('JACKETT_PROTOCOL_INVALID');
        $items = [];
        foreach ($nodes as $node) {
            if (!$node instanceof DOMElement || count($items) >= $limit) break;
            $title = $this->safeText((string) $xpath->evaluate('string(./*[local-name()="title"][1])', $node), 500);
            $indexer = $this->safeText((string) $xpath->evaluate(
                'string(./*[local-name()="jackettindexer"][1])', $node,
            ), 120);
            $attrs = [];
            $attributeNodes = $xpath->query('./*[local-name()="attr"]', $node);
            if ($attributeNodes !== false) {
                foreach ($attributeNodes as $attribute) {
                    if (!$attribute instanceof DOMElement) continue;
                    $name = strtolower($attribute->getAttribute('name'));
                    if (in_array($name, ['size', 'seeders', 'peers', 'leechers', 'magneturl', 'infohash', 'indexer', 'source', 'tracker'], true)) {
                        $attrs[$name] = $attribute->getAttribute('value');
                    }
                }
            }
            // Jackett 版本和索引器配置不同，索引器名称可能位于专用节点、Torznab attr 或 source 节点；
            // 统一读取展示文本，绝不把节点 URL、ID 或其它上游扩展字段写入租约和订阅账本。
            if ($indexer === '') {
                foreach (['indexer', 'source', 'tracker'] as $candidate) {
                    $indexer = $this->safeText((string) ($attrs[$candidate] ?? ''), 120);
                    if ($indexer !== '') break;
                }
            }
            if ($indexer === '') {
                $indexer = $this->safeText((string) $xpath->evaluate(
                    'string(./*[local-name()="source"][1])', $node,
                ), 120);
            }
            if ($title === '' || $indexer === '') continue;
            $sizeText = $attrs['size'] ?? (string) $xpath->evaluate('string(./*[local-name()="size"][1])', $node);
            $publishedText = trim((string) $xpath->evaluate('string(./*[local-name()="pubDate"][1])', $node));
            $timestamp = $publishedText === '' ? false : strtotime($publishedText);
            $seeders = $this->nonNegativeInteger($attrs['seeders'] ?? null);
            $leechers = $this->nonNegativeInteger($attrs['leechers'] ?? null);
            if ($leechers === null && isset($attrs['peers'])) {
                $peers = $this->nonNegativeInteger($attrs['peers']);
                $leechers = $peers === null || $seeders === null ? null : max(0, $peers - $seeders);
            }
            $size = $this->nonNegativeInteger($sizeText);
            $downloadReference = $this->downloadReference($xpath, $node, $attrs);
            // 下载 URL 可能包含每次轮询都会变化的签名或 passkey，绝不能作为资源身份。InfoHash 是
            // 跨索引器、跨订阅的强身份；缺少 InfoHash 时才退回标题/大小/发布时间等有界展示事实，
            // 这样同一颗种子不会因为镜像索引器名称不同而再次进入下载队列。
            $identity = $this->torrentIdentity($attrs['infohash'] ?? null, $attrs['magneturl'] ?? null);
            $publishedIdentity = $timestamp === false ? $publishedText : (string) $timestamp;
            $fingerprint = $identity !== ''
                ? hash('sha256', "torrent\0" . $identity)
                : hash('sha256', "metadata\0" . $title . "\0" . ($size ?? '') . "\0" . $publishedIdentity);
            $items[] = [
                'id' => substr($fingerprint, 0, 32),
                'fingerprint' => $fingerprint,
                'title' => $title,
                'indexer' => $indexer,
                'sizeBytes' => $size,
                'seeders' => $seeders,
                'leechers' => $leechers,
                'publishedAt' => $timestamp === false ? null : gmdate('Y-m-d\TH:i:s\Z', $timestamp),
                'downloadReference' => $downloadReference,
            ];
        }

        return $items;
    }

    /**
     * 把内部下载引用变成短期随机租约并删除明文字段。
     *
     * actorId 只能来自已通过后台 Session 校验的 Controller。租约批量写入一个短事务，网络请求早已结束；
     * 任一密文或写入失败会让整次搜索失败，不返回不可消费的半批结果。过期租约按有界批次顺手清理，
     * 被下载任务引用的历史租约因外键 RESTRICT 保留用于审计。actorId 为空只用于旧单元测试调用，此时
     * 结果明确标记不可下载，不创建匿名租约。
     *
     * @param list<array<string,mixed>> $items
     * @return list<array<string,mixed>>
     */
    private function leaseResults(array $items, ?string $actorId, string $resourceType): array
    {
        if ($actorId === null) {
            return array_map(static function (array $item) use ($resourceType): array {
                unset($item['downloadReference']);
                unset($item['fingerprint']);
                $item['downloadable'] = false;
                $item['resourceType'] = $resourceType;
                return $item;
            }, $items);
        }
        $now = gmdate('Y-m-d\TH:i:s\Z');
        $expiresAt = gmdate('Y-m-d\TH:i:s\Z', time() + 900);
        if (is_string($actorId) && preg_match('/^[0-9A-HJKMNP-TV-Z]{26}$/D', $actorId) !== 1) {
            throw new JackettSearchInvalid();
        }

        return Db::transaction(function () use ($items, $actorId, $resourceType, $now, $expiresAt): array {
            $expiredIds = Db::table('resource_search_result_leases')->where('plugin_key', 'jackett')
                ->where('expires_at', '<', $now)
                ->whereNotExists(function ($query): void {
                    $query->selectRaw('1')->from('resource_download_jobs')
                        ->whereColumn('resource_download_jobs.search_lease_id', 'resource_search_result_leases.id');
                })->limit(100)->pluck('id')->all();
            if ($expiredIds !== []) Db::table('resource_search_result_leases')->whereIn('id', $expiredIds)->delete();

            $projected = [];
            foreach ($items as $item) {
                $reference = $item['downloadReference'] ?? null;
                unset($item['downloadReference']);
                // 指纹只供插件 Worker 去重，不能随普通搜索结果进入浏览器 DTO。
                unset($item['fingerprint']);
                $item['downloadable'] = is_string($reference) && is_string($actorId);
                $item['resourceType'] = $resourceType;
                if (!$item['downloadable']) {
                    $projected[] = $item;
                    continue;
                }
                $leaseId = (string) new Ulid();
                Db::table('resource_search_result_leases')->insert([
                    'id' => $leaseId,
                    'plugin_key' => 'jackett',
                    'actor_id' => $actorId,
                    'title' => $item['title'],
                    'indexer' => $item['indexer'],
                    'size_bytes' => $item['sizeBytes'],
                    'download_ref_ciphertext' => $this->downloadCipher->encrypt('reference', $reference),
                    'expires_at' => $expiresAt,
                    'created_at' => $now,
                ]);
                $item['id'] = $leaseId;
                $projected[] = $item;
            }
            return $projected;
        });
    }

    /** 只接受无控制字符的 HTTP(S) 或 magnet 引用；其他 guid 文本永不持久化。 */
    private function downloadReference(DOMXPath $xpath, DOMElement $node, array $attrs): ?string
    {
        $candidates = [
            $attrs['magneturl'] ?? null,
            (string) $xpath->evaluate('string(./*[local-name()="link"][1])', $node),
            (string) $xpath->evaluate('string(./*[local-name()="enclosure"][1]/@url)', $node),
            (string) $xpath->evaluate('string(./*[local-name()="guid"][1])', $node),
        ];
        if (is_string($attrs['infohash'] ?? null) && preg_match('/^[A-Fa-f0-9]{40}$/D', $attrs['infohash']) === 1) {
            $candidates[] = 'magnet:?xt=urn:btih:' . strtolower($attrs['infohash']);
        }
        foreach ($candidates as $candidate) {
            if (!is_string($candidate)) continue;
            $candidate = trim($candidate);
            if ($candidate === '' || strlen($candidate) > 8192 || preg_match('/[\x00-\x20\x7F]/', $candidate) === 1) continue;
            $scheme = strtolower((string) parse_url($candidate, PHP_URL_SCHEME));
            if (in_array($scheme, ['http', 'https', 'magnet'], true)) return $candidate;
        }
        return null;
    }

    /**
     * 提取规范化的 BTIH 身份，供订阅去重使用。
     *
     * 前置条件：输入只来自 Torznab 的 infohash/magneturl 属性；函数不访问网络、不保存原始链接，也
     * 不把 passkey、tracker 或其它磁力参数纳入身份。十六进制和 Base32 BTIH 都保留其规范小写形式，
     * 无法证明为 BTIH 时返回空字符串，由调用方使用保守的展示事实回退指纹。该身份只进入 SHA-256
     * 指纹，不会返回浏览器或日志。
     */
    private function torrentIdentity(?string $infoHash, ?string $magnetUrl): string
    {
        foreach ([$infoHash, $magnetUrl] as $candidate) {
            if (!is_string($candidate)) continue;
            $candidate = trim($candidate);
            if (preg_match('/^(?:[a-f0-9]{40}|[a-z2-7]{32})$/i', $candidate) === 1) {
                return 'btih:' . strtolower($candidate);
            }
            if (preg_match('/(?:^|[?&])xt=urn:btih:([^&]+)/i', $candidate, $match) === 1
                && preg_match('/^(?:[a-f0-9]{40}|[a-z2-7]{32})$/i', $match[1]) === 1) {
                return 'btih:' . strtolower($match[1]);
            }
        }

        return '';
    }

    private function safeText(string $value, int $maxCharacters): string
    {
        $value = trim($value);
        if ($value === '' || !mb_check_encoding($value, 'UTF-8') || preg_match('/[\x00-\x1F\x7F]/u', $value) === 1) {
            return '';
        }

        return mb_substr($value, 0, $maxCharacters, 'UTF-8');
    }

    private function nonNegativeInteger(?string $value): ?int
    {
        if (!is_string($value) || preg_match('/^\d+$/D', $value) !== 1) return null;
        $number = filter_var($value, FILTER_VALIDATE_INT, ['options' => ['min_range' => 0]]);
        return is_int($number) ? $number : null;
    }
}

/** 搜索词或数量不符合固定协议边界。 */
final class JackettSearchInvalid extends \RuntimeException {}

/** Jackett 未启用或外部连接配置不完整。 */
final class JackettNotConfigured extends \RuntimeException {}

/** Jackett 网络、认证或 Torznab 协议暂时不可用；错误码不含 URI、查询和第三方正文。 */
final class JackettUnavailable extends \RuntimeException
{
    public function __construct(public readonly string $errorCode)
    {
        parent::__construct($errorCode);
    }
}
