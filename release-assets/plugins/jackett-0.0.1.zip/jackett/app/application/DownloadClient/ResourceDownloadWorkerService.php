<?php

declare(strict_types=1);

namespace plugin\jackett\app\application\DownloadClient;

use app\application\Scan\ScanJobService;
use app\application\System\SystemLimitSettingsService;
use app\application\Transcode\TranscodeAdmission;
use app\application\Transcode\TranscodeCapacityExceeded;
use app\infrastructure\Audit\AuditLogger;
use RuntimeException;
use stdClass;
use support\Db;
use Throwable;

/**
 * 驱动资源下载的提交、qBittorrent API 进度同步和完成后入库状态机。
 *
 * SQLite 阶段由单 Worker 调用。数据库只在领取/状态转换的短事务中写入，登录下载器、暂停 torrent、
 * 文件复制/移动/链接/转码和 realpath 校验全部在事务外。queued 提交可由任务标签幂等重试；downloading 只
 * 信任 qBittorrent API 的 progress/state/content_path，不扫描下载目录猜测完成。账号、权限或音乐库
 * 状态在入库前撤销会失败关闭，不让历史任务绕过实时文件写权限。成功入库后的自动清理是独立耐久状态，
 * 失败只延时重试，绝不把已公布媒体或 succeeded 主状态回退。
 */
final readonly class ResourceDownloadWorkerService
{
    public function __construct(
        private QbittorrentGateway $downloader = new QbittorrentApiClient(),
        private ResourceDownloadCipher $cipher = new ResourceDownloadCipher(),
        private ResourceDownloadImportService $importer = new ResourceDownloadImportService(),
        private ScanJobService $scans = new ScanJobService(),
        private AuditLogger $audit = new AuditLogger(),
        private TranscodeAdmission $transcodeAdmission = new TranscodeAdmission(),
        private SystemLimitSettingsService $limits = new SystemLimitSettingsService(),
    ) {
    }

    /** 处理一个最久未更新的活动下载或到期清理；返回 false 表示当前没有可执行工作。 */
    public function processNext(string $workerId): bool
    {
        $this->recoverStaleTasks();
        $now = gmdate('Y-m-d\TH:i:s\Z');
        /** @var stdClass|null $row */
        $row = Db::table('resource_download_jobs')->where('plugin_key', 'jackett')
            ->where(function ($query) use ($now): void {
            $query->whereIn('status', ['queued', 'submitting', 'downloading'])
                ->orWhere(function ($cleanup) use ($now): void {
                    $cleanup->where('status', 'succeeded')
                        ->whereIn('cleanup_status', ['pending', 'waiting', 'processing', 'retrying'])
                        ->whereNotNull('cleanup_due_at')->where('cleanup_due_at', '<=', $now);
                });
        })->orderByRaw("CASE status WHEN 'queued' THEN 0 WHEN 'submitting' THEN 1 WHEN 'downloading' THEN 2 ELSE 3 END")
            ->orderBy('updated_at')->first();
        if (!$row instanceof stdClass) return false;
        try {
            if ($row->status === 'succeeded') $this->cleanup($row, $workerId);
            elseif ($row->status === 'queued' || $row->status === 'submitting') $this->submit($row, $workerId);
            else $this->synchronize($row, $workerId);
        } catch (QbittorrentUnavailable $failure) {
            if ($row->status === 'succeeded') $this->retryCleanup((string) $row->id, $failure->errorCode);
            else $this->retryOrFail((string) $row->id, (string) $row->status, $failure->errorCode, $workerId);
        } catch (ResourceDownloadImportFailed $failure) {
            $this->fail((string) $row->id, $failure->errorCode);
        } catch (TranscodeCapacityExceeded $failure) {
            $this->deferImport((string) $row->id, $failure->getMessage());
        } catch (Throwable) {
            if ($row->status === 'succeeded') $this->retryCleanup((string) $row->id, 'DOWNLOAD_CLEANUP_FAILED');
            else $this->fail((string) $row->id, 'DOWNLOAD_WORKER_FAILED');
        }
        return true;
    }

    /**
     * 在独立媒体 Worker 中领取并发布一条已完成下载。
     *
     * importing 是下载轮询和发布 Worker 之间的持久边界；本方法先用 worker_id/heartbeat 的 CAS 领取，
     * 再在事务外读取 qBittorrent 内容和执行复制、转码、FFprobe。只有发布完成后才把任务写成 succeeded，
     * 因而多个进程同时扫描队列时最多一个进程会产生文件副作用。
     */
    public function processTranscodeNext(string $workerId): bool
    {
        $this->recoverStaleTasks(true);
        /** @var stdClass|null $row */
        $row = Db::table('resource_download_jobs')->where('plugin_key', 'jackett')
            ->where('status', 'importing')->whereNull('worker_id')->orderBy('updated_at')->first();
        if (!$row instanceof stdClass) return false;
        $now = gmdate('Y-m-d\TH:i:s\Z');
        $claimed = Db::table('resource_download_jobs')->where('id', (string) $row->id)
            ->where('status', 'importing')->whereNull('worker_id')
            ->update(['worker_id' => $workerId, 'heartbeat_at' => $now, 'updated_at' => $now]);
        if ($claimed !== 1) return false;
        try {
            $task = $this->downloader->task((string) $row->id);
            if ($task === null) throw new ResourceDownloadImportFailed('QBITTORRENT_TASK_NOT_FOUND');
            $this->assertLiveAuthorization((string) $row->requested_by, (string) $row->library_id);
            if ($row->import_mode === 'move') $this->downloader->pause($task['hash']);
            $transcodeLease = null;
            try {
                if ($row->import_mode === 'transcode') {
                    $transcodeLease = $this->transcodeAdmission->acquire(
                        (int) $this->limits->get()['maxConcurrentTranscodes'],
                    );
                }
                $count = $this->importer->publish(
                    (string) $row->id, (string) $row->library_id, (string) $row->title, $task['contentPath'],
                    (string) $row->import_mode, $row->transcode_format === null ? null : (string) $row->transcode_format,
                    $row->transcode_bitrate_kbps === null ? null : (int) $row->transcode_bitrate_kbps,
                );
            } finally {
                $transcodeLease?->release();
            }
            $scanState = $this->scans->queueAutomaticJob((string) $row->library_id, 'download_import');
            $scanJobId = $scanState === 'queued' ? Db::table('library_scan_jobs')
                ->where('library_id', (string) $row->library_id)->where('status', 'queued')
                ->orderByDesc('created_at')->value('id') : null;
            $finishedAt = gmdate('Y-m-d\TH:i:s\Z');
            $cleanupDueAt = $this->cleanupDueAt((string) $row->cleanup_policy, (int) $row->cleanup_delay_hours, $finishedAt);
            Db::transaction(function () use ($row, $count, $scanJobId, $finishedAt, $cleanupDueAt): void {
                $changed = Db::table('resource_download_jobs')->where('id', (string) $row->id)->where('status', 'importing')->update([
                    'status' => 'succeeded', 'progress_basis_points' => 10_000, 'speed_bytes_per_second' => 0,
                    'eta_seconds' => 0, 'imported_files' => $count, 'scan_job_id' => $scanJobId,
                    'worker_id' => null, 'heartbeat_at' => null, 'error_code' => null,
                    'cleanup_due_at' => $cleanupDueAt, 'finished_at' => $finishedAt, 'updated_at' => $finishedAt,
                ]);
                if ($changed !== 1) throw new RuntimeException('download state changed');
                $this->syncSubscriptionItem((string) $row->id, 'succeeded');
                $this->audit->record((string) $row->requested_by, 'resource.download.complete', 'resource_download_job',
                    (string) $row->id, 'success', (string) $row->request_id,
                    ['libraryId' => (string) $row->library_id, 'importMode' => (string) $row->import_mode, 'importedFiles' => $count]);
            });
        } catch (TranscodeCapacityExceeded $failure) {
            $this->deferImport((string) $row->id, $failure->getMessage());
        } catch (ResourceDownloadImportFailed $failure) {
            $this->fail((string) $row->id, $failure->errorCode);
        } catch (QbittorrentUnavailable $failure) {
            $this->fail((string) $row->id, $failure->errorCode);
        } catch (Throwable) {
            $this->fail((string) $row->id, 'DOWNLOAD_IMPORT_FAILED');
        }
        return true;
    }

    /** 回收失联的提交/下载/入库任务；已 succeeded 的清理任务由独立清理状态机继续处理。 */
    private function recoverStaleTasks(bool $includeImporting = false): void
    {
        // 入库可能包含多首音频和 FFmpeg，允许较长的无心跳窗口，避免长转码被第二个进程误判为崩溃。
        $cutoff = gmdate('Y-m-d\TH:i:s\Z', time() - 1800);
        $rows = Db::table('resource_download_jobs')->where('plugin_key', 'jackett')
            ->whereIn('status', $includeImporting ? ['submitting', 'downloading', 'importing'] : ['submitting', 'downloading'])->whereNotNull('heartbeat_at')
            ->where('heartbeat_at', '<', $cutoff)->limit(20)->get(['id', 'status', 'attempt'])->all();
        foreach ($rows as $row) {
            $now = gmdate('Y-m-d\TH:i:s\Z');
            if ((string) $row->status === 'importing') {
                Db::table('resource_download_jobs')->where('plugin_key', 'jackett')->where('id', (string) $row->id)
                    ->where('status', 'importing')->where('heartbeat_at', '<', $cutoff)->update([
                        'worker_id' => null, 'heartbeat_at' => null,
                        'error_code' => 'DOWNLOAD_IMPORT_WORKER_STALE_RECOVERED', 'updated_at' => $now,
                    ]);
                continue;
            }
            $retry = (int) $row->attempt < 3;
            Db::table('resource_download_jobs')->where('plugin_key', 'jackett')->where('id', (string) $row->id)
                ->where('status', (string) $row->status)->where('heartbeat_at', '<', $cutoff)->update($retry ? [
                    'status' => 'queued', 'worker_id' => null, 'heartbeat_at' => null,
                    'error_code' => 'DOWNLOAD_WORKER_STALE_RECOVERED', 'updated_at' => $now,
                ] : [
                    'status' => 'failed', 'worker_id' => null, 'heartbeat_at' => null,
                    'error_code' => 'DOWNLOAD_WORKER_STALE', 'finished_at' => $now, 'updated_at' => $now,
                ]);
        }
    }

    /**
     * 在短事务中领取提交权，然后解密引用并调用幂等标签提交。
     *
     * Worker 若在外部成功后、数据库更新前退出，下一次 submit 会先按相同标签找到既有 torrent，因而
     * 不重复下载。引用使用完立即清理；进入 downloading 后清空任务密文，缩短秘密保留周期。
     */
    private function submit(stdClass $row, string $workerId): void
    {
        $now = gmdate('Y-m-d\TH:i:s\Z');
        if ($row->status === 'queued') {
            $changed = Db::table('resource_download_jobs')->where('id', (string) $row->id)->where('status', 'queued')->update([
                'status' => 'submitting', 'worker_id' => $workerId, 'attempt' => Db::raw('attempt + 1'),
                'heartbeat_at' => $now, 'started_at' => $row->started_at ?? $now, 'error_code' => null, 'updated_at' => $now,
            ]);
            if ($changed !== 1) return;
        }
        $reference = $this->cipher->decrypt('reference', (string) $row->download_ref_ciphertext);
        try {
            $this->downloader->submit($reference, (string) $row->id);
        } finally {
            sodium_memzero($reference);
        }
        Db::table('resource_download_jobs')->where('id', (string) $row->id)->where('status', 'submitting')->update([
            'status' => 'downloading', 'download_ref_ciphertext' => null, 'worker_id' => null,
            'heartbeat_at' => null, 'error_code' => null, 'updated_at' => gmdate('Y-m-d\TH:i:s\Z'),
        ]);
    }

    /** 同步一条 qBittorrent 事实；完成后先持久化 importing，再执行文件副作用。 */
    private function synchronize(stdClass $row, string $workerId): void
    {
        $task = $this->downloader->task((string) $row->id);
        if ($task === null) {
            $this->retryOrFail((string) $row->id, 'downloading', 'QBITTORRENT_TASK_NOT_FOUND', $workerId);
            return;
        }
        $now = gmdate('Y-m-d\TH:i:s\Z');
        $basisPoints = max(0, min(10_000, (int) round($task['progress'] * 10_000)));
        $terminalError = in_array(strtolower($task['state']), ['error', 'missingfiles', 'unknown'], true);
        if ($terminalError) {
            $this->fail((string) $row->id, 'QBITTORRENT_TASK_FAILED');
            return;
        }
        $complete = $basisPoints === 10_000;
        Db::table('resource_download_jobs')->where('id', (string) $row->id)
            ->whereIn('status', ['downloading', 'importing'])->update([
            'status' => $complete ? 'importing' : 'downloading', 'progress_basis_points' => $basisPoints,
            'downloaded_bytes' => $task['downloaded'], 'total_bytes' => $task['total'],
            'speed_bytes_per_second' => $task['speed'], 'eta_seconds' => $task['eta'],
            'downloader_state' => $task['state'], 'torrent_hash_ciphertext' => $this->cipher->encrypt('hash', $task['hash']),
            // importing 交给独立 Worker，下载轮询不保留租约，避免新 Worker 被旧 worker_id 阻塞。
            'worker_id' => null, 'heartbeat_at' => null,
            'attempt' => 0, 'error_code' => null, 'updated_at' => $now,
        ]);
        if ($complete) $this->syncSubscriptionItem((string) $row->id, 'importing');
    }

    /**
     * 执行一条成功任务的自动清理，不改变主任务成功事实。
     *
     * 清理前把任务置为 processing 并设置五分钟崩溃恢复时间，随后在事务外读取 qBittorrent 事实。做种
     * 时间不足时只推进 due_at；满足条件后解密任务保存的 hash，并由 Gateway 在同一会话再次复验标签、
     * 固定分类和精确 hash 后删除 torrent 及数据。外部对象已不存在按幂等成功。任何异常只进入重试，
     * 已入库目录、扫描任务与 succeeded 状态都不回滚。
     */
    private function cleanup(stdClass $row, string $workerId): void
    {
        $now = gmdate('Y-m-d\TH:i:s\Z');
        $recoveryAt = gmdate('Y-m-d\TH:i:s\Z', time() + 300);
        $changed = Db::table('resource_download_jobs')->where('id', (string) $row->id)
            ->where('status', 'succeeded')->whereIn('cleanup_status', ['pending', 'waiting', 'processing', 'retrying'])->update([
                'cleanup_status' => 'processing', 'cleanup_attempt' => Db::raw('cleanup_attempt + 1'),
                'cleanup_due_at' => $recoveryAt, 'cleanup_error_code' => null,
                'worker_id' => $workerId, 'heartbeat_at' => $now, 'updated_at' => $now,
            ]);
        if ($changed !== 1) return;

        $task = $this->downloader->task((string) $row->id);
        if ($task !== null && $row->cleanup_policy === 'after_seeding') {
            $required = (int) $row->minimum_seed_time_hours * 3600;
            if ($task['seedingTimeSeconds'] < $required) {
                $remaining = max(60, $required - $task['seedingTimeSeconds']);
                Db::table('resource_download_jobs')->where('id', (string) $row->id)
                    ->where('cleanup_status', 'processing')->update([
                        'cleanup_status' => 'waiting',
                        'cleanup_due_at' => gmdate('Y-m-d\TH:i:s\Z', time() + min(300, $remaining)),
                        'worker_id' => null, 'heartbeat_at' => null, 'updated_at' => gmdate('Y-m-d\TH:i:s\Z'),
                    ]);
                return;
            }
        }
        if ($task !== null) {
            $expectedHash = $this->cipher->decrypt('hash', (string) $row->torrent_hash_ciphertext);
            try {
                if (!hash_equals($expectedHash, $task['hash'])) {
                    throw new QbittorrentUnavailable('QBITTORRENT_TASK_MISMATCH');
                }
                $this->downloader->remove((string) $row->id, $expectedHash);
            } finally {
                sodium_memzero($expectedHash);
            }
        }
        $completedAt = gmdate('Y-m-d\TH:i:s\Z');
        Db::transaction(function () use ($row, $completedAt): void {
            $updated = Db::table('resource_download_jobs')->where('id', (string) $row->id)
                ->where('status', 'succeeded')->where('cleanup_status', 'processing')->update([
                    'cleanup_status' => 'succeeded', 'cleanup_due_at' => null, 'cleanup_error_code' => null,
                    'cleanup_finished_at' => $completedAt, 'worker_id' => null, 'heartbeat_at' => null,
                    'updated_at' => $completedAt,
                ]);
            if ($updated !== 1) throw new RuntimeException('download cleanup state changed');
            $this->audit->record($row->requested_by === null ? null : (string) $row->requested_by,
                'resource.download.cleanup', 'resource_download_job', (string) $row->id, 'success',
                (string) $row->request_id, ['cleanupPolicy' => (string) $row->cleanup_policy]);
        });
    }

    /** 按任务快照生成首次清理时间；never 在创建时已经收口为 not_required，因此返回 null。 */
    private function cleanupDueAt(string $policy, int $delayHours, string $finishedAt): ?string
    {
        return match ($policy) {
            'after_import', 'after_seeding' => $finishedAt,
            'after_delay' => gmdate('Y-m-d\TH:i:s\Z', strtotime($finishedAt) + ($delayHours * 3600)),
            default => null,
        };
    }

    /** 清理永不终止失败；使用上限一小时的指数退避等待下载器恢复。 */
    private function retryCleanup(string $jobId, string $errorCode): void
    {
        /** @var stdClass|null $job */
        $job = Db::table('resource_download_jobs')->where('id', $jobId)->first(['cleanup_attempt']);
        if (!$job instanceof stdClass) return;
        $delay = min(3600, 30 * (2 ** min(7, (int) $job->cleanup_attempt)));
        Db::table('resource_download_jobs')->where('id', $jobId)->where('status', 'succeeded')
            ->where('cleanup_status', 'processing')->update([
                'cleanup_status' => 'retrying', 'cleanup_due_at' => gmdate('Y-m-d\TH:i:s\Z', time() + $delay),
                'cleanup_error_code' => $errorCode, 'worker_id' => null, 'heartbeat_at' => null,
                'updated_at' => gmdate('Y-m-d\TH:i:s\Z'),
            ]);
    }

    /** 全局 FFmpeg 槽暂时占满时保留 importing 事实，稍后重新取得槽并幂等恢复，不把容量竞争记为任务失败。 */
    private function deferImport(string $jobId, string $errorCode): void
    {
        Db::table('resource_download_jobs')->where('id', $jobId)->where('status', 'importing')->update([
            'worker_id' => null, 'heartbeat_at' => null, 'error_code' => $errorCode,
            'updated_at' => gmdate('Y-m-d\TH:i:s\Z'),
        ]);
    }

    /** 实时复验账号、系统管理能力和目标库管理授权；撤权后的旧任务不能落盘。 */
    private function assertLiveAuthorization(string $userId, string $libraryId): void
    {
        /** @var stdClass|null $user */
        $user = Db::table('users')->where('id', $userId)->where('status', 'active')->whereNull('deleted_at')
            ->first(['id', 'is_super_admin']);
        if (!$user instanceof stdClass) throw new ResourceDownloadImportFailed('DOWNLOAD_AUTHORIZATION_REVOKED');
        $library = Db::table('music_libraries')->where('id', $libraryId)->where('status', 'active')
            ->whereIn('source_type', ['local', 'webdav', 'onedrive', 'google_drive'])->exists();
        if (!$library) throw new ResourceDownloadImportFailed('DOWNLOAD_LIBRARY_UNAVAILABLE');
        if ((int) $user->is_super_admin === 1) return;
        $system = Db::table('user_roles')->join('role_capabilities', 'role_capabilities.role_id', '=', 'user_roles.role_id')
            ->where('user_roles.user_id', $userId)->where('role_capabilities.capability_key', 'manage_system')->exists();
        $grant = Db::table('library_user_grants')->where('user_id', $userId)->where('library_id', $libraryId)
            ->where('access_level', 'manage')->exists();
        if (!$system || !$grant) throw new ResourceDownloadImportFailed('DOWNLOAD_AUTHORIZATION_REVOKED');
    }

    /** 提交错误最多重试五次；下载轮询错误保留任务并持续恢复，不把短暂离线变成不可逆失败。 */
    private function retryOrFail(string $jobId, string $status, string $errorCode, string $workerId): void
    {
        /** @var stdClass|null $job */
        $job = Db::table('resource_download_jobs')->where('id', $jobId)->first(['attempt']);
        if (!$job instanceof stdClass) return;
        $submitting = in_array($status, ['queued', 'submitting'], true);
        if ($submitting && (int) $job->attempt >= 5) {
            $this->fail($jobId, $errorCode);
            return;
        }
        Db::table('resource_download_jobs')->where('id', $jobId)->whereIn('status', ['submitting', 'downloading'])->update([
            'status' => $submitting ? 'queued' : 'downloading', 'attempt' => Db::raw('attempt + 1'),
            'worker_id' => null, 'heartbeat_at' => null, 'error_code' => $errorCode,
            'updated_at' => gmdate('Y-m-d\TH:i:s\Z'),
        ]);
    }

    private function fail(string $jobId, string $errorCode): void
    {
        $now = gmdate('Y-m-d\TH:i:s\Z');
        Db::table('resource_download_jobs')->where('id', $jobId)
            ->whereIn('status', ['queued', 'submitting', 'downloading', 'importing'])->update([
                'status' => 'failed', 'speed_bytes_per_second' => 0, 'eta_seconds' => null,
                'worker_id' => null, 'heartbeat_at' => null, 'error_code' => $errorCode,
                'finished_at' => $now, 'updated_at' => $now,
            ]);
        $this->syncSubscriptionItem($jobId, 'failed', $errorCode);
    }

    /** 同步订阅发现账本的脱敏状态；旧版本未安装订阅表时保持下载 Worker 兼容。 */
    private function syncSubscriptionItem(string $jobId, string $status, ?string $errorCode = null): void
    {
        if (!Db::connection()->getSchemaBuilder()->hasTable('jackett_subscription_items')) return;
        $itemId = Db::table('resource_download_jobs')->where('id', $jobId)->value('subscription_item_id');
        if (!is_string($itemId) || $itemId === '') return;
        Db::table('jackett_subscription_items')->where('id', $itemId)->update([
            'status' => $status, 'error_code' => $errorCode, 'updated_at' => gmdate('Y-m-d\TH:i:s\Z'),
        ]);
    }
}
