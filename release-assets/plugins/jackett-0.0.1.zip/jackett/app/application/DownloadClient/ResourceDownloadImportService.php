<?php

declare(strict_types=1);

namespace plugin\jackett\app\application\DownloadClient;

use app\application\Media\MediaProbe;
use app\application\Media\MediaProbeFailed;
use app\application\ResourcePlugin\PluginMediaPublicationFailed;
use app\application\ResourcePlugin\PluginMediaPublicationService;
use app\application\ResourcePlugin\PhpResourcePluginWorkspaceService;
use app\application\ResourcePlugin\PhpResourcePluginWorkspaceUnavailable;
use app\infrastructure\Media\FfprobeMediaProbe;
use FilesystemIterator;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;
use RuntimeException;
use stdClass;
use support\Db;
use Symfony\Component\Process\Process;
use Throwable;

/**
 * 把已完成 qBittorrent 内容发布到任务绑定的本地或远程音乐库。
 *
 * 新任务源必须真实位于 `/storage/downloads/jackett/downloads`。升级迁移会把旧
 * `/media/plugins/jackett/downloads` 与 `/media/downloads` 内容停机迁移到该固定根；历史 qBittorrent 仍返回
 * 旧容器前缀时只做受控前缀映射，不扩大真实路径白名单。历史任务显式固化的 move/自动清理策略仍按
 * 原合同执行。每个候选都是普通、非符号链接的白名单
 * 音频文件，最多处理 10,000 个。本地目标根从数据库读取并重新 realpath，必须 active 且可写；远程
 * 目标只交给核心发布器。所有模式都先写入核心分配的 `/storage/downloads/jackett/runtime/imports` 任务目录，再用一次
 * rename 公布到本地音乐库，绝不在最终库创建 partial、所有权标记或隐藏暂存目录，也不覆盖既有路径。
 *
 * copy 保留源；hardlink 要求源和目标目录 st_dev 相同；symlink 明确保留对下载目录的长期依赖；move
 * 只能在调用方暂停 torrent 后执行，先按 copy 完整原子公布，再尽力删除源。transcode 先把下载源冻结
 * 复制到插件媒体临时库，再按任务固化的服务端白名单档案转换该副本。临时库与目标库必须同设备，跨设备
 * 明确失败且不回退到库内 staging。复制、链接或转码失败只删除带精确任务标记的本次目录；绝不递归删除
 * 未经本服务创建或已公布的目录。已存在的本任务最终目录视为崩溃恢复证据，重复执行只校验并返回文件数。
 * 远程库拒绝 hardlink 与 symlink；copy、move 和 transcode 均先形成普通本地上传产物，再逐文件调用核心
 * 发布账本。move 不在上传阶段删除下载源，成功后仍由 qBittorrent 清理策略决定，避免破坏做种和重试。
 */
final readonly class ResourceDownloadImportService
{
    private const AUDIO_EXTENSIONS = ['mp3', 'flac', 'm4a', 'aac', 'ogg', 'opus', 'wav', 'wma', 'ape', 'alac', 'aiff', 'aif'];
    private const PLUGIN_KEY = 'jackett';
    private const RUNTIME_MARKER = '.velin-runtime-owner';
    private const RUNTIME_OWNER = "velin-jackett-runtime-v1\n";
    private const IMPORTS_MARKER = '.velin-imports-owner';
    private const IMPORTS_OWNER = "velin-jackett-imports-v1\n";

    public function __construct(
        private ?PhpResourcePluginWorkspaceService $workspaces = null,
        private ?string $downloadRoot = null,
        private ?string $legacyDownloadRoot = null,
        private PluginMediaPublicationService $publications = new PluginMediaPublicationService(),
        private MediaProbe $probe = new FfprobeMediaProbe(),
    ) {
    }

    /**
     * 发布一个下载任务中的全部白名单音频。
     *
     * transcode 必须携带创建任务时固化且仍通过白名单校验的格式/码率；其他模式两值必须为 null。校验在
     * 创建目标暂存目录前完成，非法或迁移不完整的快照不会产生文件副作用。成功返回已原子公布的音频数；
     * 任一文件失败会补偿删除本任务隐藏目录，但不会删除下载源或已存在的最终目录。
     *
     * @return int 成功入库的音频文件数。
     */
    public function publish(
        string $jobId,
        string $libraryId,
        string $title,
        string $contentPath,
        string $mode,
        ?string $transcodeFormat,
        ?int $transcodeBitrateKbps,
    ): int
    {
        if (preg_match('/^[0-9A-HJKMNP-TV-Z]{26}$/D', $jobId) !== 1
            || !in_array($mode, ['copy', 'move', 'hardlink', 'symlink', 'transcode'], true)) throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_INVALID');
        if (($mode === 'transcode' && (!is_string($transcodeFormat)
                || !ResourceDownloadTranscodeProfile::accepts($transcodeFormat, $transcodeBitrateKbps)))
            || ($mode !== 'transcode' && ($transcodeFormat !== null || $transcodeBitrateKbps !== null))) {
            throw new ResourceDownloadImportFailed('DOWNLOAD_TRANSCODE_PROFILE_INVALID');
        }
        /** @var stdClass|null $library */
        $library = Db::table('music_libraries')->where('id', $libraryId)->where('status', 'active')
            ->whereIn('source_type', ['local', 'webdav', 'onedrive', 'google_drive'])
            ->first(['source_type', 'resolved_root_path']);
        if (!$library instanceof stdClass) throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_PATH_INVALID');
        if ((string) $library->source_type !== 'local') {
            if (in_array($mode, ['hardlink', 'symlink'], true)) {
                throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_MODE_REMOTE_UNSUPPORTED');
            }
            return $this->publishRemote($jobId, $libraryId, $contentPath, $mode,
                $transcodeFormat, $transcodeBitrateKbps);
        }
        $targetRoot = $library instanceof stdClass ? realpath((string) $library->resolved_root_path) : false;
        if (!is_string($targetRoot) || !is_writable($targetRoot)) {
            throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_PATH_INVALID');
        }
        $collection = $targetRoot . DIRECTORY_SEPARATOR . 'Velin Downloads';
        if (!is_dir($collection) && !mkdir($collection, 0750, true) && !is_dir($collection)) {
            throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_TARGET_UNWRITABLE');
        }
        $safeTitle = preg_replace('/[^\pL\pN ._()-]+/u', '_', trim($title)) ?: 'download';
        $safeTitle = mb_substr($safeTitle, 0, 100, 'UTF-8');
        $final = $collection . DIRECTORY_SEPARATOR . $safeTitle . ' [' . substr($jobId, -8) . ']';
        $imports = $this->importsDirectory();
        $staging = $imports . DIRECTORY_SEPARATOR . strtolower($jobId);
        $ownerMarker = $imports . DIRECTORY_SEPARATOR . '.' . strtolower($jobId) . '.owner';
        if (is_dir($final) && !is_link($final)) {
            $this->cleanupStaging($staging, $ownerMarker, $jobId);
            return $this->publishedAudioCount($final);
        }

        $runtimeStat = @stat($imports);
        $targetStat = @stat($collection);
        if (!is_array($runtimeStat) || !is_array($targetStat)
            || (string) ($runtimeStat['dev'] ?? '') !== (string) ($targetStat['dev'] ?? '')) {
            throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_RUNTIME_FILESYSTEM_MISMATCH');
        }

        $source = $this->resolveDownloadSource($contentPath);
        if (!is_string($source) || !$this->isAllowedDownloadPath($source) || !is_readable($source)) {
            throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_PATH_INVALID');
        }
        $files = $this->audioFiles($source);
        if ($files === []) throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_NO_AUDIO');

        if (file_exists($staging) || is_link($staging) || file_exists($ownerMarker) || is_link($ownerMarker)) {
            $this->cleanupStaging($staging, $ownerMarker, $jobId);
        }
        if (file_exists($final) || is_link($final) || file_exists($staging) || is_link($staging)) {
            throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_TARGET_EXISTS');
        }
        $marker = @fopen($ownerMarker, 'x+b');
        if ($marker === false) throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_RUNTIME_UNAVAILABLE');
        try {
            $owner = $jobId . "\n";
            if (fwrite($marker, $owner) !== strlen($owner) || !fflush($marker)
                || (function_exists('fsync') && !fsync($marker))) {
                throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_RUNTIME_UNAVAILABLE');
            }
        } finally {
            fclose($marker);
        }
        @chmod($ownerMarker, 0600);
        if (!mkdir($staging, 0750)) {
            @unlink($ownerMarker);
            throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_RUNTIME_UNAVAILABLE');
        }

        try {
            foreach ($files as $file) {
                $relative = $mode === 'transcode'
                    ? $this->transcodeRelativePath($file['relative'], (string) $transcodeFormat)
                    : $file['relative'];
                $target = $staging . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relative);
                $parent = dirname($target);
                if (!is_dir($parent) && !mkdir($parent, 0750, true) && !is_dir($parent)) {
                    throw new RuntimeException('parent');
                }
                if (file_exists($target) || is_link($target)) throw new RuntimeException('collision');
                if ($mode === 'transcode') {
                    $this->transcodeFile(
                        $file['path'],
                        $target,
                        (string) $transcodeFormat,
                        $transcodeBitrateKbps,
                    );
                }
                else $this->publishFile($file['path'], $target, $mode === 'move' ? 'copy' : $mode);
            }
            if (!rename($staging, $final)) throw new RuntimeException('publish');
            if (!unlink($ownerMarker)) throw new RuntimeException('owner-cleanup');
            if ($mode === 'move') {
                foreach ($files as $file) @unlink($file['path']);
            }
            return count($files);
        } catch (ResourceDownloadImportFailed $failure) {
            $this->cleanupStaging($staging, $ownerMarker, $jobId);
            throw $failure;
        } catch (Throwable) {
            $this->cleanupStaging($staging, $ownerMarker, $jobId);
            throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_FAILED');
        }
    }

    /**
     * 为远程库生成普通本地上传产物并逐首发布。
     *
     * 源树先通过 qBittorrent 根、普通文件、链接与数量边界复验，再复制或转码到当前任务 marker 持有的
     * staging。每个文件以源树相对路径作为幂等身份；核心账本允许前 N 首成功、第 N+1 首失败后重试时
     * 直接跳过已发布对象。FFprobe 使用主程序固定二进制，只读提取 title/artist/album；探测失败时仅从
     * 已验证相对目录保守推断并经过核心文件名规范化。所有文件发布后才清理 staging，本方法从不删除下载源。
     */
    private function publishRemote(
        string $jobId,
        string $libraryId,
        string $contentPath,
        string $mode,
        ?string $transcodeFormat,
        ?int $transcodeBitrateKbps,
    ): int {
        $source = $this->resolveDownloadSource($contentPath);
        if (!is_string($source) || !$this->isAllowedDownloadPath($source) || !is_readable($source)) {
            throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_PATH_INVALID');
        }
        $files = $this->audioFiles($source);
        if ($files === []) throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_NO_AUDIO');

        $imports = $this->importsDirectory();
        $staging = $imports . DIRECTORY_SEPARATOR . strtolower($jobId);
        $ownerMarker = $imports . DIRECTORY_SEPARATOR . '.' . strtolower($jobId) . '.owner';
        if (file_exists($staging) || is_link($staging) || file_exists($ownerMarker) || is_link($ownerMarker)) {
            $this->cleanupStaging($staging, $ownerMarker, $jobId);
        }
        $marker = @fopen($ownerMarker, 'x+b');
        if ($marker === false) throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_RUNTIME_UNAVAILABLE');
        try {
            $owner = $jobId . "\n";
            if (fwrite($marker, $owner) !== strlen($owner) || !fflush($marker)
                || (function_exists('fsync') && !fsync($marker))) {
                throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_RUNTIME_UNAVAILABLE');
            }
        } finally {
            fclose($marker);
        }
        @chmod($ownerMarker, 0600);
        if (!mkdir($staging, 0700)) {
            @unlink($ownerMarker);
            throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_RUNTIME_UNAVAILABLE');
        }

        try {
            foreach ($files as $file) {
                $relative = $mode === 'transcode'
                    ? $this->transcodeRelativePath($file['relative'], (string) $transcodeFormat)
                    : $file['relative'];
                $uploadSource = $staging . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relative);
                $parent = dirname($uploadSource);
                if (!is_dir($parent) && !mkdir($parent, 0700, true) && !is_dir($parent)) {
                    throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_RUNTIME_UNAVAILABLE');
                }
                if ($mode === 'transcode') {
                    $this->transcodeFile($file['path'], $uploadSource, (string) $transcodeFormat,
                        $transcodeBitrateKbps);
                } else {
                    $this->publishFile($file['path'], $uploadSource, 'copy');
                }
                $metadata = $this->publicationMetadata($uploadSource, $relative);
                try {
                    $this->publications->publish(self::PLUGIN_KEY, $jobId, $libraryId, $uploadSource,
                        $file['relative'], $metadata['artist'], $metadata['album'], $metadata['title'],
                        strtolower(pathinfo($uploadSource, PATHINFO_EXTENSION)), [
                            'title' => $metadata['title'],
                            'artists' => [$metadata['artist']],
                            'albumTitle' => $metadata['album'] === '' ? null : $metadata['album'],
                            'albumArtists' => [$metadata['artist']],
                        ]);
                } catch (PluginMediaPublicationFailed $failure) {
                    throw new ResourceDownloadImportFailed($failure->errorCode);
                }
            }
            $this->cleanupStaging($staging, $ownerMarker, $jobId);
            return count($files);
        } catch (ResourceDownloadImportFailed $failure) {
            $this->cleanupStaging($staging, $ownerMarker, $jobId);
            throw $failure;
        } catch (Throwable) {
            $this->cleanupStaging($staging, $ownerMarker, $jobId);
            throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_FAILED');
        }
    }

    /** @return array{artist:string,album:string,title:string} */
    private function publicationMetadata(string $path, string $relative): array
    {
        $fallbackTitle = pathinfo($relative, PATHINFO_FILENAME);
        try {
            $metadata = $this->probe->probe($path, $fallbackTitle);
            return [
                'artist' => trim((string) ($metadata->artists[0] ?? '')) ?: '未知艺人',
                'album' => $metadata->hasTaggedAlbum ? trim($metadata->albumTitle) : '',
                'title' => trim($metadata->title) ?: $fallbackTitle,
            ];
        } catch (MediaProbeFailed) {
            $segments = explode('/', $relative);
            $fileName = (string) array_pop($segments);
            return [
                'artist' => count($segments) >= 1 ? (string) $segments[0] : '未知艺人',
                'album' => count($segments) >= 2 ? (string) $segments[1] : '',
                'title' => pathinfo($fileName, PATHINFO_FILENAME) ?: '未知歌曲',
            ];
        }
    }

    /** @return list<array{path:string,relative:string}> */
    private function audioFiles(string $source): array
    {
        $base = is_dir($source) ? $source : dirname($source);
        $paths = is_dir($source)
            ? new RecursiveIteratorIterator(new RecursiveDirectoryIterator($source, FilesystemIterator::SKIP_DOTS))
            : [new \SplFileInfo($source)];
        $files = [];
        foreach ($paths as $info) {
            if (!$info instanceof \SplFileInfo) continue;
            if ($info->isLink()) throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_SYMLINK_SOURCE');
            if (!$info->isFile()) continue;
            $path = $info->getPathname();
            $extension = strtolower(pathinfo($path, PATHINFO_EXTENSION));
            if (!in_array($extension, self::AUDIO_EXTENSIONS, true)) continue;
            $real = realpath($path);
            if (!is_string($real) || !$this->within($real, $source) || !is_readable($real)) {
                throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_PATH_INVALID');
            }
            $relative = is_file($source) ? basename($real) : ltrim(substr($real, strlen($base)), DIRECTORY_SEPARATOR);
            $relative = str_replace(DIRECTORY_SEPARATOR, '/', $relative);
            if ($relative === '' || str_contains($relative, '../') || count($files) >= 10_000) {
                throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_TOO_MANY_FILES');
            }
            $files[] = ['path' => $real, 'relative' => $relative];
        }
        return $files;
    }

    private function publishFile(string $source, string $target, string $mode): void
    {
        if ($mode === 'copy') {
            $input = fopen($source, 'rb');
            $output = fopen($target, 'xb');
            if ($input === false || $output === false) throw new RuntimeException('copy-open');
            try {
                if (stream_copy_to_stream($input, $output) === false || !fflush($output)) throw new RuntimeException('copy');
            } finally {
                fclose($input); fclose($output);
            }
            chmod($target, 0640);
            return;
        }
        if ($mode === 'move') {
            if (!rename($source, $target)) throw new RuntimeException('move');
            return;
        }
        if ($mode === 'hardlink') {
            $sourceStat = stat($source); $targetStat = stat(dirname($target));
            if (!is_array($sourceStat) || !is_array($targetStat) || $sourceStat['dev'] !== $targetStat['dev']) {
                throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_CROSS_DEVICE');
            }
            if (!link($source, $target)) throw new RuntimeException('hardlink');
            return;
        }
        if (!symlink($source, $target)) throw new RuntimeException('symlink');
    }

    /**
     * 使用任务固化的白名单档案转换一个已复验音频副本。
     *
     * 下载源先以独占临时路径复制到目标隐藏目录，并在复制前后复验 dev/inode/size/mtime；FFmpeg 只读取
     * 该冻结副本，输入和输出绝对路径以参数数组传递，绝不经过 shell。副本在成功、失败或异常时都必须
     * 删除，不能随最终目录发布。退出码异常、超时、空输出或副本清理失败都会删除转码结果并让整次入库
     * 失败；格式、码率、编码器和容器由 ResourceDownloadTranscodeProfile 复验并构造，不能由浏览器注入。
     * 原下载源不由本方法删除，只有音乐库结果原子发布成功后，独立清理状态机才可按任务策略删除。
     */
    private function transcodeFile(
        string $source,
        string $target,
        string $format,
        ?int $bitrateKbps,
    ): void
    {
        if (!ResourceDownloadTranscodeProfile::accepts($format, $bitrateKbps)) {
            throw new ResourceDownloadImportFailed('DOWNLOAD_TRANSCODE_PROFILE_INVALID');
        }
        $binary = realpath((string) (getenv('VELIN_FFMPEG_PATH') ?: base_path('bin/ffmpeg')));
        if (!is_string($binary) || !is_file($binary) || !is_executable($binary)) {
            throw new ResourceDownloadImportFailed('DOWNLOAD_TRANSCODE_UNAVAILABLE');
        }
        $frozenSource = dirname($target) . DIRECTORY_SEPARATOR . '.' . basename($target)
            . '.source-' . bin2hex(random_bytes(8)) . '.tmp';
        $this->copyTranscodeSource($source, $frozenSource);
        $copyRemoved = false;
        try {
            $process = new Process(array_merge([
                $binary, '-nostdin', '-hide_banner', '-loglevel', 'error', '-i', $frozenSource,
                '-map', '0:a:0', '-vn', '-sn', '-dn', '-map_metadata', '0',
            ], ResourceDownloadTranscodeProfile::ffmpegArguments($format, $bitrateKbps), [
                $target,
            ]), base_path(), ['PATH' => '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'], null, 21_600);
            $process->setIdleTimeout(600);
            $process->run();
        } finally {
            clearstatcache(true, $frozenSource);
            $copyRemoved = !file_exists($frozenSource) || (!is_link($frozenSource) && @unlink($frozenSource));
        }
        clearstatcache(true, $target);
        if (!$copyRemoved || !$process->isSuccessful() || !is_file($target) || is_link($target)
            || filesize($target) <= 0) {
            @unlink($target);
            throw new ResourceDownloadImportFailed('DOWNLOAD_TRANSCODE_FAILED');
        }
        @chmod($target, 0640);
    }

    /**
     * 把下载源冻结为同一任务隐藏目录中的临时转码输入。
     *
     * 源必须是普通非链接文件，目标必须不存在。复制使用独占创建并在关闭前 flush/fsync；随后重新读取源
     * 身份并校验副本大小，下载器若在复制期间改写源则失败关闭。任何失败只删除精确临时副本，不触碰
     * 下载源或其他任务文件；成功副本权限为 0600，并由 transcodeFile 的 finally 负责最终清理。
     */
    private function copyTranscodeSource(string $source, string $frozenSource): void
    {
        clearstatcache(true, $source);
        $before = @lstat($source);
        if (!is_array($before) || is_link($source) || !is_file($source) || (int) ($before['size'] ?? 0) <= 0) {
            throw new ResourceDownloadImportFailed('DOWNLOAD_TRANSCODE_SOURCE_COPY_FAILED');
        }
        $input = @fopen($source, 'rb');
        $output = @fopen($frozenSource, 'xb');
        if ($input === false || $output === false) {
            if (is_resource($input)) fclose($input);
            if (is_resource($output)) fclose($output);
            @unlink($frozenSource);
            throw new ResourceDownloadImportFailed('DOWNLOAD_TRANSCODE_SOURCE_COPY_FAILED');
        }
        $copied = false;
        try {
            $copied = stream_copy_to_stream($input, $output) !== false
                && fflush($output)
                && (!function_exists('fsync') || fsync($output));
        } finally {
            fclose($input);
            fclose($output);
        }
        clearstatcache(true, $source);
        clearstatcache(true, $frozenSource);
        $after = @lstat($source);
        $frozen = @lstat($frozenSource);
        if (!$copied || !is_array($after) || !is_array($frozen) || is_link($frozenSource)
            || !$this->sameIdentity($before, $after)
            || (string) ($frozen['size'] ?? '') !== (string) ($before['size'] ?? '')) {
            @unlink($frozenSource);
            throw new ResourceDownloadImportFailed('DOWNLOAD_TRANSCODE_SOURCE_COPY_FAILED');
        }
        @chmod($frozenSource, 0600);
    }

    /** 同名不同扩展会映射到同一档案目标并由禁止覆盖规则失败，避免静默丢曲。 */
    private function transcodeRelativePath(string $relative, string $format): string
    {
        $directory = pathinfo($relative, PATHINFO_DIRNAME);
        $name = pathinfo($relative, PATHINFO_FILENAME);
        $target = ($directory === '.' || $directory === '' ? '' : $directory . '/') . $name . '.'
            . ResourceDownloadTranscodeProfile::outputExtension($format);
        if ($name === '' || str_contains($target, '../')) throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_INVALID');
        return $target;
    }

    /** @param array<string|int,mixed> $before @param array<string|int,mixed> $after */
    private function sameIdentity(array $before, array $after): bool
    {
        foreach (['dev', 'ino', 'size', 'mtime'] as $key) {
            if ((string) ($before[$key] ?? '') !== (string) ($after[$key] ?? '')) return false;
        }
        return true;
    }

    private function within(string $candidate, string $root): bool
    {
        $root = rtrim($root, DIRECTORY_SEPARATOR);
        return $candidate === $root || str_starts_with($candidate, $root . DIRECTORY_SEPARATOR);
    }

    /** 只统计已原子公布目录中的白名单音频；符号链接模式允许但仍复验其目标位于新根或兼容旧根。 */
    private function publishedAudioCount(string $directory): int
    {
        $count = 0;
        $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($directory, FilesystemIterator::SKIP_DOTS));
        foreach ($iterator as $entry) {
            if (!$entry instanceof \SplFileInfo || (!$entry->isFile() && !$entry->isLink())) continue;
            if (!in_array(strtolower($entry->getExtension()), self::AUDIO_EXTENSIONS, true)) continue;
            if ($entry->isLink()) {
                $target = realpath($entry->getPathname());
                if (!is_string($target) || !$this->isAllowedDownloadPath($target)) {
                    throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_PATH_INVALID');
                }
            }
            if (++$count > 10_000) throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_TOO_MANY_FILES');
        }
        if ($count === 0) throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_NO_AUDIO');
        return $count;
    }

    /**
     * 返回 Jackett 导入 staging 集合并复验插件内二级所有权。
     *
     * 插件根只能由核心分配。`runtime` 和 `imports` 分别使用独立 marker，任一级已存在但缺少精确 marker
     * 都拒绝接管；新建时使用 0700 与独占 marker。该集合仅保存 Velin 的入库副本和转码中间文件，
     * qBittorrent 的新旧下载交换根都不由本方法迁移或清理。卸载时核心可据协议清理整个 runtime，同时
     * 保留同级 downloads 和其中需要继续做种的数据。
     */
    private function importsDirectory(): string
    {
        try {
            $workspace = ($this->workspaces ?? new PhpResourcePluginWorkspaceService())->mediaDirectory(self::PLUGIN_KEY);
        } catch (PhpResourcePluginWorkspaceUnavailable) {
            throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_RUNTIME_UNAVAILABLE');
        }
        $runtime = $this->ownedChildDirectory(
            $workspace,
            'runtime',
            self::RUNTIME_MARKER,
            self::RUNTIME_OWNER,
        );
        return $this->ownedChildDirectory(
            $runtime,
            'imports',
            self::IMPORTS_MARKER,
            self::IMPORTS_OWNER,
        );
    }

    /**
     * 在已复验父目录下幂等分配一个 Jackett 所有的 staging 子目录。
     *
     * 父目录和子目录都必须是非链接真实目录；只有本次成功创建的目录才写独占 marker。并发创建最终以
     * marker 内容收敛，已有无 marker 目录不会被静默接管。失败不递归删除现场，避免误删另一个 Worker
     * 已开始写入的数据；调用方统一转换为稳定的 runtime 不可用错误。
     */
    private function ownedChildDirectory(
        string $parent,
        string $name,
        string $markerName,
        string $owner,
    ): string {
        $parentReal = realpath($parent);
        if (!is_string($parentReal) || $parentReal !== $parent || !is_dir($parentReal) || is_link($parent)) {
            throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_RUNTIME_UNAVAILABLE');
        }
        $directory = $parentReal . DIRECTORY_SEPARATOR . $name;
        $created = false;
        if (!file_exists($directory) && !is_link($directory)) {
            $created = @mkdir($directory, 0700);
            if (!$created && !is_dir($directory)) {
                throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_RUNTIME_UNAVAILABLE');
            }
        }
        $real = realpath($directory);
        if (!is_string($real) || $real !== $directory || is_link($directory) || !is_dir($real) || !is_writable($real)) {
            throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_RUNTIME_UNAVAILABLE');
        }
        $marker = $real . DIRECTORY_SEPARATOR . $markerName;
        if ($created) {
            $handle = @fopen($marker, 'x+b');
            if ($handle === false) throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_RUNTIME_UNAVAILABLE');
            try {
                if (fwrite($handle, $owner) !== strlen($owner) || !fflush($handle)
                    || (function_exists('fsync') && !fsync($handle))) {
                    throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_RUNTIME_UNAVAILABLE');
                }
            } finally {
                fclose($handle);
            }
            @chmod($marker, 0600);
        }
        if (!is_file($marker) || is_link($marker) || @file_get_contents($marker) !== $owner) {
            throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_RUNTIME_UNAVAILABLE');
        }
        return $real;
    }

    /**
     * 判断真实路径是否位于允许读取的 qBittorrent 根。
     *
     * 生产默认同时接受当前根和旧根，以便目录调整前创建的任务继续入库；注入主根的测试默认只信任该根，
     * 只有显式注入第三个兼容根时才扩大范围。不存在的根直接忽略，因此新目录尚未建立不会阻断旧任务，
     * 但任何来源仍必须命中至少一个已存在、非链接且 realpath 精确的根。
     */
    private function isAllowedDownloadPath(string $candidate): bool
    {
        $configured = [$this->downloadRoot ?? QbittorrentSettingsService::DOWNLOAD_DIRECTORY];
        if ($this->downloadRoot === null) {
            $configured[] = QbittorrentSettingsService::LEGACY_PLUGIN_DOWNLOAD_DIRECTORY;
            $configured[] = QbittorrentSettingsService::LEGACY_DOWNLOAD_DIRECTORY;
        } elseif ($this->legacyDownloadRoot !== null) {
            $configured[] = $this->legacyDownloadRoot;
        }
        foreach (array_unique($configured) as $root) {
            $real = realpath($root);
            if (is_string($real) && $real === rtrim($root, DIRECTORY_SEPARATOR)
                && is_dir($real) && !is_link($root) && $this->within($candidate, $real)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 把升级前 qBittorrent 任务仍返回的旧容器前缀映射到已经迁移的新下载根。
     *
     * 只有生产默认根启用映射，注入路径的测试和调用方不扩大权限。替换要求完整根或分隔符边界，不能把
     * `/media/downloads-old` 误映射；随后仍执行 realpath、非链接根和 isAllowedDownloadPath 校验，因此
     * 该兼容层不会允许浏览器或下载器选择任意文件。映射不改 qBittorrent 状态或数据库，部署者完成其
     * 保存路径升级后自然直接使用新路径。
     */
    private function resolveDownloadSource(string $contentPath): string|false
    {
        if ($this->downloadRoot === null) {
            $contentPath = $this->mapLegacyDownloadPath($contentPath);
        }
        return realpath($contentPath);
    }

    /**
     * 把两种旧宿主目录映射到各自不冲突的新位置。
     *
     * 旧插件专用根可直接收敛到当前 Jackett 下载根；更早的公共 `/media/downloads` 必须进入 `legacy`
     * 子目录，否则两个旧根存在同名专辑时会在停机迁移后静默指向错误资源。只接受完整根或目录分隔符
     * 边界，未知路径保持原值并由后续 realpath/所有权检查拒绝。本方法只转换字符串，不创建、移动、
     * 覆盖或删除文件，重复调用保持幂等。
     */
    private function mapLegacyDownloadPath(string $contentPath): string
    {
        foreach ([
            QbittorrentSettingsService::LEGACY_PLUGIN_DOWNLOAD_DIRECTORY
                => QbittorrentSettingsService::DOWNLOAD_DIRECTORY,
            QbittorrentSettingsService::LEGACY_DOWNLOAD_DIRECTORY
                => QbittorrentSettingsService::MIGRATED_LEGACY_DOWNLOAD_DIRECTORY,
        ] as $legacyRoot => $migratedRoot) {
            $legacyRoot = rtrim($legacyRoot, DIRECTORY_SEPARATOR);
            if ($contentPath === $legacyRoot || str_starts_with($contentPath, $legacyRoot . DIRECTORY_SEPARATOR)) {
                return $migratedRoot . substr($contentPath, strlen($legacyRoot));
            }
        }
        return $contentPath;
    }

    /**
     * 删除精确任务拥有的导入 staging，不跟随目录内链接。
     *
     * sibling marker 不会随 rename 进入音乐库。staging 和 marker 必须同时存在且 marker 内容等于任务
     * ULID；任一身份不一致都失败并保留现场。目录中的文件全部来自本任务复验后的源树，补偿可递归删除
     * 普通文件和链接，但绝不删除最终目录或核心分配的插件根。
     */
    private function cleanupStaging(string $directory, string $ownerMarker, string $jobId): void
    {
        $directoryExists = file_exists($directory) || is_link($directory);
        $markerExists = file_exists($ownerMarker) || is_link($ownerMarker);
        if (!$directoryExists && !$markerExists) return;
        if (!$directoryExists && $markerExists && is_file($ownerMarker) && !is_link($ownerMarker)
            && @file_get_contents($ownerMarker) === $jobId . "\n") {
            if (!unlink($ownerMarker)) throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_RUNTIME_CLEANUP_FAILED');
            return;
        }
        if (!is_dir($directory) || is_link($directory) || !is_file($ownerMarker) || is_link($ownerMarker)
            || @file_get_contents($ownerMarker) !== $jobId . "\n") {
            throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_RUNTIME_INVALID');
        }
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($directory, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST,
        );
        foreach ($iterator as $entry) {
            $removed = $entry->isLink() || $entry->isFile()
                ? @unlink($entry->getPathname())
                : ($entry->isDir() && @rmdir($entry->getPathname()));
            if (!$removed) throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_RUNTIME_CLEANUP_FAILED');
        }
        if (!rmdir($directory) || !unlink($ownerMarker)) {
            throw new ResourceDownloadImportFailed('DOWNLOAD_IMPORT_RUNTIME_CLEANUP_FAILED');
        }
    }
}

final class ResourceDownloadImportFailed extends RuntimeException
{
    public function __construct(public readonly string $errorCode) { parent::__construct($errorCode); }
}
