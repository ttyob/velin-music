<?php

declare(strict_types=1);

namespace plugin\jackett\app\application\DownloadClient;

/**
 * 统一计算资源下载任务可以执行的最终源数据清理策略。
 *
 * 配置中的清理策略是管理员意图，但最终能否删除 qBittorrent 源数据还取决于入库方式。copy、hardlink
 * 和 transcode 都会在音乐库中产生不依赖下载路径的独立结果；move 在入库时已经移走音频，不能继续
 * 等待做种；symlink 则长期依赖下载路径，任何自动删除都会制造失效链接。该解析器不访问数据库或文件
 * 系统，可在任务创建事务前安全重复调用；调用方必须先完成枚举白名单校验。
 */
final class ResourceDownloadCleanupPolicyResolver
{
    /**
     * 返回任务必须固化的最终清理策略。
     *
     * 使用软链接时固定返回 never；历史转码任务可能仍带有已经移除的源文件保护快照，此时也必须继续
     * 返回 never，升级不能反向授权删除旧任务源数据。move 与 after_seeding 组合改为 after_import，
     * 因为移动后已经没有可继续做种的完整源。其他组合保持管理员配置。该方法只计算策略，不删除文件、
     * torrent 或修改任务，实际清理仍必须等入库目录原子发布成功后由 Worker 执行。
     */
    public static function resolve(string $importMode, string $configuredPolicy, bool $transcodeKeepSource): string
    {
        if ($importMode === 'symlink' || ($importMode === 'transcode' && $transcodeKeepSource)) {
            return 'never';
        }
        if ($importMode === 'move' && $configuredPolicy === 'after_seeding') {
            return 'after_import';
        }
        return $configuredPolicy;
    }

    /**
     * 判断当前任务是否具备自动删除下载源数据的结构条件。
     *
     * 返回 true 只表示入库产物不会依赖下载路径，不代表一定会删除；配置仍可选择 never。软链接和带
     * 历史保护快照的转码返回 false，确保升级后 Worker 不会改变既有任务的删除授权。
     */
    public static function supportsAutomaticCleanup(string $importMode, bool $transcodeKeepSource): bool
    {
        return $importMode !== 'symlink' && !($importMode === 'transcode' && $transcodeKeepSource);
    }
}
