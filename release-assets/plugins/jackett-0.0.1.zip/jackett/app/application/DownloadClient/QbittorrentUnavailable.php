<?php

declare(strict_types=1);

namespace plugin\jackett\app\application\DownloadClient;

/** qBittorrent 连接、认证、命令或协议失败；errorCode 可安全记录，异常不携带第三方消息。 */
final class QbittorrentUnavailable extends \RuntimeException
{
    public function __construct(public readonly string $errorCode)
    {
        parent::__construct($errorCode);
    }
}
