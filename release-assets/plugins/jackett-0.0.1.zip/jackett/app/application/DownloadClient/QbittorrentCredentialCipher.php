<?php

declare(strict_types=1);

namespace plugin\jackett\app\application\DownloadClient;

use RuntimeException;

/**
 * 使用用途隔离的 Sodium secretbox 加密外部 qBittorrent WebUI 密码。
 *
 * 根密钥来自部署级 `VELIN_CREDENTIAL_KEY`，HKDF context 与 Jackett、WebDAV、Subsonic 完全不同，
 * 防止不同集成的密文被互换解密。密码只允许在保存或单次状态探测调用栈中存在，不得进入 API、日志、
 * 审计、异常事件或前端。密文损坏、版本未知或部署密钥轮换后统一失败关闭，管理员需重新保存密码。
 */
final readonly class QbittorrentCredentialCipher
{
    private string $key;

    /** 测试可注入根密钥；生产读取至少 16 字节的独立部署密钥。 */
    public function __construct(?string $deploymentSecret = null)
    {
        $root = $deploymentSecret ?? getenv('VELIN_CREDENTIAL_KEY') ?: 'velin-development-credential-key-change-me';
        if (strlen($root) < 16) {
            throw new RuntimeException('VELIN_CREDENTIAL_KEY must contain at least 16 bytes.');
        }
        $this->key = hash_hkdf(
            'sha256',
            $root,
            SODIUM_CRYPTO_SECRETBOX_KEYBYTES,
            'velin-qbittorrent-credentials-v1',
        );
    }

    /** 加密已校验的 1-256 字节密码；随机 nonce 保证相同密码不会生成相同数据库值。 */
    public function encrypt(string $password): string
    {
        if (!$this->valid($password)) {
            throw new RuntimeException('qBittorrent credential is outside the supported boundary.');
        }
        $nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        return 'v1:' . base64_encode($nonce . sodium_crypto_secretbox($password, $nonce, $this->key));
    }

    /** 解密并认证密码；调用方必须在外部请求结束后使用 `sodium_memzero()` 清理返回值。 */
    public function decrypt(?string $payload): string
    {
        if (!is_string($payload) || !str_starts_with($payload, 'v1:')) {
            throw new RuntimeException('qBittorrent credential is unavailable.');
        }
        $decoded = base64_decode(substr($payload, 3), true);
        if (!is_string($decoded) || strlen($decoded) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES) {
            throw new RuntimeException('qBittorrent credential is unavailable.');
        }
        $plaintext = sodium_crypto_secretbox_open(
            substr($decoded, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES),
            substr($decoded, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES),
            $this->key,
        );
        if (!is_string($plaintext) || !$this->valid($plaintext)) {
            throw new RuntimeException('qBittorrent credential is unavailable.');
        }
        return $plaintext;
    }

    private function valid(string $password): bool
    {
        return $password !== '' && strlen($password) <= 256 && mb_check_encoding($password, 'UTF-8')
            && preg_match('/[\x00-\x1F\x7F]/u', $password) !== 1;
    }
}
