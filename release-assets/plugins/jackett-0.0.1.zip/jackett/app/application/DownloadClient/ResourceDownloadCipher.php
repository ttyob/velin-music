<?php

declare(strict_types=1);

namespace plugin\jackett\app\application\DownloadClient;

use RuntimeException;

/**
 * 加密 Jackett 下载引用、qBittorrent hash 与内部内容路径。
 *
 * 下载任务密文使用独立 HKDF context，不能与连接密码或 Jackett API Key 互换。明文只允许在一次搜索
 * 持久化、下载器调用或完成入库调用栈中存在，不得进入浏览器、日志、审计或异常。用途字符串参与认证
 * 明文，阻止把 URL 密文误当 hash/path 使用；调用方在使用后应尽快清理返回值。
 */
final readonly class ResourceDownloadCipher
{
    private string $key;

    public function __construct(?string $deploymentSecret = null)
    {
        $root = $deploymentSecret ?? getenv('VELIN_CREDENTIAL_KEY') ?: 'velin-development-credential-key-change-me';
        if (strlen($root) < 16) throw new RuntimeException('VELIN_CREDENTIAL_KEY is invalid.');
        $this->key = hash_hkdf('sha256', $root, SODIUM_CRYPTO_SECRETBOX_KEYBYTES, 'velin-resource-download-v1');
    }

    public function encrypt(string $purpose, string $value): string
    {
        if (!$this->valid($purpose, $value)) throw new RuntimeException('Download secret is invalid.');
        $nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        return 'v1:' . base64_encode($nonce . sodium_crypto_secretbox($purpose . "\0" . $value, $nonce, $this->key));
    }

    public function decrypt(string $purpose, ?string $payload): string
    {
        if (!is_string($payload) || !str_starts_with($payload, 'v1:')) throw new RuntimeException('Download secret is unavailable.');
        $decoded = base64_decode(substr($payload, 3), true);
        if (!is_string($decoded) || strlen($decoded) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES) {
            throw new RuntimeException('Download secret is unavailable.');
        }
        $plain = sodium_crypto_secretbox_open(
            substr($decoded, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES),
            substr($decoded, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES),
            $this->key,
        );
        $prefix = $purpose . "\0";
        if (!is_string($plain) || !str_starts_with($plain, $prefix)) throw new RuntimeException('Download secret is unavailable.');
        $value = substr($plain, strlen($prefix));
        if (!$this->valid($purpose, $value)) throw new RuntimeException('Download secret is unavailable.');
        return $value;
    }

    private function valid(string $purpose, string $value): bool
    {
        return in_array($purpose, ['reference', 'hash', 'content_path'], true)
            && $value !== '' && strlen($value) <= 8192 && !str_contains($value, "\0");
    }
}
