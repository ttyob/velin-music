<?php

declare(strict_types=1);

namespace plugin\jackett\app\application\DownloadClient;

/**
 * 定义下载入库允许使用的转码档案及对应 FFmpeg 参数。
 *
 * 浏览器和数据库只保存格式与受限码率，不能提交编码器名称、容器、扩展名或任意命令参数。本类是这些
 * 派生事实的唯一来源，防止设置校验、任务快照和 Worker 执行出现不同白名单。FLAC 的 null 码率表示
 * 无损编码；压缩级别只影响耗时与文件大小，不改变音频质量，因此固定为 8。档案非法时调用方必须在
 * 创建任务或文件副作用前失败关闭，不能回退到另一个格式后继续发布。
 */
final class ResourceDownloadTranscodeProfile
{
    public const DEFAULT_FORMAT = 'opus';
    public const DEFAULT_BITRATE_KBPS = 192;

    /** @var array<string,list<int|null>> */
    private const BITRATES = [
        'opus' => [96, 128, 160, 192, 256, 320],
        'aac' => [128, 192, 256, 320],
        'mp3' => [128, 192, 256, 320],
        'flac' => [null],
    ];

    /**
     * 判断设置或任务快照是否属于完整白名单组合。
     *
     * 格式区分大小写并使用稳定协议 slug；有损格式必须提供明确码率，FLAC 必须为 null。方法无副作用，
     * 既不探测 FFmpeg，也不修改输入值，适合在设置事务和 Worker 文件操作前重复校验。
     */
    public static function accepts(string $format, ?int $bitrateKbps): bool
    {
        return array_key_exists($format, self::BITRATES)
            && in_array($bitrateKbps, self::BITRATES[$format], true);
    }

    /**
     * 返回指定格式允许展示的码率；FLAC 返回空列表，由界面显示“无损”。
     *
     * 未知格式返回空列表而不猜测默认值，调用方必须结合 accepts 判断是否合法。
     *
     * @return list<int>
     */
    public static function bitrates(string $format): array
    {
        return array_values(array_filter(
            self::BITRATES[$format] ?? [],
            static fn (?int $value): bool => $value !== null,
        ));
    }

    /**
     * 返回服务端支持的稳定格式 slug，顺序同时作为管理端展示顺序。
     *
     * @return list<string>
     */
    public static function formats(): array
    {
        return array_keys(self::BITRATES);
    }

    /**
     * 根据已经通过 accepts 校验的格式返回安全输出扩展名。
     *
     * 扩展名由服务端决定并参与目标冲突检测，不能由标题、下载文件扩展名或浏览器覆盖。
     */
    public static function outputExtension(string $format): string
    {
        return match ($format) {
            'opus' => 'opus',
            'aac' => 'm4a',
            'mp3' => 'mp3',
            'flac' => 'flac',
            default => throw new \InvalidArgumentException('Unsupported transcode format.'),
        };
    }

    /**
     * 根据已校验档案构造不含路径的 FFmpeg 参数数组。
     *
     * 返回值只包含内置编码器、码率、容器与固定质量参数，不包含输入/输出路径，也不经过 shell。调用方
     * 必须先使用 accepts 复验任务快照；非法档案抛出异常且不得执行 FFmpeg。AAC 输出 MP4/M4A，Opus
     * 输出 Ogg，MP3 与 FLAC 使用各自原生容器。
     *
     * @return list<string>
     */
    public static function ffmpegArguments(string $format, ?int $bitrateKbps): array
    {
        if (!self::accepts($format, $bitrateKbps)) {
            throw new \InvalidArgumentException('Unsupported transcode profile.');
        }
        return match ($format) {
            'opus' => ['-codec:a', 'libopus', '-b:a', $bitrateKbps . 'k', '-vbr', 'on',
                '-application', 'audio', '-f', 'ogg'],
            'aac' => ['-codec:a', 'aac', '-b:a', $bitrateKbps . 'k', '-movflags', '+faststart', '-f', 'mp4'],
            'mp3' => ['-codec:a', 'libmp3lame', '-b:a', $bitrateKbps . 'k', '-f', 'mp3'],
            'flac' => ['-codec:a', 'flac', '-compression_level', '8', '-f', 'flac'],
        };
    }
}
