<?php

declare(strict_types=1);

namespace plugin\jackett\app\application\DownloadClient;

use app\infrastructure\Audit\AuditLogger;
use JsonException;
use RuntimeException;
use stdClass;
use support\Db;

/**
 * 管理外部 qBittorrent WebUI 的全局连接设置。
 *
 * 地址、账号与启停状态保存在版本化 `system_settings` 对象，密码使用 qBittorrent 专用 secretbox 密文。
 * 新任务下载目录 `/storage/downloads/jackett/downloads`、分类 `velin-music` 与完成监听方式固定在服务端，
 * 浏览器不能提交路径、
 * 分类或监听器。管理员从服务端白名单选择默认入库方式、转码档案与自动清理策略；每次任务仍会显式
 * 绑定目标音乐库并固化当时的档案和清理快照。更新使用单行 CAS 与同事务脱敏审计，不在事务中访问
 * 网络、创建目录、安装下载器、删除 torrent 或修改 qBittorrent 设置。
 */
final readonly class QbittorrentSettingsService implements QbittorrentConnectionProvider
{
    public const DOWNLOAD_DIRECTORY = '/storage/downloads/jackett/downloads';
    public const MIGRATED_LEGACY_DOWNLOAD_DIRECTORY = self::DOWNLOAD_DIRECTORY . '/legacy';
    public const LEGACY_PLUGIN_DOWNLOAD_DIRECTORY = '/media/plugins/jackett/downloads';
    public const LEGACY_DOWNLOAD_DIRECTORY = '/media/downloads';
    public const CATEGORY = 'velin-music';
    private const KEY = 'integration.qbittorrent';

    public function __construct(
        private QbittorrentCredentialCipher $cipher = new QbittorrentCredentialCipher(),
        private AuditLogger $audit = new AuditLogger(),
    ) {
    }

    /**
     * 返回配置弹窗使用的脱敏快照。
     *
     * 缺行、损坏 JSON、非法 URL/账号或异常密文字段表示迁移或数据故障并失败关闭。本方法不解密密码，
     * 不访问外部服务，也不检查目录；固定目录仅作为不可编辑事实投影。
     *
     * @return array{enabled:bool,baseUrl:string,username:string,configured:bool,downloadDirectory:string,category:string,defaultImportMode:string,transcodeFormat:string,transcodeBitrateKbps:?int,cleanupPolicy:string,cleanupDelayHours:int,minimumSeedTimeHours:int,monitorMode:string,version:int,updatedAt:string}
     */
    public function snapshot(): array
    {
        $setting = $this->setting();
        return [
            'enabled' => $setting['enabled'],
            'baseUrl' => $setting['baseUrl'],
            'username' => $setting['username'],
            'configured' => is_string($setting['passwordCiphertext']) && $setting['passwordCiphertext'] !== '',
            'downloadDirectory' => self::DOWNLOAD_DIRECTORY,
            'category' => self::CATEGORY,
            'defaultImportMode' => $setting['defaultImportMode'],
            'transcodeFormat' => $setting['transcodeFormat'],
            'transcodeBitrateKbps' => $setting['transcodeBitrateKbps'],
            'cleanupPolicy' => $setting['cleanupPolicy'],
            'cleanupDelayHours' => $setting['cleanupDelayHours'],
            'minimumSeedTimeHours' => $setting['minimumSeedTimeHours'],
            'monitorMode' => $setting['monitorMode'],
            'version' => $setting['version'],
            'updatedAt' => $setting['updatedAt'],
        ];
    }

    /**
     * 为一次状态探测解密连接。
     *
     * 配置必须启用且地址、账号、密文完整。返回密码只能立即交给 qBittorrent 客户端，并由调用方在
     * finally 中清理；解密失败不携带密文、URL、账号或 Sodium 底层消息。
     *
     * @return array{baseUrl:string,username:string,password:string}
     */
    public function connection(): array
    {
        $setting = $this->setting();
        if (!$setting['enabled'] || $setting['baseUrl'] === '' || $setting['username'] === ''
            || !is_string($setting['passwordCiphertext'])) {
            throw new QbittorrentSettingsUnavailable();
        }
        try {
            $password = $this->cipher->decrypt($setting['passwordCiphertext']);
        } catch (RuntimeException) {
            throw new QbittorrentSettingsUnavailable();
        }
        return ['baseUrl' => $setting['baseUrl'], 'username' => $setting['username'], 'password' => $password];
    }

    /**
     * 原子保存启停、外部地址、账号和可选的新密码。
     *
     * `password` 省略时保留旧密文；显式空字符串只允许在关闭连接时清除。启用要求地址、账号和有效
     * 密码完整。转码格式与码率必须构成服务端白名单档案，FLAC 只能使用 null 表示无损；默认软链接只能
     * 选择 never，默认移动不能选择 after_seeding。这些后端约束与页面禁用规则重复实施，防止绕过浏览器
     * 保存随后会被任务静默改写的配置。URL 允许管理员明确配置 HTTP/HTTPS 内网或公网 WebUI，并支持
     * 反向代理子路径，但拒绝 URL 凭据、查询、片段、点段和控制字符。审计不保存地址、账号或密码。
     *
     * @return array{enabled:bool,baseUrl:string,username:string,configured:bool,downloadDirectory:string,category:string,defaultImportMode:string,transcodeFormat:string,transcodeBitrateKbps:?int,cleanupPolicy:string,cleanupDelayHours:int,minimumSeedTimeHours:int,monitorMode:string,version:int,updatedAt:string}
     */
    public function update(array $command, string $actorId, string $requestId): array
    {
        return Db::transaction(function () use ($command, $actorId, $requestId): array {
            $before = $this->setting();
            $allowed = ['enabled', 'baseUrl', 'username', 'defaultImportMode', 'transcodeFormat',
                'transcodeBitrateKbps', 'cleanupPolicy', 'cleanupDelayHours', 'minimumSeedTimeHours',
                'expectedVersion', 'password'];
            $requiredCount = array_key_exists('password', $command) ? 11 : 10;
            if (array_is_list($command) || array_diff(array_keys($command), $allowed) !== []
                || count($command) !== $requiredCount || !is_bool($command['enabled'] ?? null)
                || !is_string($command['baseUrl'] ?? null) || !is_string($command['username'] ?? null)
                || !is_string($command['defaultImportMode'] ?? null)
                || !in_array($command['defaultImportMode'], ['copy', 'move', 'hardlink', 'symlink', 'transcode'], true)
                || !is_string($command['transcodeFormat'] ?? null)
                || (!is_int($command['transcodeBitrateKbps'] ?? null)
                    && !is_null($command['transcodeBitrateKbps'] ?? null))
                || !ResourceDownloadTranscodeProfile::accepts(
                    $command['transcodeFormat'],
                    $command['transcodeBitrateKbps'],
                )
                || !is_string($command['cleanupPolicy'] ?? null)
                || !in_array($command['cleanupPolicy'], ['never', 'after_import', 'after_delay', 'after_seeding'], true)
                || !is_int($command['cleanupDelayHours'] ?? null)
                || $command['cleanupDelayHours'] < 1 || $command['cleanupDelayHours'] > 8760
                || !is_int($command['minimumSeedTimeHours'] ?? null)
                || $command['minimumSeedTimeHours'] < 1 || $command['minimumSeedTimeHours'] > 8760
                || !is_int($command['expectedVersion'] ?? null)) {
                throw new QbittorrentSettingsInvalid();
            }
            if ($command['expectedVersion'] !== $before['version']) {
                throw new QbittorrentSettingsConflict();
            }
            if (ResourceDownloadCleanupPolicyResolver::resolve(
                $command['defaultImportMode'],
                $command['cleanupPolicy'],
                false,
            ) !== $command['cleanupPolicy']) {
                throw new QbittorrentSettingsInvalid();
            }

            $baseUrl = $this->normalizeBaseUrl($command['baseUrl'], $command['enabled']);
            $username = $this->normalizeUsername($command['username'], $command['enabled']);
            $ciphertext = $before['passwordCiphertext'];
            if (array_key_exists('password', $command)) {
                if (!is_string($command['password'])) throw new QbittorrentSettingsInvalid();
                $password = $command['password'];
                if ($password === '') {
                    $ciphertext = null;
                } else {
                    try {
                        $ciphertext = $this->cipher->encrypt($password);
                    } catch (RuntimeException) {
                        throw new QbittorrentSettingsInvalid();
                    } finally {
                        sodium_memzero($password);
                    }
                }
            }
            if ($command['enabled'] && ($baseUrl === '' || $username === '' || !is_string($ciphertext))) {
                throw new QbittorrentSettingsInvalid();
            }

            $value = [
                'enabled' => $command['enabled'],
                'baseUrl' => $baseUrl,
                'username' => $username,
                'passwordCiphertext' => $ciphertext,
                'defaultImportMode' => $command['defaultImportMode'],
                'transcodeFormat' => $command['transcodeFormat'],
                'transcodeBitrateKbps' => $command['transcodeBitrateKbps'],
                'cleanupPolicy' => $command['cleanupPolicy'],
                'cleanupDelayHours' => $command['cleanupDelayHours'],
                'minimumSeedTimeHours' => $command['minimumSeedTimeHours'],
                'monitorMode' => 'qbittorrent_api',
            ];
            $changed = Db::table('system_settings')->where('setting_key', self::KEY)
                ->where('version', $command['expectedVersion'])->update([
                    'value_json' => json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR),
                    'version' => Db::raw('version + 1'),
                    'updated_by' => $actorId,
                    'updated_at' => gmdate('Y-m-d\TH:i:s\Z'),
                ]);
            if ($changed !== 1) throw new QbittorrentSettingsConflict();
            $this->audit->record(
                $actorId,
                'integration.qbittorrent.update',
                'system_setting',
                self::KEY,
                'success',
                $requestId,
                [
                    'enabled' => $command['enabled'],
                    'configured' => is_string($ciphertext),
                    'url_changed' => $baseUrl !== $before['baseUrl'],
                    'username_changed' => $username !== $before['username'],
                    'credential_replaced' => array_key_exists('password', $command),
                    'default_import_mode' => $command['defaultImportMode'],
                    'transcode_format' => $command['transcodeFormat'],
                    'transcode_bitrate_kbps' => $command['transcodeBitrateKbps'],
                    'cleanup_policy' => $command['cleanupPolicy'],
                    'cleanup_delay_hours' => $command['cleanupDelayHours'],
                    'minimum_seed_time_hours' => $command['minimumSeedTimeHours'],
                    'version' => $command['expectedVersion'] + 1,
                ],
            );
            return $this->snapshot();
        });
    }

    /** @return array{enabled:bool,baseUrl:string,username:string,passwordCiphertext:?string,defaultImportMode:string,transcodeFormat:string,transcodeBitrateKbps:?int,cleanupPolicy:string,cleanupDelayHours:int,minimumSeedTimeHours:int,monitorMode:string,version:int,updatedAt:string} */
    private function setting(): array
    {
        $row = Db::table('system_settings')->where('setting_key', self::KEY)->first();
        if (!$row instanceof stdClass) throw new QbittorrentSettingsUnavailable();
        try {
            $value = json_decode((string) $row->value_json, true, 8, JSON_THROW_ON_ERROR);
        } catch (JsonException) {
            throw new QbittorrentSettingsUnavailable();
        }
        if (!is_array($value) || array_is_list($value)
            || array_diff(array_keys($value), ['enabled', 'baseUrl', 'username', 'passwordCiphertext', 'defaultImportMode',
                'transcodeFormat', 'transcodeBitrateKbps', 'cleanupPolicy', 'cleanupDelayHours',
                'minimumSeedTimeHours', 'monitorMode']) !== []
            || count($value) !== 11 || !is_bool($value['enabled'] ?? null)
            || !is_string($value['baseUrl'] ?? null) || !is_string($value['username'] ?? null)
            || (!is_null($value['passwordCiphertext'] ?? null) && !is_string($value['passwordCiphertext']))
            || !in_array($value['defaultImportMode'] ?? null, ['copy', 'move', 'hardlink', 'symlink', 'transcode'], true)
            || !is_string($value['transcodeFormat'] ?? null)
            || (!is_int($value['transcodeBitrateKbps'] ?? null)
                && !is_null($value['transcodeBitrateKbps'] ?? null))
            || !ResourceDownloadTranscodeProfile::accepts(
                $value['transcodeFormat'],
                $value['transcodeBitrateKbps'],
            )
            || !in_array($value['cleanupPolicy'] ?? null, ['never', 'after_import', 'after_delay', 'after_seeding'], true)
            || !is_int($value['cleanupDelayHours'] ?? null) || $value['cleanupDelayHours'] < 1 || $value['cleanupDelayHours'] > 8760
            || !is_int($value['minimumSeedTimeHours'] ?? null) || $value['minimumSeedTimeHours'] < 1 || $value['minimumSeedTimeHours'] > 8760
            || ($value['monitorMode'] ?? null) !== 'qbittorrent_api') {
            throw new QbittorrentSettingsUnavailable();
        }
        try {
            $baseUrl = $this->normalizeBaseUrl($value['baseUrl'], $value['enabled']);
            $username = $this->normalizeUsername($value['username'], $value['enabled']);
        } catch (QbittorrentSettingsInvalid) {
            throw new QbittorrentSettingsUnavailable();
        }
        return [
            'enabled' => $value['enabled'],
            'baseUrl' => $baseUrl,
            'username' => $username,
            'passwordCiphertext' => $value['passwordCiphertext'],
            'defaultImportMode' => $value['defaultImportMode'],
            'transcodeFormat' => $value['transcodeFormat'],
            'transcodeBitrateKbps' => $value['transcodeBitrateKbps'],
            'cleanupPolicy' => $value['cleanupPolicy'],
            'cleanupDelayHours' => $value['cleanupDelayHours'],
            'minimumSeedTimeHours' => $value['minimumSeedTimeHours'],
            'monitorMode' => $value['monitorMode'],
            'version' => (int) $row->version,
            'updatedAt' => (string) $row->updated_at,
        ];
    }

    /** 校验外部 WebUI 根地址；关闭时允许空地址以清除配置。 */
    private function normalizeBaseUrl(string $input, bool $enabled): string
    {
        $url = rtrim(trim($input), '/');
        if ($url === '') {
            if ($enabled) throw new QbittorrentSettingsInvalid();
            return '';
        }
        $parts = parse_url($url);
        $decodedPath = is_array($parts) ? rawurldecode((string) ($parts['path'] ?? '')) : '';
        if (strlen($url) > 2048 || preg_match('/[\x00-\x20\x7F]/', $url) === 1 || !is_array($parts)
            || !in_array($parts['scheme'] ?? null, ['http', 'https'], true)
            || !is_string($parts['host'] ?? null) || $parts['host'] === ''
            || isset($parts['user']) || isset($parts['pass']) || isset($parts['query']) || isset($parts['fragment'])
            || (isset($parts['port']) && ((int) $parts['port'] < 1 || (int) $parts['port'] > 65535))
            || preg_match('~(^|/)(?:\.|\.\.)(?:/|$)~', $decodedPath) === 1) {
            throw new QbittorrentSettingsInvalid();
        }
        return $url;
    }

    /** 校验 WebUI 登录账号；关闭时允许空账号以清除配置。 */
    private function normalizeUsername(string $input, bool $enabled): string
    {
        $username = trim($input);
        if ($username === '') {
            if ($enabled) throw new QbittorrentSettingsInvalid();
            return '';
        }
        if (strlen($username) > 128 || !mb_check_encoding($username, 'UTF-8')
            || preg_match('/[\x00-\x1F\x7F]/u', $username) === 1) {
            throw new QbittorrentSettingsInvalid();
        }
        return $username;
    }
}

/** 外部 qBittorrent 设置字段、地址、账号或密码不符合固定契约。 */
final class QbittorrentSettingsInvalid extends \RuntimeException {}

/** 外部 qBittorrent 设置的 expectedVersion 已过期。 */
final class QbittorrentSettingsConflict extends \RuntimeException {}

/** 外部 qBittorrent 设置缺失、损坏或无法解密。 */
final class QbittorrentSettingsUnavailable extends \RuntimeException {}
