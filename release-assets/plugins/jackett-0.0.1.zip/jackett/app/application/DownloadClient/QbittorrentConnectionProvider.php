<?php

declare(strict_types=1);

namespace plugin\jackett\app\application\DownloadClient;

/**
 * 向状态探测器提供 qBittorrent 脱敏快照和一次性明文连接。
 *
 * 生产实现从版本化设置读取并解密密码；测试实现可提供内存夹具。调用方不得缓存 connection 返回值，
 * 且必须在请求结束后清理 password。该边界不提供下载路径修改、任务创建或数据库写入能力。
 */
interface QbittorrentConnectionProvider
{
    /** @return array{enabled:bool,baseUrl:string,username:string,configured:bool,downloadDirectory:string,category:string,defaultImportMode:string,cleanupPolicy:string,cleanupDelayHours:int,minimumSeedTimeHours:int,monitorMode:string,version:int,updatedAt:string} */
    public function snapshot(): array;

    /** @return array{baseUrl:string,username:string,password:string} */
    public function connection(): array;
}
