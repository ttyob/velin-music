<?php

declare(strict_types=1);

namespace plugin\jackett\app\application\DownloadClient;

use app\infrastructure\Audit\AuditLogger;
use Illuminate\Database\QueryException;
use stdClass;
use Symfony\Component\Uid\Ulid;
use support\Db;

/**
 * 管理 Jackett 结果到 qBittorrent 下载任务的授权、幂等命令与后台投影。
 *
 * 创建任务要求实时后台 actor、属于该 actor 且未过期的搜索租约，以及可管理的 active 可写音乐库。
 * 下载引用密文只从租约复制到任务，浏览器不能提交 URL、磁力、hash、保存目录或分类。租约唯一索引使
 * 同一结果的重复点击返回原任务；默认转码档案和清理策略在创建时固化，之后设置变化不追溯。任务、
 * 审计和引用转移在一个短事务提交，不在写锁内访问网络或文件。
 */
final readonly class ResourceDownloadJobService
{
    public function __construct(private AuditLogger $audit = new AuditLogger())
    {
    }

    /** @return array{libraries:list<array{id:string,name:string}>,defaultImportMode:string,importModes:list<string>,transcodeProfile:array{format:string,bitrateKbps:?int},monitorMode:string} */
    public function options(array $actor): array
    {
        $query = Db::table('music_libraries as libraries')->where('libraries.status', 'active')
            ->whereIn('libraries.source_type', ['local', 'webdav', 'onedrive', 'google_drive']);
        if (!($actor['isSuperAdmin'] ?? false)) {
            $query->join('library_user_grants as grant', function ($join) use ($actor): void {
                $join->on('grant.library_id', '=', 'libraries.id')
                    ->where('grant.user_id', '=', (string) $actor['id'])
                    ->where('grant.access_level', '=', 'manage');
            });
        }
        $libraries = $query->orderBy('libraries.name')->get(['libraries.id', 'libraries.name', 'libraries.source_type'])
            ->map(static fn (stdClass $row): array => ['id' => (string) $row->id, 'name' => (string) $row->name,
                'sourceType' => (string) $row->source_type])->all();
        $settings = (new QbittorrentSettingsService())->snapshot();
        return [
            'libraries' => $libraries,
            'defaultImportMode' => $settings['defaultImportMode'],
            'importModes' => ['copy', 'move', 'hardlink', 'symlink', 'transcode'],
            'transcodeProfile' => [
                'format' => $settings['transcodeFormat'],
                'bitrateKbps' => $settings['transcodeBitrateKbps'],
            ],
            'monitorMode' => 'qbittorrent_api',
        ];
    }

    /**
     * 创建一个耐久任务，重复 leaseId 返回既有任务。
     *
     * expected lease 所有者和当前 Session actor 必须一致；音乐库管理授权在事务内复验。统一核心 API
     * 不传插件私有参数时使用版本化设置中的默认入库方式，插件自有后台仍可传五种白名单模式。新任务
     * 不接受单任务源文件保护，转码产物独立发布后是否删除下载源统一服从当前清理配置；软链接仍把本
     * 任务清理策略强制收口为 never，防止删除其长期依赖。transcode 任务额外固化当前格式/码率；其他
     * 模式把两列保持 null。所有任务固化
     * 当前清理策略与小时参数，之后配置变化不追溯。关闭或未完整配置的下载器失败关闭，避免队列积累
     * 无法执行的命令。唯一冲突只可能来自并发重复点击，此时安全读取原任务作为幂等成功。
     */
    public function create(
        string $leaseId,
        string $libraryId,
        ?string $importMode,
        array $actor,
        string $requestId,
    ): array
    {
        foreach ([$leaseId, $libraryId] as $id) {
            if (preg_match('/^[0-9A-HJKMNP-TV-Z]{26}$/D', $id) !== 1) throw new ResourceDownloadInvalid();
        }
        $settings = (new QbittorrentSettingsService())->snapshot();
        $importMode ??= (string) $settings['defaultImportMode'];
        if (!in_array($importMode, ['copy', 'move', 'hardlink', 'symlink', 'transcode'], true)) {
            throw new ResourceDownloadInvalid();
        }
        if (!$settings['enabled'] || !$settings['configured']) throw new QbittorrentSettingsUnavailable();
        $cleanupPolicy = ResourceDownloadCleanupPolicyResolver::resolve(
            $importMode,
            (string) $settings['cleanupPolicy'],
            false,
        );
        $jobId = (string) new Ulid();
        $now = gmdate('Y-m-d\TH:i:s\Z');
        try {
            return Db::transaction(function () use ($leaseId, $libraryId, $importMode,
                $cleanupPolicy, $settings, $actor, $requestId, $jobId, $now): array {
                /** @var stdClass|null $existing */
                $existing = Db::table('resource_download_jobs')->where('plugin_key', 'jackett')
                    ->where('search_lease_id', $leaseId)->first(['id']);
                if ($existing instanceof stdClass) return $this->find((string) $existing->id);

                /** @var stdClass|null $lease */
                $lease = Db::table('resource_search_result_leases')->where('id', $leaseId)
                    ->where('plugin_key', 'jackett')
                    ->where('actor_id', (string) $actor['id'])->where('expires_at', '>=', $now)->first();
                if (!$lease instanceof stdClass || !$this->manageableWritableLibraryExists($libraryId, $actor)
                    || !$this->libraryAcceptsMode($libraryId, $importMode)) {
                    throw new ResourceDownloadNotFound();
                }
                Db::table('resource_download_jobs')->insert([
                    'id' => $jobId, 'plugin_key' => 'jackett', 'search_lease_id' => $leaseId,
                    'requested_by' => (string) $actor['id'],
                    'library_id' => $libraryId, 'title' => (string) $lease->title,
                    'indexer' => (string) $lease->indexer, 'expected_size_bytes' => $lease->size_bytes,
                    // 该列只为兼容已存在的历史任务；新任务统一由全局清理策略决定是否保留下载源。
                    'import_mode' => $importMode, 'transcode_keep_source' => 0,
                    'transcode_format' => $importMode === 'transcode' ? $settings['transcodeFormat'] : null,
                    'transcode_bitrate_kbps' => $importMode === 'transcode'
                        ? $settings['transcodeBitrateKbps'] : null,
                    'monitor_mode' => 'qbittorrent_api', 'cleanup_policy' => $cleanupPolicy,
                    'cleanup_delay_hours' => $settings['cleanupDelayHours'],
                    'minimum_seed_time_hours' => $settings['minimumSeedTimeHours'],
                    'cleanup_status' => $cleanupPolicy === 'never' ? 'not_required' : 'pending',
                    'cleanup_due_at' => null, 'cleanup_attempt' => 0, 'cleanup_error_code' => null,
                    'cleanup_finished_at' => null, 'status' => 'queued',
                    'download_ref_ciphertext' => (string) $lease->download_ref_ciphertext,
                    'torrent_hash_ciphertext' => null, 'progress_basis_points' => 0,
                    'downloaded_bytes' => 0, 'total_bytes' => 0, 'speed_bytes_per_second' => 0,
                    'eta_seconds' => null, 'downloader_state' => null, 'imported_files' => 0,
                    'scan_job_id' => null, 'error_code' => null, 'worker_id' => null, 'attempt' => 0,
                    'heartbeat_at' => null, 'started_at' => null, 'finished_at' => null,
                    'request_id' => $requestId, 'created_at' => $now, 'updated_at' => $now,
                ]);
                $this->audit->record((string) $actor['id'], 'resource.download.queue', 'resource_download_job',
                    $jobId, 'success', $requestId, ['libraryId' => $libraryId, 'importMode' => $importMode,
                        'transcodeProfile' => $importMode === 'transcode' ? [
                            'format' => $settings['transcodeFormat'],
                            'bitrateKbps' => $settings['transcodeBitrateKbps'],
                        ] : null,
                        'cleanupPolicy' => $cleanupPolicy]);
                return $this->find($jobId);
            });
        } catch (QueryException $exception) {
            if (str_contains(strtolower($exception->getMessage()), 'unique')) {
                /** @var stdClass|null $row */
                $row = Db::table('resource_download_jobs')->where('plugin_key', 'jackett')
                    ->where('search_lease_id', $leaseId)->first(['id']);
                if ($row instanceof stdClass) return $this->find((string) $row->id);
            }
            throw $exception;
        }
    }

    /**
     * 把订阅 Worker 选中的内部结果直接原子登记为下载任务。
     *
     * 前置条件：subscription 已由后台服务校验，item 只来自同一插件搜索解析器，downloadReference 不得
     * 进入浏览器。事务同时创建加密租约、发现账本和 queued 任务；同一 subscription/fingerprint 重复
     * 调用只返回既有任务或 null，不重复访问 qBittorrent。目标库授权和下载器配置在提交前重新复验，
     * 任务快照固定当前入库/清理策略，后续设置变化不追溯已排队任务。
     *
     * @param stdClass $subscription 已锁定的订阅行
     * @param array<string,mixed> $item 仅允许来自 JackettSearchService::searchForSubscription 的内部条目
     * @return array<string,mixed>|null 新建或既有下载任务；已发现但不可重复提交时返回 null
     */
    public function createFromSubscription(
        stdClass $subscription,
        array $item,
        array $actor,
        string $requestId,
    ): ?array {
        $reference = $item['downloadReference'] ?? null;
        $fingerprint = $item['fingerprint'] ?? null;
        if (!is_string($reference) || $reference === '' || !is_string($fingerprint)
            || preg_match('/^[a-f0-9]{64}$/D', $fingerprint) !== 1) {
            throw new ResourceDownloadInvalid();
        }
        $libraryId = (string) $subscription->library_id;
        $importMode = (string) $subscription->import_mode;
        if (!in_array($importMode, ['copy', 'move', 'hardlink', 'symlink', 'transcode'], true)
            || !$this->manageableWritableLibraryExists($libraryId, $actor)
            || !$this->libraryAcceptsMode($libraryId, $importMode)) {
            throw new ResourceDownloadNotFound();
        }
        $settings = (new QbittorrentSettingsService())->snapshot();
        if (!$settings['enabled'] || !$settings['configured']) throw new QbittorrentSettingsUnavailable();
        // 订阅策略属于规则本身；qBittorrent 全局策略只用于手动下载，不能覆盖订阅快照。
        $configuredCleanupPolicy = isset($subscription->cleanup_policy)
            ? (string) $subscription->cleanup_policy : 'never';
        $cleanupDelayHours = isset($subscription->cleanup_delay_hours)
            ? (int) $subscription->cleanup_delay_hours : 24;
        $minimumSeedTimeHours = isset($subscription->minimum_seed_time_hours)
            ? (int) $subscription->minimum_seed_time_hours : 72;
        $cleanupPolicy = ResourceDownloadCleanupPolicyResolver::resolve(
            $importMode, $configuredCleanupPolicy, false,
        );
        $now = gmdate('Y-m-d\TH:i:s\Z');
        $jobId = (string) new Ulid();
        $leaseId = (string) new Ulid();
        $itemId = (string) new Ulid();

        try {
            return Db::transaction(function () use (
                $subscription, $item, $actor, $requestId, $reference, $fingerprint, $libraryId,
                $importMode, $settings, $cleanupPolicy, $cleanupDelayHours, $minimumSeedTimeHours,
                $now, $jobId, $leaseId, $itemId,
            ): ?array {
                /** @var stdClass|null $known */
                $known = Db::table('jackett_subscription_items')
                    ->where('subscription_id', (string) $subscription->id)
                    ->where('fingerprint', $fingerprint)->first(['id', 'job_id', 'status']);
                if ($known instanceof stdClass) {
                    if (is_string($known->job_id) && $known->job_id !== '') return $this->find((string) $known->job_id);
                    return null;
                }
                // 不同订阅可能命中同一颗种子。InfoHash 指纹在搜索层已跨索引器稳定化，
                // 这里再以任务事实表复核，避免两个规则分别向 qBittorrent 提交同一个 torrent。
                /** @var stdClass|null $duplicate */
                $duplicate = Db::table('resource_download_jobs as jobs')
                    ->join('jackett_subscription_items as duplicate_items',
                        'duplicate_items.id', '=', 'jobs.subscription_item_id')
                    ->where('jobs.plugin_key', 'jackett')
                    ->where('duplicate_items.fingerprint', $fingerprint)
                    ->whereIn('jobs.status', ['queued', 'submitting', 'downloading', 'importing', 'succeeded'])
                    ->orderByDesc('jobs.created_at')->first(['jobs.id', 'jobs.status']);
                if ($duplicate instanceof stdClass) {
                    Db::table('jackett_subscription_items')->insert([
                        'id' => $itemId, 'subscription_id' => (string) $subscription->id,
                        'fingerprint' => $fingerprint, 'title' => (string) $item['title'],
                        'indexer' => (string) $item['indexer'], 'size_bytes' => $item['sizeBytes'] ?? null,
                        'seeders' => $item['seeders'] ?? null, 'published_at' => $item['publishedAt'] ?? null,
                        'status' => 'skipped', 'job_id' => (string) $duplicate->id,
                        'error_code' => 'JACKETT_TORRENT_DUPLICATE',
                        'discovered_at' => $now, 'updated_at' => $now,
                    ]);
                    return null;
                }
                Db::table('jackett_subscription_items')->insert([
                    'id' => $itemId, 'subscription_id' => (string) $subscription->id,
                    'fingerprint' => $fingerprint, 'title' => (string) $item['title'],
                    'indexer' => (string) $item['indexer'], 'size_bytes' => $item['sizeBytes'] ?? null,
                    'seeders' => $item['seeders'] ?? null, 'published_at' => $item['publishedAt'] ?? null,
                    'status' => 'discovered', 'job_id' => null, 'error_code' => null,
                    'discovered_at' => $now, 'updated_at' => $now,
                ]);
                Db::table('resource_search_result_leases')->insert([
                    'id' => $leaseId, 'plugin_key' => 'jackett', 'actor_id' => (string) $actor['id'],
                    'title' => (string) $item['title'], 'indexer' => (string) $item['indexer'],
                    'size_bytes' => $item['sizeBytes'] ?? null,
                    'download_ref_ciphertext' => (new ResourceDownloadCipher())->encrypt('reference', $reference),
                    'expires_at' => gmdate('Y-m-d\TH:i:s\Z', time() + 900), 'created_at' => $now,
                ]);
                Db::table('resource_download_jobs')->insert([
                    'id' => $jobId, 'plugin_key' => 'jackett',
                    'subscription_id' => (string) $subscription->id, 'subscription_item_id' => $itemId,
                    'search_lease_id' => $leaseId, 'requested_by' => (string) $actor['id'],
                    'library_id' => $libraryId, 'title' => (string) $item['title'],
                    'indexer' => (string) $item['indexer'], 'expected_size_bytes' => $item['sizeBytes'] ?? null,
                    'import_mode' => $importMode, 'transcode_keep_source' => 0,
                    'transcode_format' => $importMode === 'transcode' ? $settings['transcodeFormat'] : null,
                    'transcode_bitrate_kbps' => $importMode === 'transcode' ? $settings['transcodeBitrateKbps'] : null,
                    'monitor_mode' => 'qbittorrent_api', 'cleanup_policy' => $cleanupPolicy,
                    'cleanup_delay_hours' => $cleanupDelayHours,
                    'minimum_seed_time_hours' => $minimumSeedTimeHours,
                    'cleanup_status' => $cleanupPolicy === 'never' ? 'not_required' : 'pending',
                    'cleanup_due_at' => null, 'cleanup_attempt' => 0, 'cleanup_error_code' => null,
                    'cleanup_finished_at' => null, 'status' => 'queued', 'download_ref_ciphertext' => Db::table('resource_search_result_leases')->where('id', $leaseId)->value('download_ref_ciphertext'),
                    'torrent_hash_ciphertext' => null, 'progress_basis_points' => 0, 'downloaded_bytes' => 0,
                    'total_bytes' => 0, 'speed_bytes_per_second' => 0, 'eta_seconds' => null,
                    'downloader_state' => null, 'imported_files' => 0, 'scan_job_id' => null,
                    'error_code' => null, 'worker_id' => null, 'attempt' => 0, 'heartbeat_at' => null,
                    'started_at' => null, 'finished_at' => null, 'request_id' => $requestId,
                    'created_at' => $now, 'updated_at' => $now,
                ]);
                Db::table('jackett_subscription_items')->where('id', $itemId)->update([
                    'status' => 'queued', 'job_id' => $jobId, 'updated_at' => $now,
                ]);
                $this->audit->record((string) $actor['id'], 'jackett.subscription.queue', 'resource_download_job',
                    $jobId, 'success', $requestId, ['subscriptionId' => (string) $subscription->id]);
                return $this->find($jobId);
            });
        } catch (QueryException $exception) {
            if (str_contains(strtolower($exception->getMessage()), 'unique')) {
                $existing = Db::table('jackett_subscription_items')->where('subscription_id', (string) $subscription->id)
                    ->where('fingerprint', $fingerprint)->first(['job_id']);
                if ($existing instanceof stdClass && is_string($existing->job_id) && $existing->job_id !== '') {
                    return $this->find((string) $existing->job_id);
                }
                return null;
            }
            throw $exception;
        }
    }

    /** @return array{jobs:list<array<string,mixed>>} */
    public function list(int $limit = 50): array
    {
        $limit = max(1, min(100, $limit));
        /** @var list<stdClass> $rows */
        $rows = $this->query()->orderByDesc('jobs.created_at')->limit($limit)->get($this->columns())->all();
        return ['jobs' => array_map(fn (stdClass $row): array => $this->map($row), $rows)];
    }

    /** @return array<string,mixed> */
    public function find(string $jobId): array
    {
        /** @var stdClass|null $row */
        $row = $this->query()->where('jobs.id', $jobId)->first($this->columns());
        if (!$row instanceof stdClass) throw new ResourceDownloadNotFound();
        return $this->map($row);
    }

    /** 复验目标库来源类型与 manage 授权；远端协议凭据只由核心发布器读取。 */
    private function manageableWritableLibraryExists(string $libraryId, array $actor): bool
    {
        $query = Db::table('music_libraries as libraries')->where('libraries.id', $libraryId)
            ->where('libraries.status', 'active')
            ->whereIn('libraries.source_type', ['local', 'webdav', 'onedrive', 'google_drive']);
        if (!($actor['isSuperAdmin'] ?? false)) {
            $query->join('library_user_grants as grant', function ($join) use ($actor): void {
                $join->on('grant.library_id', '=', 'libraries.id')->where('grant.user_id', '=', (string) $actor['id'])
                    ->where('grant.access_level', '=', 'manage');
            });
        }
        return $query->exists();
    }

    /** hardlink/symlink 依赖本地 inode 或长期本地路径，远程库必须在任务创建前拒绝。 */
    private function libraryAcceptsMode(string $libraryId, string $mode): bool
    {
        $sourceType = Db::table('music_libraries')->where('id', $libraryId)->where('status', 'active')
            ->value('source_type');
        return is_string($sourceType) && ($sourceType === 'local' || !in_array($mode, ['hardlink', 'symlink'], true));
    }

    private function query()
    {
        return Db::table('resource_download_jobs as jobs')
            ->where('jobs.plugin_key', 'jackett')
            ->join('music_libraries as libraries', 'libraries.id', '=', 'jobs.library_id');
    }

    /** @return list<string> */
    private function columns(): array
    {
        $columns = ['jobs.id', 'jobs.title', 'jobs.indexer', 'jobs.import_mode', 'jobs.transcode_keep_source',
            'jobs.transcode_format', 'jobs.transcode_bitrate_kbps',
            'jobs.monitor_mode', 'jobs.cleanup_policy', 'jobs.cleanup_status', 'jobs.cleanup_due_at',
            'jobs.cleanup_error_code', 'jobs.cleanup_finished_at', 'jobs.status',
            'jobs.progress_basis_points', 'jobs.downloaded_bytes', 'jobs.total_bytes', 'jobs.speed_bytes_per_second',
            'jobs.eta_seconds', 'jobs.downloader_state', 'jobs.imported_files', 'jobs.scan_job_id', 'jobs.error_code',
            'jobs.created_at', 'jobs.updated_at', 'jobs.finished_at', 'libraries.id as library_id',
            'libraries.name as library_name'];
        if (Db::connection()->getSchemaBuilder()->hasColumn('resource_download_jobs', 'subscription_id')) {
            $columns[] = 'jobs.subscription_id';
        }
        return $columns;
    }

    /** 浏览器投影严格排除租约、下载引用、hash、内容路径、Worker 和 requestId。 */
    private function map(stdClass $row): array
    {
        return [
            'id' => (string) $row->id, 'title' => (string) $row->title, 'indexer' => (string) $row->indexer,
            'library' => ['id' => (string) $row->library_id, 'name' => (string) $row->library_name],
            'importMode' => (string) $row->import_mode, 'monitorMode' => (string) $row->monitor_mode,
            'transcodeKeepSource' => (int) $row->transcode_keep_source === 1,
            'transcodeProfile' => $row->import_mode === 'transcode' ? [
                'format' => (string) $row->transcode_format,
                'bitrateKbps' => $row->transcode_bitrate_kbps === null
                    ? null : (int) $row->transcode_bitrate_kbps,
            ] : null,
            'cleanupPolicy' => (string) $row->cleanup_policy,
            'cleanupStatus' => (string) $row->cleanup_status,
            'cleanupDueAt' => $row->cleanup_due_at === null ? null : (string) $row->cleanup_due_at,
            'cleanupErrorCode' => $row->cleanup_error_code === null ? null : (string) $row->cleanup_error_code,
            'cleanupFinishedAt' => $row->cleanup_finished_at === null ? null : (string) $row->cleanup_finished_at,
            'status' => (string) $row->status, 'progress' => (int) $row->progress_basis_points / 100,
            'downloadedBytes' => (int) $row->downloaded_bytes, 'totalBytes' => (int) $row->total_bytes,
            'speedBytesPerSecond' => (int) $row->speed_bytes_per_second,
            'etaSeconds' => $row->eta_seconds === null ? null : (int) $row->eta_seconds,
            'downloaderState' => $row->downloader_state === null ? null : (string) $row->downloader_state,
            'importedFiles' => (int) $row->imported_files,
            'scanJobId' => $row->scan_job_id === null ? null : (string) $row->scan_job_id,
            'errorCode' => $row->error_code === null ? null : (string) $row->error_code,
            'createdAt' => (string) $row->created_at, 'updatedAt' => (string) $row->updated_at,
            'finishedAt' => $row->finished_at === null ? null : (string) $row->finished_at,
        ];
    }
}

final class ResourceDownloadInvalid extends \RuntimeException {}
final class ResourceDownloadNotFound extends \RuntimeException {}
