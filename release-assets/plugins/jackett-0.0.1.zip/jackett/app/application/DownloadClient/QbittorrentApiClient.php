<?php

declare(strict_types=1);

namespace plugin\jackett\app\application\DownloadClient;

use GuzzleHttp\Client;
use GuzzleHttp\ClientInterface;
use Psr\Http\Message\ResponseInterface;
use Throwable;

/**
 * 使用 WebUI API 提交并轮询 Velin Music 自有 qBittorrent 任务。
 *
 * 每个任务用 `velin-job-{ULID}` 标签隔离，保存目录和分类来自服务端常量；浏览器无法覆盖。submit 在
 * 添加前先按标签查询，因此 HTTP 重试、Worker 崩溃恢复或 qBittorrent 延迟响应不会创建重复任务。
 * 下载引用、Cookie、hash 和内容路径只存在于调用栈，不写日志或异常。所有请求禁用环境代理和重定向，
 * 使用有界超时与响应体；登录兼容 qBittorrent 4.x 的 200/Ok. 和 5.2 的 204/空正文协议。
 */
final readonly class QbittorrentApiClient implements QbittorrentGateway
{
    public function __construct(
        private ?ClientInterface $http = null,
        private QbittorrentConnectionProvider $settings = new QbittorrentSettingsService(),
    ) {
    }

    public function submit(string $reference, string $jobId): void
    {
        $this->assertJobId($jobId);
        $scheme = strtolower((string) parse_url($reference, PHP_URL_SCHEME));
        if (!in_array($scheme, ['http', 'https', 'magnet'], true) || strlen($reference) > 8192
            || preg_match('/[\x00-\x20\x7F]/', $reference) === 1) {
            throw new QbittorrentUnavailable('DOWNLOAD_REFERENCE_INVALID');
        }
        $this->withSession(function (string $baseUrl, string $cookie) use ($reference, $jobId): void {
            $this->ensureCategory($baseUrl, $cookie);
            if ($this->taskInSession($baseUrl, $cookie, $jobId) !== null) return;
            $response = $this->request('POST', $baseUrl, '/api/v2/torrents/add', [
                'headers' => ['Cookie' => $cookie],
                'form_params' => [
                    'urls' => $reference,
                    'savepath' => QbittorrentSettingsService::DOWNLOAD_DIRECTORY,
                    'category' => QbittorrentSettingsService::CATEGORY,
                    'tags' => $this->tag($jobId),
                    'paused' => 'false',
                ],
                'timeout' => 20.0,
            ]);
            $body = trim($this->body($response, 256));
            if ($response->getStatusCode() !== 200 || !in_array($body, ['', 'Ok.'], true)) {
                throw new QbittorrentUnavailable('QBITTORRENT_ADD_FAILED');
            }
        });
    }

    /**
     * 幂等确保固定分类绑定固定下载根。
     *
     * qBittorrent 对不存在分类的 add 行为随版本不同，可能静默留下空分类；这会破坏后续删除前的归属
     * 复验。固定名称和路径均来自服务端常量，200 表示创建成功，409 只可能表示该合法固定分类已存在。
     * 其他响应失败关闭，不继续提交可能无法安全清理的新任务。
     */
    private function ensureCategory(string $baseUrl, string $cookie): void
    {
        $response = $this->request('POST', $baseUrl, '/api/v2/torrents/createCategory', [
            'headers' => ['Cookie' => $cookie],
            'form_params' => [
                'category' => QbittorrentSettingsService::CATEGORY,
                'savePath' => QbittorrentSettingsService::DOWNLOAD_DIRECTORY,
            ],
        ]);
        if (!in_array($response->getStatusCode(), [200, 409], true)) {
            throw new QbittorrentUnavailable('QBITTORRENT_CATEGORY_FAILED');
        }
        $this->body($response, 128);
    }

    public function task(string $jobId): ?array
    {
        $this->assertJobId($jobId);
        return $this->withSession(fn (string $baseUrl, string $cookie): ?array =>
            $this->taskInSession($baseUrl, $cookie, $jobId));
    }

    public function pause(string $hash): void
    {
        if (preg_match('/^[a-f0-9]{40}$/D', strtolower($hash)) !== 1) {
            throw new QbittorrentUnavailable('QBITTORRENT_PROTOCOL_INVALID');
        }
        $this->withSession(function (string $baseUrl, string $cookie) use ($hash): void {
            $response = $this->request('POST', $baseUrl, '/api/v2/torrents/stop', [
                'headers' => ['Cookie' => $cookie],
                'form_params' => ['hashes' => strtolower($hash)],
            ]);
            if ($response->getStatusCode() === 404) {
                // qBittorrent 4.x 使用 pause，5.x 将其改名为 stop；两者都只作用于精确 hash。
                $response = $this->request('POST', $baseUrl, '/api/v2/torrents/pause', [
                    'headers' => ['Cookie' => $cookie],
                    'form_params' => ['hashes' => strtolower($hash)],
                ]);
            }
            if (!in_array($response->getStatusCode(), [200, 204], true)) {
                throw new QbittorrentUnavailable('QBITTORRENT_PAUSE_FAILED');
            }
            $this->body($response, 64);
        });
    }

    /**
     * 删除一条已成功入库任务对应的 torrent 及数据。
     *
     * 调用方提供的 hash 来自任务密文或刚读取的下载器事实，但本方法仍在同一登录会话内按服务端生成的
     * 标签重新查询，并复验固定分类与精确 hash。任务已由外部删除时按幂等成功；不匹配时失败关闭，绝不
     * 把 hash 直接当作授权。WebUI 删除成功后数据不可由 Velin 回滚，因此只能由上层成功入库状态机调用。
     */
    public function remove(string $jobId, string $hash): void
    {
        $this->assertJobId($jobId);
        $hash = strtolower($hash);
        if (preg_match('/^[a-f0-9]{40}$/D', $hash) !== 1) {
            throw new QbittorrentUnavailable('QBITTORRENT_PROTOCOL_INVALID');
        }
        $this->withSession(function (string $baseUrl, string $cookie) use ($jobId, $hash): void {
            $task = $this->taskInSession($baseUrl, $cookie, $jobId);
            if ($task === null) return;
            if (!hash_equals($task['hash'], $hash)) {
                throw new QbittorrentUnavailable('QBITTORRENT_TASK_MISMATCH');
            }
            $response = $this->request('POST', $baseUrl, '/api/v2/torrents/delete', [
                'headers' => ['Cookie' => $cookie],
                'form_params' => ['hashes' => $hash, 'deleteFiles' => 'true'],
            ]);
            if (!in_array($response->getStatusCode(), [200, 204], true)) {
                throw new QbittorrentUnavailable('QBITTORRENT_DELETE_FAILED');
            }
            $this->body($response, 64);
        });
    }

    /** @template T @param callable(string,string):T $operation @return T */
    private function withSession(callable $operation): mixed
    {
        $connection = $this->settings->connection();
        $password = $connection['password'];
        $cookie = null;
        try {
            $login = $this->request('POST', $connection['baseUrl'], '/api/v2/auth/login', [
                'form_params' => ['username' => $connection['username'], 'password' => $password],
            ]);
            $status = $login->getStatusCode();
            $body = $this->body($login, 32);
            if (!(($status === 200 && trim($body) === 'Ok.') || ($status === 204 && $body === ''))) {
                throw new QbittorrentUnavailable($status === 403 ? 'QBITTORRENT_AUTH_FAILED' : 'QBITTORRENT_UPSTREAM_FAILED');
            }
            $cookie = $this->sessionCookie($login);
            return $operation($connection['baseUrl'], $cookie);
        } finally {
            if (is_string($cookie)) $this->logout($connection['baseUrl'], $cookie);
            sodium_memzero($password);
        }
    }

    /** @return array{hash:string,name:string,state:string,progress:float,downloaded:int,total:int,speed:int,eta:?int,contentPath:string,seedingTimeSeconds:int}|null */
    private function taskInSession(string $baseUrl, string $cookie, string $jobId): ?array
    {
        $response = $this->request('GET', $baseUrl, '/api/v2/torrents/info', [
            'headers' => ['Cookie' => $cookie],
            'query' => ['tag' => $this->tag($jobId)],
        ]);
        if ($response->getStatusCode() !== 200) throw new QbittorrentUnavailable('QBITTORRENT_UPSTREAM_FAILED');
        try {
            $rows = json_decode($this->body($response, 2_097_152), true, 32, JSON_THROW_ON_ERROR);
        } catch (\JsonException) {
            throw new QbittorrentUnavailable('QBITTORRENT_PROTOCOL_INVALID');
        }
        if (!is_array($rows) || !array_is_list($rows) || count($rows) > 1) {
            throw new QbittorrentUnavailable('QBITTORRENT_PROTOCOL_INVALID');
        }
        if ($rows === []) return null;
        $row = $rows[0];
        if (!is_array($row) || !is_string($row['hash'] ?? null) || !is_string($row['name'] ?? null)
            || !is_string($row['state'] ?? null) || !is_numeric($row['progress'] ?? null)
            || !is_numeric($row['downloaded'] ?? null) || !is_numeric($row['size'] ?? null)
            || !is_numeric($row['dlspeed'] ?? null) || !is_numeric($row['eta'] ?? null)
            || !is_string($row['content_path'] ?? null) || !is_numeric($row['seeding_time'] ?? null)
            || !is_string($row['category'] ?? null)) {
            throw new QbittorrentUnavailable('QBITTORRENT_PROTOCOL_INVALID');
        }
        $hash = strtolower($row['hash']);
        $progress = (float) $row['progress'];
        $eta = (int) $row['eta'];
        if (preg_match('/^[a-f0-9]{40}$/D', $hash) !== 1 || $progress < 0 || $progress > 1
            || (int) $row['downloaded'] < 0 || (int) $row['size'] < 0 || (int) $row['dlspeed'] < 0
            || (int) $row['seeding_time'] < 0 || $row['category'] !== QbittorrentSettingsService::CATEGORY
            || strlen($row['name']) > 500 || strlen($row['state']) > 64 || strlen($row['content_path']) > 4096) {
            throw new QbittorrentUnavailable('QBITTORRENT_PROTOCOL_INVALID');
        }
        return [
            'hash' => $hash,
            'name' => $row['name'],
            'state' => $row['state'],
            'progress' => $progress,
            'downloaded' => (int) $row['downloaded'],
            'total' => (int) $row['size'],
            'speed' => (int) $row['dlspeed'],
            'eta' => $eta >= 8_640_000 ? null : max(0, $eta),
            'contentPath' => $row['content_path'],
            'seedingTimeSeconds' => (int) $row['seeding_time'],
        ];
    }

    /** 发送受约束 WebUI 请求，并丢弃可能包含连接地址或秘密的第三方异常。 */
    private function request(string $method, string $baseUrl, string $path, array $options): ResponseInterface
    {
        try {
            $options['headers'] = ['Accept' => 'application/json, text/plain', 'Referer' => $baseUrl . '/']
                + (is_array($options['headers'] ?? null) ? $options['headers'] : []);
            return ($this->http ?? new Client(['http_errors' => false]))->request($method, $baseUrl . $path, $options + [
                'allow_redirects' => false, 'connect_timeout' => 2.0, 'timeout' => 10.0, 'proxy' => '',
            ]);
        } catch (Throwable) {
            throw new QbittorrentUnavailable('QBITTORRENT_CONNECTION_FAILED');
        }
    }

    private function body(ResponseInterface $response, int $maximumBytes): string
    {
        try {
            $body = $response->getBody();
            $value = $body->read($maximumBytes + 1);
        } catch (Throwable) {
            throw new QbittorrentUnavailable('QBITTORRENT_PROTOCOL_INVALID');
        }
        if (strlen($value) > $maximumBytes || (!$body->eof() && $value !== '')) {
            throw new QbittorrentUnavailable('QBITTORRENT_PROTOCOL_INVALID');
        }
        return $value;
    }

    private function sessionCookie(ResponseInterface $response): string
    {
        foreach ($response->getHeader('Set-Cookie') as $cookie) {
            if (preg_match('/^(SID|QBT_SID_([1-9][0-9]{0,4}))=([^;,\x00-\x20\x7F]{16,256})(?:;|$)/D', $cookie, $m) === 1
                && ($m[1] === 'SID' || (int) $m[2] <= 65535)) return $m[1] . '=' . $m[3];
        }
        throw new QbittorrentUnavailable('QBITTORRENT_PROTOCOL_INVALID');
    }

    private function logout(string $baseUrl, string $cookie): void
    {
        try {
            $this->request('POST', $baseUrl, '/api/v2/auth/logout', ['headers' => ['Cookie' => $cookie]]);
        } catch (QbittorrentUnavailable) {
            // 注销失败不改变已完成命令；Cookie 仍只存在于当前调用栈。
        }
    }

    private function assertJobId(string $jobId): void
    {
        if (preg_match('/^[0-9A-HJKMNP-TV-Z]{26}$/D', $jobId) !== 1) {
            throw new QbittorrentUnavailable('DOWNLOAD_JOB_INVALID');
        }
    }

    private function tag(string $jobId): string
    {
        return 'velin-job-' . strtolower($jobId);
    }
}
