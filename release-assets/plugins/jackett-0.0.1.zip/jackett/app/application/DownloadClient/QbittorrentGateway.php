<?php

declare(strict_types=1);

namespace plugin\jackett\app\application\DownloadClient;

/**
 * qBittorrent 下载命令边界，便于 Worker 契约测试替换网络实现。
 *
 * 实现必须使用固定分类、固定下载目录和每任务唯一标签；返回值只能留在后端领域层，不得直接作为 Web
 * API 投影。所有方法幂等：重复 submit 不得产生第二个 torrent，重复 pause 可视为成功；remove 必须先
 * 以任务标签和固定分类复验精确 hash，任务已不存在时也视为成功。
 */
interface QbittorrentGateway
{
    public function submit(string $reference, string $jobId): void;

    /** @return array{hash:string,name:string,state:string,progress:float,downloaded:int,total:int,speed:int,eta:?int,contentPath:string,seedingTimeSeconds:int}|null */
    public function task(string $jobId): ?array;

    public function pause(string $hash): void;

    public function remove(string $jobId, string $hash): void;
}
