<?php

declare(strict_types=1);

namespace plugin\jackett\app\application\DownloadClient;

use GuzzleHttp\Client;
use GuzzleHttp\ClientInterface;
use Psr\Http\Message\ResponseInterface;
use Throwable;

/**
 * 通过 qBittorrent WebUI API 执行只读连接探测。
 *
 * 服务只登录、读取应用版本并尽力注销，不提交种子、不改变保存目录或下载器偏好。用户名和解密密码仅
 * 存在于当前调用栈；SID Cookie、URL 和第三方响应不会进入 API、日志、审计或异常。请求禁用重定向与
 * 环境代理并设置短超时，防止外部下载器故障占用 Webman Worker。固定下载目录只作为 Velin 约定返回，
 * 状态成功不代表 qBittorrent 已正确挂载该目录，真正开放下载前仍需独立目录预检。
 */
final readonly class QbittorrentStatusService
{
    public function __construct(
        private ?ClientInterface $http = null,
        private QbittorrentConnectionProvider $settings = new QbittorrentSettingsService(),
    ) {
    }

    /**
     * 返回脱敏配置与即时可用性。
     *
     * 关闭或未配置时不访问网络；预期连接、认证和协议错误收敛为稳定 errorCode 并返回 200 状态快照，
     * 避免外部下载器阻断 Jackett 搜索页面。qBittorrent 旧版登录成功返回 `200/Ok.`，5.2 起返回
     * `204/空正文`；两种响应都必须同时提供规范 SID 才能继续。成功只证明 WebUI API 当前可登录和
     * 读取版本，不代表下载目录已经映射正确。
     *
     * @return array{bundled:false,enabled:bool,baseUrl:string,username:string,configured:bool,available:bool,remoteVersion:?string,downloadDirectory:string,category:string,defaultImportMode:string,transcodeFormat:string,transcodeBitrateKbps:?int,cleanupPolicy:string,cleanupDelayHours:int,minimumSeedTimeHours:int,monitorMode:string,version:int,updatedAt:string,errorCode:?string}
     */
    public function status(): array
    {
        $snapshot = $this->settings->snapshot();
        if (!$snapshot['enabled']) return $this->projection($snapshot, false, null, 'QBITTORRENT_DISABLED');
        if (!$snapshot['configured']) return $this->projection($snapshot, false, null, 'QBITTORRENT_NOT_CONFIGURED');

        $connection = $this->settings->connection();
        $password = $connection['password'];
        $sessionCookie = null;
        try {
            $login = $this->request('POST', $connection['baseUrl'], '/api/v2/auth/login', [
                'form_params' => ['username' => $connection['username'], 'password' => $password],
            ]);
            if ($login->getStatusCode() === 403) {
                throw new QbittorrentUnavailable('QBITTORRENT_AUTH_FAILED');
            }
            $loginStatus = $login->getStatusCode();
            if ($loginStatus === 200) {
                if (trim($this->body($login, 32)) !== 'Ok.') {
                    throw new QbittorrentUnavailable('QBITTORRENT_AUTH_FAILED');
                }
            } elseif ($loginStatus === 204) {
                if ($this->body($login, 1) !== '') {
                    throw new QbittorrentUnavailable('QBITTORRENT_PROTOCOL_INVALID');
                }
            } else {
                throw new QbittorrentUnavailable('QBITTORRENT_UPSTREAM_FAILED');
            }
            $sessionCookie = $this->sessionCookie($login);
            $versionResponse = $this->request('GET', $connection['baseUrl'], '/api/v2/app/version', [
                'headers' => ['Cookie' => $sessionCookie],
            ]);
            if ($versionResponse->getStatusCode() === 403) {
                throw new QbittorrentUnavailable('QBITTORRENT_AUTH_FAILED');
            }
            if ($versionResponse->getStatusCode() !== 200) {
                throw new QbittorrentUnavailable('QBITTORRENT_UPSTREAM_FAILED');
            }
            $version = trim($this->body($versionResponse, 128));
            if ($version === '' || preg_match('/^[A-Za-z0-9][A-Za-z0-9._+-]{0,63}$/D', $version) !== 1) {
                throw new QbittorrentUnavailable('QBITTORRENT_PROTOCOL_INVALID');
            }
            return $this->projection($snapshot, true, $version, null);
        } catch (QbittorrentUnavailable $failure) {
            return $this->projection($snapshot, false, null, $failure->errorCode);
        } finally {
            if (is_string($sessionCookie)) $this->logout($connection['baseUrl'], $sessionCookie);
            sodium_memzero($password);
        }
    }

    /** @param array{enabled:bool,baseUrl:string,username:string,configured:bool,downloadDirectory:string,category:string,defaultImportMode:string,transcodeFormat:string,transcodeBitrateKbps:?int,cleanupPolicy:string,cleanupDelayHours:int,minimumSeedTimeHours:int,monitorMode:string,version:int,updatedAt:string} $snapshot */
    private function projection(array $snapshot, bool $available, ?string $remoteVersion, ?string $errorCode): array
    {
        return ['bundled' => false] + $snapshot + [
            'available' => $available,
            'remoteVersion' => $remoteVersion,
            'errorCode' => $errorCode,
        ];
    }

    /**
     * 发送受约束 WebUI 请求；所有异常均丢弃原消息和 previous，避免表单密码或外部 URL进入错误记录。
     *
     * @param array<string,mixed> $options
     */
    private function request(string $method, string $baseUrl, string $path, array $options): ResponseInterface
    {
        try {
            $options['headers'] = ['Accept' => 'text/plain', 'Referer' => $baseUrl . '/']
                + (is_array($options['headers'] ?? null) ? $options['headers'] : []);
            return ($this->http ?? new Client(['http_errors' => false]))->request($method, $baseUrl . $path, $options + [
                'allow_redirects' => false,
                'connect_timeout' => 2.0,
                'timeout' => 8.0,
                'proxy' => '',
            ]);
        } catch (Throwable) {
            throw new QbittorrentUnavailable('QBITTORRENT_CONNECTION_FAILED');
        }
    }

    /** 有界读取小型纯文本响应，禁止下载器返回大正文占用请求内存。 */
    private function body(ResponseInterface $response, int $maximumBytes): string
    {
        $body = $response->getBody();
        try {
            $value = $body->read($maximumBytes + 1);
        } catch (Throwable) {
            throw new QbittorrentUnavailable('QBITTORRENT_PROTOCOL_INVALID');
        }
        if (strlen($value) > $maximumBytes || (!$body->eof() && $value !== '')) {
            throw new QbittorrentUnavailable('QBITTORRENT_PROTOCOL_INVALID');
        }
        return $value;
    }

    /**
     * 提取登录响应中的单个规范会话 Cookie。
     *
     * qBittorrent 旧版使用 `SID`，5.2 起按 WebUI 监听端口使用 `QBT_SID_<port>`。新版端口必须位于
     * 1-65535，值长度与字符集继续受限；返回值只包含名称和值，不转发 Path、HttpOnly 等其他属性，
     * 更不会接受任意第三方 Cookie 名称。缺失或畸形响应失败关闭。
     */
    private function sessionCookie(ResponseInterface $response): string
    {
        foreach ($response->getHeader('Set-Cookie') as $cookie) {
            if (preg_match('/^(SID|QBT_SID_([1-9][0-9]{0,4}))=([^;,\x00-\x20\x7F]{16,256})(?:;|$)/D', $cookie, $matches) === 1
                && ($matches[1] === 'SID' || (int) $matches[2] <= 65535)) {
                return $matches[1] . '=' . $matches[3];
            }
        }
        throw new QbittorrentUnavailable('QBITTORRENT_PROTOCOL_INVALID');
    }

    /** 注销失败不改变已经得到的探测结果；方法不会记录会话 Cookie、URL 或异常正文。 */
    private function logout(string $baseUrl, string $sessionCookie): void
    {
        try {
            $this->request('POST', $baseUrl, '/api/v2/auth/logout', ['headers' => ['Cookie' => $sessionCookie]]);
        } catch (QbittorrentUnavailable) {
            // 注销是凭据生命周期清理，不把尽力而为失败升级为服务不可用。
        }
    }
}
