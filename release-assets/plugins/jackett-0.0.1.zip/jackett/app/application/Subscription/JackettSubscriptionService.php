<?php

declare(strict_types=1);

namespace plugin\jackett\app\application\Subscription;

use app\application\ResourcePlugin\PhpResourcePluginInvalid;
use app\application\ResourcePlugin\PhpResourcePluginNotFound;
use app\application\ResourcePlugin\PhpResourcePluginOperationConflict;
use app\infrastructure\Audit\AuditLogger;
use plugin\jackett\app\application\DownloadClient\QbittorrentSettingsUnavailable;
use plugin\jackett\app\application\DownloadClient\ResourceDownloadJobService;
use plugin\jackett\app\application\ResourceSearch\JackettNotConfigured;
use plugin\jackett\app\application\ResourceSearch\JackettSearchInvalid;
use plugin\jackett\app\application\ResourceSearch\JackettSearchService;
use plugin\jackett\app\application\ResourceSearch\JackettUnavailable;
use stdClass;
use Symfony\Component\Uid\Ulid;
use support\Db;
use Throwable;

/**
 * 管理 Jackett PT 订阅规则、轮询发现和去重提交。
 *
 * 订阅只由后台 `manage_system` 管理；HTTP 写入只创建规则或设置立即检查标记，Jackett 网络请求、租约
 * 创建和 qBittorrent 提交全部在核心插件 Worker 的单步调用中执行。规则表不保存磁力、种子 URL、Cookie
 * 或平台账号；候选下载引用在同一短事务内加密进现有租约和下载任务，成功入库仍由原下载 Worker 事实确认。
 * 单消费者通过 next_run_at CAS 避免重叠轮询；相同订阅和候选 fingerprint 只允许一次下载任务。删除
 * 订阅只删除规则和发现账本，不删除已提交的 qBittorrent 任务、保种数据或已发布媒体。
 */
final readonly class JackettSubscriptionService
{
    private const QUALITY_RANK = ['any' => 0, '128k' => 1, '320k' => 2, 'flac' => 3, 'flac24' => 4];
    private const MAX_SIZE_BYTES = 1_099_511_627_776;

    public function __construct(
        private JackettSearchService $search = new JackettSearchService(),
        private ResourceDownloadJobService $downloads = new ResourceDownloadJobService(),
        private AuditLogger $audit = new AuditLogger(),
    ) {
    }

    /**
     * 返回订阅规则、当前可管理音乐库和固定筛选选项。
     *
     * 列表仅展示脱敏规则和状态计数；搜索词属于管理员自己配置的业务字段，不能进入 Worker 日志或审计。
     * 目标库名称通过数据库授权目录投影，永不返回真实路径。调用者已经由核心校验 manage_system。
     */
    public function snapshot(array $actor): array
    {
        if (!Db::connection()->getSchemaBuilder()->hasTable('jackett_subscriptions')) {
            return ['subscriptions' => [], 'options' => $this->options($actor)];
        }
        /** @var list<stdClass> $rows */
        $rows = Db::table('jackett_subscriptions as subscriptions')
            ->leftJoin('music_libraries as libraries', 'libraries.id', '=', 'subscriptions.library_id')
            ->leftJoin('users as owners', 'owners.id', '=', 'subscriptions.owner_user_id')
            ->orderByDesc('subscriptions.updated_at')->orderBy('subscriptions.id')
            ->get([
                'subscriptions.*', 'libraries.name as library_name', 'owners.username as owner_username',
            ])->all();
        return [
            'subscriptions' => array_map(fn (stdClass $row): array => $this->map($row), $rows),
            'options' => $this->options($actor),
        ];
    }

    /** 创建订阅规则；规则启用时首次检查安排在下一轮 Worker，不在请求中访问外部服务。 */
    public function create(array $payload, array $actor, string $requestId): array
    {
        $command = $this->validate($payload, false);
        $this->assertManageableLibrary((string) $command['libraryId'], (string) $command['importMode'], $actor);
        $now = gmdate('Y-m-d\TH:i:s\Z');
        $id = (string) new Ulid();
        Db::transaction(function () use ($id, $command, $actor, $requestId, $now): void {
            Db::table('jackett_subscriptions')->insert([
                'id' => $id, 'owner_user_id' => (string) $actor['id'], 'name' => $command['name'],
                'query' => $command['query'], 'indexer' => $command['indexer'],
                'quality_floor' => $command['qualityFloor'], 'min_seeders' => $command['minSeeders'],
                'max_size_bytes' => $command['maxSizeBytes'], 'interval_minutes' => $command['intervalMinutes'],
                'max_items_per_run' => $command['maxItemsPerRun'], 'library_id' => $command['libraryId'],
                'import_mode' => $command['importMode'], 'enabled' => $command['enabled'] ? 1 : 0,
                'cleanup_policy' => $command['cleanupPolicy'],
                'cleanup_delay_hours' => $command['cleanupDelayHours'],
                'minimum_seed_time_hours' => $command['minimumSeedTimeHours'],
                'version' => 1, 'last_run_at' => null,
                'next_run_at' => $command['enabled'] ? $now : gmdate('Y-m-d\TH:i:s\Z', time() + 86400),
                'last_error_code' => null, 'created_at' => $now, 'updated_at' => $now,
            ]);
            $this->audit->record((string) $actor['id'], 'jackett.subscription.create', 'jackett_subscription',
                $id, 'success', $requestId, ['enabled' => $command['enabled'], 'libraryId' => $command['libraryId']]);
        });
        return $this->find($id);
    }

    /**
     * 原子更新订阅规则。
     *
     * expectedVersion 必须匹配当前规则；已经进入 qBittorrent 的任务不回溯修改，新的筛选和调度只影响
     * 后续轮询。更新目标库前再次复验当前管理员的库管理权限，防止后台页面长期打开后越权写入。
     */
    public function update(string $subscriptionId, array $payload, array $actor, string $requestId): array
    {
        $this->assertId($subscriptionId);
        $command = $this->validate($payload, true);
        $this->assertManageableLibrary((string) $command['libraryId'], (string) $command['importMode'], $actor);
        $now = gmdate('Y-m-d\TH:i:s\Z');
        $changed = Db::table('jackett_subscriptions')->where('id', $subscriptionId)
            ->where('version', $command['expectedVersion'])->update([
                'name' => $command['name'], 'query' => $command['query'], 'indexer' => $command['indexer'],
                'quality_floor' => $command['qualityFloor'], 'min_seeders' => $command['minSeeders'],
                'max_size_bytes' => $command['maxSizeBytes'], 'interval_minutes' => $command['intervalMinutes'],
                'max_items_per_run' => $command['maxItemsPerRun'], 'library_id' => $command['libraryId'],
                'import_mode' => $command['importMode'], 'enabled' => $command['enabled'] ? 1 : 0,
                'cleanup_policy' => $command['cleanupPolicy'],
                'cleanup_delay_hours' => $command['cleanupDelayHours'],
                'minimum_seed_time_hours' => $command['minimumSeedTimeHours'],
                'version' => $command['expectedVersion'] + 1,
                'next_run_at' => $command['enabled'] ? $now : gmdate('Y-m-d\TH:i:s\Z', time() + 86400),
                'last_error_code' => null, 'updated_at' => $now,
            ]);
        if ($changed !== 1) throw new JackettSubscriptionConflict();
        $this->audit->record((string) $actor['id'], 'jackett.subscription.update', 'jackett_subscription',
            $subscriptionId, 'success', $requestId, ['version' => $command['expectedVersion'] + 1]);
        return $this->find($subscriptionId);
    }

    /** 删除规则和发现账本；外部 qBittorrent 任务由原下载 Worker 继续完成。 */
    public function delete(string $subscriptionId, array $actor, string $requestId): array
    {
        $this->assertId($subscriptionId);
        $deleted = Db::table('jackett_subscriptions')->where('id', $subscriptionId)->delete();
        if ($deleted !== 1) throw new JackettSubscriptionNotFound();
        $this->audit->record((string) $actor['id'], 'jackett.subscription.delete', 'jackett_subscription',
            $subscriptionId, 'success', $requestId, []);
        return ['id' => $subscriptionId, 'deleted' => true];
    }

    /** 标记立即轮询；禁用规则不会被隐式启用，避免“立即检查”改变管理员开关语义。 */
    public function runNow(string $subscriptionId, array $actor, string $requestId): array
    {
        $this->assertId($subscriptionId);
        $now = gmdate('Y-m-d\TH:i:s\Z');
        $changed = Db::table('jackett_subscriptions')->where('id', $subscriptionId)->update([
            'next_run_at' => $now, 'last_error_code' => null, 'updated_at' => $now,
        ]);
        if ($changed !== 1) throw new JackettSubscriptionNotFound();
        $this->audit->record((string) $actor['id'], 'jackett.subscription.run_now', 'jackett_subscription',
            $subscriptionId, 'success', $requestId, []);
        return $this->find($subscriptionId);
    }

    /** 返回指定订阅的最近运行记录；所有候选只保留标题/索引器和固定原因，禁止输出下载引用。 */
    public function runs(string $subscriptionId, array $actor, int $limit = 20): array
    {
        $this->assertId($subscriptionId);
        $this->assertOwner($subscriptionId, $actor);
        $rows = Db::table('jackett_subscription_runs')->where('subscription_id', $subscriptionId)
            ->orderByDesc('started_at')->limit(max(1, min(50, $limit)))->get()->all();
        return ['runs' => array_map(static function (stdClass $row): array {
            $details = json_decode((string) ($row->details_json ?? '{}'), true);
            return ['id' => (string) $row->id, 'status' => (string) $row->status,
                'trial' => (int) ($row->trial_mode ?? 0) === 1,
                'discoveredCount' => (int) $row->discovered_count,
                'filteredCount' => (int) ($row->filtered_count ?? 0),
                'queuedCount' => (int) $row->queued_count,
                'duplicateCount' => (int) ($row->duplicate_count ?? 0),
                'skippedCount' => (int) $row->skipped_count,
                'errorCode' => $row->error_code === null ? null : (string) $row->error_code,
                'startedAt' => (string) $row->started_at,
                'finishedAt' => $row->finished_at === null ? null : (string) $row->finished_at,
                'details' => is_array($details) ? $details : [],];
        }, $rows)];
    }

    /**
     * 试跑订阅：执行一次 Jackett 搜索和本地筛选，记录统计但不创建租约、下载任务或文件。
     *
     * 试跑使用独立运行记录并保留短摘要，管理员可据此调整索引器、质量和做种筛选；外部服务失败只
     * 写稳定错误码，绝不把上游正文回传页面。
     */
    public function trial(string $subscriptionId, array $actor, string $requestId): array
    {
        $this->assertId($subscriptionId);
        $subscription = Db::table('jackett_subscriptions')->where('id', $subscriptionId)->first();
        if (!$subscription instanceof stdClass) throw new JackettSubscriptionNotFound();
        $this->assertManageableLibrary((string) $subscription->library_id, (string) $subscription->import_mode, $actor);
        $runId = (string) new Ulid();
        $now = gmdate('Y-m-d\TH:i:s\Z');
        Db::table('jackett_subscription_runs')->insert(['id' => $runId, 'subscription_id' => $subscriptionId,
            'status' => 'running', 'trial_mode' => 1, 'discovered_count' => 0, 'filtered_count' => 0,
            'queued_count' => 0, 'duplicate_count' => 0, 'skipped_count' => 0, 'error_code' => null,
            'details_json' => '{}', 'started_at' => $now, 'finished_at' => null]);
        try {
            $items = $this->search->searchForSubscription((string) $subscription->query,
                min(100, max(20, (int) $subscription->max_items_per_run * 10)));
            $candidates = $this->filterAndSort($subscription, $items);
            $details = ['top' => array_map(static fn (array $item): array => [
                'title' => (string) ($item['title'] ?? ''), 'indexer' => (string) ($item['indexer'] ?? ''),
                'seeders' => isset($item['seeders']) ? (int) $item['seeders'] : null,
            ], array_slice($candidates, 0, 20))];
            Db::table('jackett_subscription_runs')->where('id', $runId)->update([
                'status' => 'succeeded', 'discovered_count' => count($items), 'filtered_count' => count($candidates),
                'skipped_count' => max(0, count($items) - count($candidates)),
                'details_json' => json_encode($details, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE),
                'finished_at' => gmdate('Y-m-d\TH:i:s\Z'),
            ]);
            $this->audit->record((string) $actor['id'], 'jackett.subscription.trial', 'jackett_subscription',
                $subscriptionId, 'success', $requestId, ['runId' => $runId, 'discoveredCount' => count($items),
                    'filteredCount' => count($candidates), 'queuedCount' => 0]);
            return ['runId' => $runId, 'trial' => true, 'status' => 'succeeded',
                'discoveredCount' => count($items), 'filteredCount' => count($candidates), 'queuedCount' => 0];
        } catch (Throwable $throwable) {
            $code = $this->errorCode($throwable);
            Db::table('jackett_subscription_runs')->where('id', $runId)->update([
                'status' => 'failed', 'error_code' => $code, 'finished_at' => gmdate('Y-m-d\TH:i:s\Z'),
            ]);
            $this->audit->record((string) $actor['id'], 'jackett.subscription.trial', 'jackett_subscription',
                $subscriptionId, 'failed', $requestId, ['runId' => $runId, 'errorCode' => $code]);
            return ['runId' => $runId, 'trial' => true, 'status' => 'failed', 'errorCode' => $code];
        }
    }

    /** 复验订阅存在且调用者拥有系统管理权限；库权限仍在写入/试跑前再次检查。 */
    private function assertOwner(string $subscriptionId, array $actor): void
    {
        if (!Db::table('jackett_subscriptions')->where('id', $subscriptionId)->exists()) {
            throw new JackettSubscriptionNotFound();
        }
        if (!($actor['isSuperAdmin'] ?? false)) {
            $user = Db::table('users')->where('id', (string) $actor['id'])->where('status', 'active')->exists();
            if (!$user) throw new JackettSubscriptionNotFound();
        }
    }

    /**
     * 消费一个到期订阅轮询。
     *
     * 领取只更新 next_run_at，随后在事务外访问 Jackett；成功候选由下载服务在独立短事务中加密租约并
     * 排队 qBittorrent。搜索/下载器暂时不可用时只记录稳定错误码并缩短下一次重试间隔，不把候选误标记为
     * 成功。一次调用最多处理一条规则，返回 true 让核心 Worker 继续保持单步节奏。
     */
    public function processNext(string $workerId): bool
    {
        if (!Db::connection()->getSchemaBuilder()->hasTable('jackett_subscriptions')) return false;
        $now = gmdate('Y-m-d\TH:i:s\Z');
        /** @var stdClass|null $subscription */
        $subscription = Db::table('jackett_subscriptions')->where('enabled', 1)
            ->where('next_run_at', '<=', $now)->orderBy('next_run_at')->first();
        if (!$subscription instanceof stdClass) return false;
        $next = gmdate('Y-m-d\TH:i:s\Z', time() + ((int) $subscription->interval_minutes * 60));
        $claimed = Db::table('jackett_subscriptions')->where('id', (string) $subscription->id)
            ->where('enabled', 1)->where('next_run_at', (string) $subscription->next_run_at)->update([
                'last_run_at' => $now, 'next_run_at' => $next, 'last_error_code' => null, 'updated_at' => $now,
            ]);
        if ($claimed !== 1) return true;

        $runId = (string) new Ulid();
        Db::table('jackett_subscription_runs')->insert([
            'id' => $runId, 'subscription_id' => (string) $subscription->id, 'status' => 'running',
            'trial_mode' => 0, 'discovered_count' => 0, 'filtered_count' => 0, 'queued_count' => 0,
            'duplicate_count' => 0, 'skipped_count' => 0, 'details_json' => '{}',
            'error_code' => null, 'started_at' => $now, 'finished_at' => null,
        ]);
        $owner = Db::table('users')->where('id', (string) $subscription->owner_user_id)
            ->where('status', 'active')->whereNull('deleted_at')->first(['id', 'is_super_admin']);
        if (!$owner instanceof stdClass) return $this->failRun($subscription, $runId, 'JACKETT_SUBSCRIPTION_OWNER_UNAVAILABLE');
        $actor = ['id' => (string) $owner->id, 'isSuperAdmin' => (int) $owner->is_super_admin === 1];
        try {
            $items = $this->search->searchForSubscription((string) $subscription->query, min(100, max(20, (int) $subscription->max_items_per_run * 10)));
            $candidates = $this->filterAndSort($subscription, $items);
            $discovered = count($items);
            $queued = 0;
            $skipped = max(0, $discovered - count($candidates));
            $duplicates = 0;
            foreach (array_slice($candidates, 0, (int) $subscription->max_items_per_run) as $item) {
                $known = Db::table('jackett_subscription_items')->where('subscription_id', (string) $subscription->id)
                    ->where('fingerprint', (string) $item['fingerprint'])->exists();
                if ($known) {
                    $skipped++;
                    $duplicates++;
                    continue;
                }
                $job = $this->downloads->createFromSubscription(
                    $subscription, $item, $actor, 'jackett-subscription:' . (string) $subscription->id,
                );
                if ($job !== null) $queued++;
                else $skipped++;
            }
            $finished = gmdate('Y-m-d\TH:i:s\Z');
            Db::table('jackett_subscription_runs')->where('id', $runId)->update([
                'status' => 'succeeded', 'discovered_count' => $discovered,
                'filtered_count' => count($candidates), 'queued_count' => $queued,
                'duplicate_count' => $duplicates, 'skipped_count' => $skipped,
                'finished_at' => $finished,
            ]);
            return true;
        } catch (Throwable $throwable) {
            $code = $this->errorCode($throwable);
            $this->failRun($subscription, $runId, $code);
            return true;
        }
    }

    /** @return array<string,mixed> */
    private function find(string $id): array
    {
        /** @var stdClass|null $row */
        $row = Db::table('jackett_subscriptions as subscriptions')
            ->leftJoin('music_libraries as libraries', 'libraries.id', '=', 'subscriptions.library_id')
            ->where('subscriptions.id', $id)->first(['subscriptions.*', 'libraries.name as library_name']);
        if (!$row instanceof stdClass) throw new JackettSubscriptionNotFound();
        return $this->map($row);
    }

    /** @return array<string,mixed> */
    private function map(stdClass $row): array
    {
        $activeJobs = Db::table('resource_download_jobs')->where('subscription_id', (string) $row->id)
            ->whereIn('status', ['queued', 'submitting', 'downloading', 'importing'])->count();
        return [
            'id' => (string) $row->id, 'name' => (string) $row->name, 'query' => (string) $row->query,
            'indexer' => $row->indexer === null ? null : (string) $row->indexer,
            'qualityFloor' => (string) $row->quality_floor, 'minSeeders' => $row->min_seeders === null ? null : (int) $row->min_seeders,
            'maxSizeBytes' => $row->max_size_bytes === null ? null : (int) $row->max_size_bytes,
            'intervalMinutes' => (int) $row->interval_minutes, 'maxItemsPerRun' => (int) $row->max_items_per_run,
            'library' => ['id' => (string) $row->library_id, 'name' => (string) ($row->library_name ?? '')],
            'importMode' => (string) $row->import_mode, 'enabled' => (int) $row->enabled === 1,
            'cleanupPolicy' => (string) ($row->cleanup_policy ?? 'never'),
            'cleanupDelayHours' => (int) ($row->cleanup_delay_hours ?? 24),
            'minimumSeedTimeHours' => (int) ($row->minimum_seed_time_hours ?? 72),
            'version' => (int) $row->version, 'lastRunAt' => $row->last_run_at === null ? null : (string) $row->last_run_at,
            'nextRunAt' => (string) $row->next_run_at, 'lastErrorCode' => $row->last_error_code === null ? null : (string) $row->last_error_code,
            'activeJobs' => (int) $activeJobs, 'updatedAt' => (string) $row->updated_at,
        ];
    }

    /**
     * 组装订阅表单选项，并把 Jackett 已配置索引器投影为名称/ID 白名单。
     *
     * 索引器清单是外部只读探测，不能阻断订阅列表、删除或已有 Worker；Jackett 暂时不可用时返回空
     * 清单和稳定错误码，页面会明确提示需要先恢复 Jackett 连接。已有规则仍保留原索引器文本并继续
     * 按其固化值筛选，不能因为一次清单探测失败而被清空或修改。
     *
     * @return array<string,mixed>
     */
    private function options(array $actor): array
    {
        $indexers = [];
        $indexersErrorCode = null;
        try {
            $indexers = $this->search->indexers();
        } catch (Throwable) {
            $indexersErrorCode = 'JACKETT_INDEXERS_UNAVAILABLE';
        }

        return $this->downloads->options($actor) + [
            'indexers' => $indexers,
            'indexersErrorCode' => $indexersErrorCode,
            'qualityFloors' => array_keys(self::QUALITY_RANK),
            'intervalMinutes' => [5, 15, 30, 60, 120, 360, 720, 1440],
            'maxItemsPerRun' => [1, 2, 3, 5, 10, 20],
        ];
    }

    /**
     * 将后台 JSON 命令转换成订阅内部值对象。
     *
     * 前置条件：核心已完成 Session、manage_system 和 CSRF 校验，但不能假设请求来自可信页面，因此
     * 这里仍要求精确字段集合、原生 PHP 标量类型、UTF-8 文本、ULID 库 ID 和数据库同范围的数值。
     * 失败只抛出稳定的领域异常，不访问音乐库、Jackett 或 qBittorrent；成功返回的值已经 trim，供
     * 事务直接写入。更新命令额外要求正整数 expectedVersion，由调用方用 CAS 防止旧页面覆盖新规则。
     */
    private function validate(array $payload, bool $update): array
    {
        $required = ['enabled', 'importMode', 'indexer', 'intervalMinutes', 'libraryId', 'maxItemsPerRun',
            'maxSizeBytes', 'minSeeders', 'name', 'qualityFloor', 'query', 'cleanupPolicy',
            'cleanupDelayHours', 'minimumSeedTimeHours'];
        if ($update) $required[] = 'expectedVersion';
        if (array_is_list($payload)) throw new JackettSubscriptionInvalid();
        $keys = array_keys($payload);
        sort($keys);
        $expected = $required;
        sort($expected);
        if ($keys !== $expected) throw new JackettSubscriptionInvalid();
        if (!is_string($payload['name']) || !is_string($payload['query'])
            || ($payload['indexer'] !== null && !is_string($payload['indexer']))
            || !is_string($payload['qualityFloor']) || !is_string($payload['importMode'])
            || !is_string($payload['libraryId']) || !is_bool($payload['enabled'])
            || !is_int($payload['intervalMinutes']) || !is_int($payload['maxItemsPerRun'])
            || !is_string($payload['cleanupPolicy']) || !is_int($payload['cleanupDelayHours'])
            || !is_int($payload['minimumSeedTimeHours'])) {
            throw new JackettSubscriptionInvalid();
        }
        $name = trim($payload['name']);
        $query = trim($payload['query']);
        $indexer = $payload['indexer'] === null ? null : trim($payload['indexer']);
        if (!$this->validText($name, 1, 120) || !$this->validText($query, 2, 200)
            || ($indexer !== null && !$this->validText($indexer, 1, 120))
            || preg_match('/^[0-9A-HJKMNP-TV-Z]{26}$/D', $payload['libraryId']) !== 1
            || !in_array($payload['qualityFloor'], array_keys(self::QUALITY_RANK), true)
            || !in_array($payload['importMode'], ['copy', 'move', 'hardlink', 'symlink', 'transcode'], true)
            || $payload['intervalMinutes'] < 5 || $payload['intervalMinutes'] > 1440
            || $payload['maxItemsPerRun'] < 1 || $payload['maxItemsPerRun'] > 20
            || !in_array($payload['cleanupPolicy'], ['never', 'after_import', 'after_delay', 'after_seeding'], true)
            || $payload['cleanupDelayHours'] < 1 || $payload['cleanupDelayHours'] > 8760
            || $payload['minimumSeedTimeHours'] < 1 || $payload['minimumSeedTimeHours'] > 8760) {
            throw new JackettSubscriptionInvalid();
        }
        foreach (['minSeeders' => 0, 'maxSizeBytes' => 1] as $field => $minimum) {
            if ($payload[$field] !== null && (!is_int($payload[$field]) || $payload[$field] < $minimum)) {
                throw new JackettSubscriptionInvalid();
            }
        }
        if (($payload['minSeeders'] !== null && $payload['minSeeders'] > 1_000_000)
            || ($payload['maxSizeBytes'] !== null && $payload['maxSizeBytes'] > self::MAX_SIZE_BYTES)) {
            throw new JackettSubscriptionInvalid();
        }
        $result = [
            'name' => $name, 'query' => $query, 'indexer' => $indexer, 'qualityFloor' => $payload['qualityFloor'],
            'minSeeders' => $payload['minSeeders'], 'maxSizeBytes' => $payload['maxSizeBytes'],
            'intervalMinutes' => $payload['intervalMinutes'], 'maxItemsPerRun' => $payload['maxItemsPerRun'],
            'libraryId' => $payload['libraryId'], 'importMode' => $payload['importMode'], 'enabled' => $payload['enabled'],
            'cleanupPolicy' => $payload['cleanupPolicy'], 'cleanupDelayHours' => $payload['cleanupDelayHours'],
            'minimumSeedTimeHours' => $payload['minimumSeedTimeHours'],
        ];
        if ($update) $result['expectedVersion'] = $payload['expectedVersion'];
        if ($update && (!is_int($payload['expectedVersion']) || $payload['expectedVersion'] < 1)) throw new JackettSubscriptionInvalid();
        return $result;
    }

    /**
     * 校验订阅中由管理员输入的文本字段。
     *
     * 订阅会被 Worker 长期保存并写入 Jackett 查询；这里拒绝非法 UTF-8 和控制字符，避免损坏数据库
     * 约束、日志终端或上游请求。长度按 Unicode 字符计算，调用方仍应在业务层使用 trim 后的值。
     */
    private function validText(string $value, int $minimum, int $maximum): bool
    {
        return mb_check_encoding($value, 'UTF-8')
            && preg_match('/[\x00-\x1F\x7F]/u', $value) !== 1
            && mb_strlen($value, 'UTF-8') >= $minimum
            && mb_strlen($value, 'UTF-8') <= $maximum;
    }

    /** 远程库不能保存链接模式规则；该约束在规则保存和每次 Worker 执行前都重新应用。 */
    private function assertManageableLibrary(string $libraryId, string $importMode, array $actor): void
    {
        foreach ($this->downloads->options($actor)['libraries'] as $library) {
            if (($library['id'] ?? null) !== $libraryId) continue;
            if (($library['sourceType'] ?? null) !== 'local'
                && in_array($importMode, ['hardlink', 'symlink'], true)) break;
            return;
        }
        throw new JackettSubscriptionInvalid();
    }

    /** @param list<array<string,mixed>> $items @return list<array<string,mixed>> */
    private function filterAndSort(stdClass $subscription, array $items): array
    {
        $floor = self::QUALITY_RANK[(string) $subscription->quality_floor];
        $filtered = array_values(array_filter($items, function (array $item) use ($subscription, $floor): bool {
            if (($subscription->indexer !== null) && strcasecmp((string) $subscription->indexer, (string) $item['indexer']) !== 0) return false;
            if ($subscription->min_seeders !== null && (($item['seeders'] ?? null) === null || (int) $item['seeders'] < (int) $subscription->min_seeders)) return false;
            if ($subscription->max_size_bytes !== null && (($item['sizeBytes'] ?? null) === null || (int) $item['sizeBytes'] > (int) $subscription->max_size_bytes)) return false;
            if ($floor > 0 && $this->qualityRank((string) $item['title']) < $floor) return false;
            return is_string($item['downloadReference'] ?? null) && $item['downloadReference'] !== '';
        }));
        usort($filtered, function (array $left, array $right): int {
            $quality = $this->qualityRank((string) $right['title']) <=> $this->qualityRank((string) $left['title']);
            if ($quality !== 0) return $quality;
            return ((int) ($right['seeders'] ?? -1)) <=> ((int) ($left['seeders'] ?? -1));
        });
        return $filtered;
    }

    private function qualityRank(string $title): int
    {
        $value = strtolower($title);
        if (preg_match('/(?:24bit|24-bit|hi[- ]?res|high[- ]?resolution)/', $value) === 1 && str_contains($value, 'flac')) return 4;
        if (str_contains($value, 'flac') || str_contains($value, 'lossless')) return 3;
        if (preg_match('/(?:320\s*k|320kbps|mp3\s*320)/', $value) === 1) return 2;
        if (preg_match('/(?:128\s*k|128kbps|mp3)/', $value) === 1) return 1;
        return 0;
    }

    private function failRun(stdClass $subscription, string $runId, string $errorCode): bool
    {
        $now = gmdate('Y-m-d\TH:i:s\Z');
        $retryAt = gmdate('Y-m-d\TH:i:s\Z', time() + min(900, (int) $subscription->interval_minutes * 60));
        Db::table('jackett_subscription_runs')->where('id', $runId)->update([
            'status' => 'failed', 'error_code' => $errorCode, 'finished_at' => $now,
        ]);
        Db::table('jackett_subscriptions')->where('id', (string) $subscription->id)->update([
            'last_error_code' => $errorCode, 'next_run_at' => $retryAt, 'updated_at' => $now,
        ]);
        return true;
    }

    private function errorCode(Throwable $throwable): string
    {
        if ($throwable instanceof JackettUnavailable) return $throwable->errorCode;
        if ($throwable instanceof JackettNotConfigured) return 'JACKETT_NOT_CONFIGURED';
        if ($throwable instanceof QbittorrentSettingsUnavailable) return 'QBITTORRENT_NOT_CONFIGURED';
        if ($throwable instanceof JackettSearchInvalid) return 'JACKETT_SUBSCRIPTION_INVALID';
        return 'JACKETT_SUBSCRIPTION_FAILED';
    }

    private function assertId(string $id): void
    {
        if (preg_match('/^[0-9A-HJKMNP-TV-Z]{26}$/D', $id) !== 1) throw new JackettSubscriptionNotFound();
    }
}

/**
 * 订阅异常别名必须兼容已发布核心的 final 错误类；插件包独立升级时不能要求同时重建 backend 镜像。
 * 别名仍保留插件命名空间，测试和业务代码可使用稳定名称，Controller 的既有错误映射则继续识别核心类。
 */
class_alias(PhpResourcePluginInvalid::class, __NAMESPACE__ . '\\JackettSubscriptionInvalid');
class_alias(PhpResourcePluginNotFound::class, __NAMESPACE__ . '\\JackettSubscriptionNotFound');
class_alias(PhpResourcePluginOperationConflict::class, __NAMESPACE__ . '\\JackettSubscriptionConflict');
