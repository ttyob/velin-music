<?php

declare(strict_types=1);

namespace plugin\jackett\app\controller\Admin;

use app\application\Auth\AuthenticationRequired;
use app\application\Auth\AuthorizationDenied;
use app\application\Auth\AuthorizationService;
use app\application\ResourcePlugin\PhpResourcePluginRegistry;
use plugin\jackett\app\application\DownloadClient\QbittorrentSettingsConflict;
use plugin\jackett\app\application\DownloadClient\QbittorrentSettingsInvalid;
use plugin\jackett\app\application\DownloadClient\QbittorrentSettingsService;
use plugin\jackett\app\application\DownloadClient\QbittorrentSettingsUnavailable;
use plugin\jackett\app\application\DownloadClient\QbittorrentStatusService;
use plugin\jackett\app\application\DownloadClient\ResourceDownloadInvalid;
use plugin\jackett\app\application\DownloadClient\ResourceDownloadJobService;
use plugin\jackett\app\application\DownloadClient\ResourceDownloadNotFound;
use app\http\JsonResponseFactory;
use app\http\RequestContext;
use support\Request;
use support\Response;
use Throwable;

/**
 * 暴露后台 Session 专用的外部 qBittorrent 配置与状态 API。
 *
 * Controller 要求 `manage_system` 并拒绝 Bearer/PAT，防止长期令牌修改下载基础设施。PUT 由路由绑定
 * CSRF，只接受启停、WebUI 根地址、账号、默认入库方式、白名单转码档案、自动清理策略/小时参数、可选
 * 替换密码和版本；下载路径、分类和监听模式不是请求字段。下载命令只接收 Jackett 服务端租约、目标库
 * 与白名单入库方式，不接收 torrent、
 * 磁力、InfoHash 或下载 URL；任务投影严格排除下载引用、hash、Cookie 和内容路径。
 */
final class QbittorrentController
{
    /** 返回外部连接的脱敏配置和即时可用性，不返回密码、SID 或下载任务。 */
    public function status(Request $request): Response
    {
        return $this->execute($request, static fn (): array =>
            (new PhpResourcePluginRegistry())->download('jackett')->downloadStatus());
    }

    /** 返回配置弹窗快照；密码只投影为 configured，下载目录和分类只读。 */
    public function configuration(Request $request): Response
    {
        return $this->execute($request, static fn (): array =>
            (new PhpResourcePluginRegistry())->download('jackett')->downloadConfiguration());
    }

    /**
     * 使用版本锁保存外部 qBittorrent 连接、默认转码档案与自动清理策略。
     *
     * actor 只来自实时后台 Session，CSRF 在路由层验证。服务严格拒绝路径、分类、FFmpeg 参数和未知
     * 字段；转码档案与清理策略只影响后续任务快照，不追溯活动任务。保存成功不在 SQLite 事务中探测
     * 网络；页面随后读取 status，避免慢连接延长写锁。
     */
    public function updateConfiguration(Request $request): Response
    {
        return $this->execute($request, static function (array $actor) use ($request): array {
            $payload = $request->post();
            if (!is_array($payload)) throw new QbittorrentSettingsInvalid();
            return (new PhpResourcePluginRegistry())->download('jackett')->updateDownloadConfiguration(
                $payload, $actor, RequestContext::requestId(),
            );
        });
    }

    /** 返回当前管理员可管理的本地或受支持远程库及下载方式词汇，不暴露根路径或远端凭据。 */
    public function downloadOptions(Request $request): Response
    {
        return $this->execute($request, static fn (array $actor): array =>
            (new PhpResourcePluginRegistry())->download('jackett')->downloadOptions($actor));
    }

    /**
     * 从当前管理员拥有的短期 Jackett 结果租约创建下载任务。
     *
     * Controller 严格拒绝未知字段；URL、磁力、保存目录和单任务源文件保护均无法由浏览器注入。转码
     * 结果是否清理下载源统一服从版本化下载器配置，软链接的安全例外仍由领域服务强制收口。重复
     * leaseId 由服务端唯一约束返回原任务，CSRF 与实时 manage_system 在进入服务前均已验证。
     */
    public function createDownload(Request $request): Response
    {
        return $this->execute($request, static function (array $actor) use ($request): array {
            $payload = $request->post();
            if (!is_array($payload) || array_is_list($payload)) throw new ResourceDownloadInvalid();
            $keys = array_keys($payload); sort($keys);
            if ($keys !== ['importMode', 'leaseId', 'libraryId']
                || !is_string($payload['leaseId'] ?? null) || !is_string($payload['libraryId'] ?? null)
                || !is_string($payload['importMode'] ?? null)) throw new ResourceDownloadInvalid();
            return (new PhpResourcePluginRegistry())->download('jackett')->createDownload(
                $payload, $actor, RequestContext::requestId(),
            );
        });
    }

    /** 返回最近任务与可展示进度；读取也要求实时后台 Session，拒绝 PAT/Bearer。 */
    public function jobs(Request $request): Response
    {
        return $this->execute($request, static fn (): array =>
            (new PhpResourcePluginRegistry())->download('jackett')->downloadJobs(50));
    }

    /**
     * 统一执行后台认证、能力校验和安全错误映射。
     *
     * 非预期 Throwable 收敛为 503 且不附带 previous/message，避免全局异常记录捕获可能包含 WebUI URL、
     * 用户名、密码或 SID 的第三方异常。配置不存在也使用稳定错误，不回退到隐藏默认账号。
     */
    private function execute(Request $request, callable $operation): Response
    {
        $requestId = RequestContext::requestId();
        try {
            if (trim((string) $request->header('authorization')) !== '') throw new AuthorizationDenied();
            $actor = (new AuthorizationService())->requireCapability($request, 'manage_system');
            return JsonResponseFactory::create(['data' => $operation($actor), 'meta' => [
                'requestId' => $requestId,
                'timestamp' => gmdate('c'),
            ]], 200, $requestId);
        } catch (Throwable $exception) {
            $error = match (true) {
                $exception instanceof AuthenticationRequired => ['AUTHENTICATION_REQUIRED', '请先登录。', 401],
                $exception instanceof AuthorizationDenied => ['PERMISSION_DENIED', '没有管理下载器的权限。', 403],
                $exception instanceof QbittorrentSettingsInvalid => ['QBITTORRENT_SETTINGS_INVALID', 'qBittorrent 配置无效。', 422],
                $exception instanceof QbittorrentSettingsConflict => ['QBITTORRENT_SETTINGS_CONFLICT', 'qBittorrent 配置已变化，请刷新后重试。', 409],
                $exception instanceof QbittorrentSettingsUnavailable => ['QBITTORRENT_SETTINGS_UNAVAILABLE', 'qBittorrent 配置暂时不可用。', 503],
                $exception instanceof ResourceDownloadInvalid => ['RESOURCE_DOWNLOAD_INVALID', '下载任务参数无效。', 422],
                $exception instanceof ResourceDownloadNotFound => ['RESOURCE_DOWNLOAD_NOT_FOUND', '搜索结果已过期或目标音乐库不可用。', 404],
                default => ['QBITTORRENT_STATUS_FAILED', 'qBittorrent 状态暂时不可用。', 503],
            };
            return JsonResponseFactory::error($error[0], $error[1], $error[2], $requestId);
        }
    }
}
