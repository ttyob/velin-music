<?php

declare(strict_types=1);

namespace plugin\jackett\app\controller\Admin;

use app\application\Auth\AuthenticationRequired;
use app\application\Auth\AuthorizationDenied;
use app\application\Auth\AuthorizationService;
use app\application\ResourcePlugin\PhpResourcePluginRegistry;
use plugin\jackett\app\application\ResourceSearch\JackettNotConfigured;
use plugin\jackett\app\application\ResourceSearch\JackettSearchInvalid;
use plugin\jackett\app\application\ResourceSearch\JackettSearchService;
use plugin\jackett\app\application\ResourceSearch\JackettSettingsConflict;
use plugin\jackett\app\application\ResourceSearch\JackettSettingsInvalid;
use plugin\jackett\app\application\ResourceSearch\JackettSettingsService;
use plugin\jackett\app\application\ResourceSearch\JackettSettingsUnavailable;
use plugin\jackett\app\application\ResourceSearch\JackettUnavailable;
use app\http\JsonResponseFactory;
use app\http\RequestContext;
use support\Request;
use support\Response;
use Throwable;

/**
 * 暴露后台 Session 专用的 Jackett 状态与只读搜索 API。
 *
 * Controller 要求 `manage_system`，并拒绝 Bearer/PAT 调用，避免长期令牌成为访问私有 tracker 搜索事实的
 * 旁路。PUT 配置与 POST 搜索都由路由显式绑定 CSRF；配置只接受启停、外部根地址、可选替换 Key 和
 * 版本，API Key 永不回读。搜索只接受 query/limit，indexer ID 和下载地址不是 Web 协议字段。
 */
final class JackettController
{
    /** 返回外部连接的脱敏配置和当前可用性，不返回 API Key 或站点清单。 */
    public function status(Request $request): Response
    {
        return $this->execute($request, static fn (): array =>
            (new PhpResourcePluginRegistry())->search('jackett')->searchStatus());
    }

    /** 返回外部 Jackett 表单快照；API Key 只投影为 configured 布尔值。 */
    public function configuration(Request $request): Response
    {
        return $this->execute($request, static fn (): array =>
            (new PhpResourcePluginRegistry())->search('jackett')->searchConfiguration());
    }

    /**
     * 用版本锁保存外部 Jackett 地址、启停与可选的新 API Key。
     *
     * actor 只来自实时后台 Session，CSRF 在路由层验证。服务严格拒绝未知字段，保存成功不在事务中探测
     * 网络；页面随后读取 status 获取当前可用性，避免慢连接延长 SQLite 写锁。
     */
    public function updateConfiguration(Request $request): Response
    {
        return $this->execute($request, static function (array $actor) use ($request): array {
            $payload = $request->post();
            if (!is_array($payload)) {
                throw new JackettSettingsInvalid();
            }

            return (new PhpResourcePluginRegistry())->search('jackett')->updateSearchConfiguration(
                $payload, $actor, RequestContext::requestId(),
            );
        });
    }

    /**
     * 执行一次有界音乐搜索并返回白名单投影。
     *
     * 未知字段失败关闭，避免未来浏览器误以为可提交 category、indexer 或下载开关。query 会交给领域
     * 服务重复校验；错误响应只使用稳定中文消息，不回显查询或上游异常。
     */
    public function search(Request $request): Response
    {
        return $this->execute($request, static function (array $actor) use ($request): array {
            $payload = $request->post();
            if (!is_array($payload)) throw new JackettSearchInvalid();
            $keys = array_keys($payload);
            sort($keys);
            if (!in_array($keys, [['query'], ['limit', 'query']], true)
                || !is_string($payload['query'] ?? null)
                || (isset($payload['limit']) && !is_int($payload['limit']))) {
                throw new JackettSearchInvalid();
            }

            return (new PhpResourcePluginRegistry())->search('jackett')->search(
                $payload['query'],
                isset($payload['limit']) ? $payload['limit'] : 30,
                (string) $actor['id'],
            );
        });
    }

    /**
     * 统一应用后台认证、能力与安全错误映射。
     *
     * Authorization header 无论是否合法都不进入该集成；Cookie Session 仍由 AuthorizationService 解析
     * 实时账号与能力。所有非预期 Throwable 收敛为 503，不附带 previous 或 message，避免全局异常页
     * 记录可能含 apikey 的 Guzzle URI。
     */
    private function execute(Request $request, callable $operation): Response
    {
        $requestId = RequestContext::requestId();
        try {
            if (trim((string) $request->header('authorization')) !== '') throw new AuthorizationDenied();
            $actor = (new AuthorizationService())->requireCapability($request, 'manage_system');
            return JsonResponseFactory::create(['data' => $operation($actor), 'meta' => [
                'requestId' => $requestId, 'timestamp' => gmdate('c'),
            ]], 200, $requestId);
        } catch (Throwable $exception) {
            $error = match (true) {
                $exception instanceof AuthenticationRequired => ['AUTHENTICATION_REQUIRED', '请先登录。', 401],
                $exception instanceof AuthorizationDenied => ['PERMISSION_DENIED', '没有管理资源搜索的权限。', 403],
                $exception instanceof JackettSearchInvalid => ['JACKETT_SEARCH_INVALID', '搜索条件无效。', 422],
                $exception instanceof JackettSettingsInvalid => ['JACKETT_SETTINGS_INVALID', 'Jackett 配置无效。', 422],
                $exception instanceof JackettSettingsConflict => ['JACKETT_SETTINGS_CONFLICT', 'Jackett 配置已变化，请刷新后重试。', 409],
                $exception instanceof JackettSettingsUnavailable => ['JACKETT_SETTINGS_UNAVAILABLE', 'Jackett 配置暂时不可用。', 503],
                $exception instanceof JackettNotConfigured => ['JACKETT_NOT_CONFIGURED', 'Jackett 未启用或配置不完整。', 503],
                $exception instanceof JackettUnavailable => [$exception->errorCode, 'Jackett 搜索暂时不可用。', 503],
                default => ['JACKETT_SEARCH_FAILED', 'Jackett 搜索暂时不可用。', 503],
            };
            return JsonResponseFactory::error($error[0], $error[1], $error[2], $requestId);
        }
    }
}
