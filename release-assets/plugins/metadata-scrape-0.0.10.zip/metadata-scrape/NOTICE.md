# Velin Music Metadata Scrape Helper

`metadata-scrape-helper` is a separately executed command-line component owned by the
`metadata-scrape` plugin. It statically links `github.com/guohuiyuan/music-lib` and
`github.com/mozillazg/go-pinyin` at the exact versions recorded in the helper's `go.mod` and
`go.sum`. Those dependencies are licensed under GNU AGPL-3.0 and MIT, respectively.

The complete source used to build this component is `gohelper/metadata-scrape-helper/` plus the
locked upstream module source. Anyone distributing or providing network access to the helper must
independently review and satisfy the AGPL-3.0 source availability obligations for the combined
helper binary. This notice does not relicense unrelated Velin Music Webman or frontend code.
