<?php

declare(strict_types=1);

namespace plugin\metadata_scrape\app;

use Throwable;

/**
 * MetadataScrapeHelperUnavailable 表示插件自带 Helper 无法给出可信协议结果。
 *
 * 异常消息只使用稳定机器码，诊断也只能包含封闭枚举的阶段、原因、来源和字段，不能含进程输出、第三方
 * URL、歌词、网络错误或任何凭据。调用方必须把故障显示为插件不可用，而不是“歌曲没有匹配”；核心也
 * 不得回退已移除的固定平台实现。异常本身不修改数据库或文件。
 */
final class MetadataScrapeHelperUnavailable extends \RuntimeException
{
    private const PHASES = ['input', 'process', 'envelope', 'result', 'candidate'];
    private const REASONS = [
        'INPUT_INVALID', 'BINARY_UNAVAILABLE', 'PROCESS_FAILED', 'OUTPUT_EMPTY', 'OUTPUT_TOO_LARGE',
        'JSON_INVALID', 'ENVELOPE_KEYS_INVALID', 'VERSION_MISMATCH', 'RESULT_COUNT_MISMATCH',
        'SOURCE_ORDER_MISMATCH', 'RESULT_FIELD_INVALID', 'CANDIDATE_FIELD_INVALID',
    ];

    /**
     * 创建一个只携带安全诊断的 Helper 故障。
     *
     * `$diagnostics` 由协议客户端生成而不是外部输入；构造器仍执行白名单过滤，保证未来调用方即使误传
     * Helper 正文也不会进入插件任务日志。`retryable` 只描述故障分类，当前核心仍按统一最多三次退避；它
     * 供任务详情说明和后续契约演进使用。异常链仅保留在内存中，不得序列化到数据库或 API。
     *
     * @param array{phase?:string,reason?:string,source?:string|null,field?:string|null,retryable?:bool} $diagnostics
     */
    public function __construct(string $errorCode, array $diagnostics = [], ?Throwable $previous = null)
    {
        parent::__construct($errorCode, 0, $previous);
        $phase = $diagnostics['phase'] ?? null;
        $reason = $diagnostics['reason'] ?? null;
        $source = $diagnostics['source'] ?? null;
        $field = $diagnostics['field'] ?? null;
        $this->diagnostics = [
            'phase' => is_string($phase) && in_array($phase, self::PHASES, true) ? $phase : 'process',
            'reason' => is_string($reason) && in_array($reason, self::REASONS, true) ? $reason : 'PROCESS_FAILED',
            'retryable' => ($diagnostics['retryable'] ?? true) === true,
        ];
        if (is_string($source) && preg_match('/^[a-z][a-z0-9_]{1,31}$/D', $source) === 1) {
            $this->diagnostics['source'] = $source;
        }
        if (is_string($field) && preg_match('/^[A-Za-z][A-Za-z0-9]{0,63}$/D', $field) === 1) {
            $this->diagnostics['field'] = $field;
        }
    }

    /** @var array{phase:string,reason:string,retryable:bool,source?:string,field?:string} */
    private array $diagnostics;

    /**
     * 返回可写入插件任务日志的封闭诊断，不包含 Helper 输出或第三方数据。
     *
     * @return array{phase:string,reason:string,retryable:bool,source?:string,field?:string}
     */
    public function safeDiagnostics(): array
    {
        return $this->diagnostics;
    }
}
