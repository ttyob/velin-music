<?php

declare(strict_types=1);

namespace plugin\metadata_scrape\app;

use app\application\ResourcePlugin\Contract\AlbumScrapeCompletionRequest;

/**
 * MetadataScrapeAlbumLookupGateway 隔离插件自带的专辑查询协议。
 *
 * 专辑查询只接受专辑身份，不得把专辑标题伪装成歌曲标题，也不得复用歌曲候选评分结果。返回值只在
 * 插件内完成最终选择，核心不会接触平台私有 ID、原始响应或候选 URL。
 */
interface MetadataScrapeAlbumLookupGateway
{
    /** @return list<array<string,mixed>> 插件内部的逐来源专辑结果。 */
    public function lookupAlbum(AlbumScrapeCompletionRequest $request): array;
}
