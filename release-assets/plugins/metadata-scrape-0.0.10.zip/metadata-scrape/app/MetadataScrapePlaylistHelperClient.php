<?php

declare(strict_types=1);

namespace plugin\metadata_scrape\app;

use app\application\Playlist\PlatformPlaylistDocument;
use app\application\Playlist\PlatformPlaylistEntry;
use app\application\Playlist\PlaylistLinkInvalid;
use app\application\Playlist\PlaylistLinkUnavailable;
use app\application\Recommendation\PublicPlaylistCatalogUnavailable;
use Symfony\Component\Process\Process;
use JsonException;
use Throwable;

/**
 * MetadataScrapePlaylistHelperClient 把平台歌单网络和协议解析限制在元数据插件包内。
 *
 * 二进制必须是本包随附的静态 Helper，PHP 只发送经过主机白名单校验的公开 URL 或脱敏来源 key；Helper
 * 输出重新做字段、数量和单位校验后才转换为核心统一 DTO。任何启动、超时、协议或上游失败都映射为稳定
 * 异常，绝不调用核心 `velin-source-helper`，也不把平台 ID、URL、凭据或原始响应带入业务层。
 */
final readonly class MetadataScrapePlaylistHelperClient
{
    private const PLAYLIST_PROTOCOL_VERSION = 8;
    private const CATALOG_PROTOCOL_VERSION = 13;
    private const RECOMMENDATION_PROTOCOL_VERSION = 17;
    private const MAX_OUTPUT_BYTES = 2_097_152;
    private const MAX_CATALOG_ITEMS = 20;
    private const HOSTS = [
        'netease' => ['music.163.com', 'y.music.163.com'],
        'qq' => ['y.qq.com', 'c6.y.qq.com', 'i.y.qq.com', 'i2.y.qq.com'],
        'kugou' => ['kugou.com', 'www.kugou.com', 'm.kugou.com'],
        'kuwo' => ['kuwo.cn', 'www.kuwo.cn', 'm.kuwo.cn'],
        'migu' => ['music.migu.cn', 'm.music.migu.cn', 'y.migu.cn', 'd.musicapp.migu.cn'],
        'soda' => ['music.douyin.com', 'www.douyin.com', 'www.qishui.com', 'qishui.douyin.com'],
        'apple_music' => ['music.apple.com', 'itunes.apple.com'],
    ];

    public function __construct(private ?string $binaryPath = null)
    {
    }

    /**
     * 解析一个公开歌单 URL；请求不携带 Cookie、Token 或任意浏览器请求头。
     *
     * URL 只接受插件声明的 HTTPS 主机，长度和端口等 SSRF 边界在启动 Helper 前检查。成功文档只保留
     * 标题、艺人、专辑和毫秒时长；空歌单和协议字段异常均失败关闭，不创建核心歌单。
     *
     * @throws PlaylistLinkInvalid
     * @throws PlaylistLinkUnavailable
     */
    public function identify(string $source, string $link): PlatformPlaylistDocument
    {
        $source = strtolower(trim($source));
        $link = trim($link);
        if (!isset(self::HOSTS[$source]) || mb_strlen($link) < 12 || mb_strlen($link) > 2048) {
            throw new PlaylistLinkInvalid();
        }
        $parts = parse_url($link);
        $host = is_array($parts) ? strtolower(rtrim((string) ($parts['host'] ?? ''), '.')) : '';
        if (!is_array($parts) || ($parts['scheme'] ?? '') !== 'https' || $host === ''
            || isset($parts['user'], $parts['pass'], $parts['port']) || ($parts['path'] ?? '') === ''
            || !in_array($host, self::HOSTS[$source], true)) {
            throw new PlaylistLinkInvalid();
        }
        $payload = $this->run([
            'version' => self::PLAYLIST_PROTOCOL_VERSION,
            'operation' => 'playlist',
            'playlistSource' => $source,
            'playlistLink' => $link,
            'sources' => [],
        ], 'PLAYLIST_LINK');
        if (!is_array($payload) || array_diff(array_keys($payload), ['version', 'source', 'title', 'entries']) !== []
            || ($payload['version'] ?? null) !== self::PLAYLIST_PROTOCOL_VERSION
            || ($payload['source'] ?? null) !== $source || !$this->text($payload['title'] ?? null, 500)
            || !is_array($payload['entries'] ?? null) || !array_is_list($payload['entries'])
            || count($payload['entries']) > 1000) {
            throw new PlaylistLinkUnavailable('invalid_helper_response');
        }
        $entries = [];
        foreach ($payload['entries'] as $entry) $entries[] = $this->entry($entry, true);
        if ($entries === []) throw new PlaylistLinkUnavailable('playlist_empty');
        return new PlatformPlaylistDocument($source, trim($payload['title']), $entries);
    }

    /**
     * 读取公开榜单目录；目录 key 是 Helper 计算的不可逆摘要，不是平台 ID。
     *
     * @return list<array{key:string,title:string,description:string,entries:list<array{title:string,artists:list<string>,album:?string,durationMs:?int}>}>
     * @throws PublicPlaylistCatalogUnavailable
     */
    public function catalog(string $source): array
    {
        if (!in_array($source, ['netease', 'qq', 'kugou'], true)) {
            throw new PublicPlaylistCatalogUnavailable('PUBLIC_PLAYLIST_SOURCE_UNSUPPORTED');
        }
        try {
            $payload = $this->run([
                'version' => self::CATALOG_PROTOCOL_VERSION,
                'operation' => 'playlist_catalog',
                'playlistSource' => $source,
                'sources' => [],
            ], 'PUBLIC_PLAYLIST_CATALOG');
        } catch (PlaylistLinkUnavailable $exception) {
            throw new PublicPlaylistCatalogUnavailable('PUBLIC_PLAYLIST_PLUGIN_UNAVAILABLE', previous: $exception);
        }
        return $this->catalogResponse($payload, self::CATALOG_PROTOCOL_VERSION, $source);
    }

    /**
     * 读取无需登录的首页推荐歌单；首版只开放 Helper 内固定的网易云公开接口。
     *
     * 调用方只能提供来源枚举和 1 到 20 的数量，不接受平台链接、账号凭据、种子歌曲或任意 options。
     * Helper 返回后仍按目录合同逐字段复验，平台 ID、封面、URL 和推荐算法标识不会进入 PHP。方法只做
     * 有界网络读取，不写插件任务、核心歌单或缓存；上游/协议失败统一抛出稳定不可用异常供核心降级。
     *
     * @return list<array{key:string,title:string,description:string,entries:list<array{title:string,artists:list<string>,album:?string,durationMs:?int}>}>
     * @throws PublicPlaylistCatalogUnavailable
     */
    public function recommendations(string $source, int $limit): array
    {
        $source = strtolower(trim($source));
        if ($source !== 'netease' || $limit < 1 || $limit > self::MAX_CATALOG_ITEMS) {
            throw new PublicPlaylistCatalogUnavailable('RECOMMENDATION_PLAYLIST_REQUEST_INVALID');
        }
        try {
            $payload = $this->run([
                'version' => self::RECOMMENDATION_PROTOCOL_VERSION,
                'operation' => 'recommended_playlists',
                'playlistSource' => $source,
                'limit' => $limit,
                'sources' => [],
            ], 'RECOMMENDATION_PLAYLIST');
        } catch (PlaylistLinkUnavailable $exception) {
            throw new PublicPlaylistCatalogUnavailable('RECOMMENDATION_PLAYLIST_PLUGIN_UNAVAILABLE', previous: $exception);
        }
        return $this->catalogResponse($payload, self::RECOMMENDATION_PROTOCOL_VERSION, $source);
    }

    /**
     * 复验榜单与推荐歌单共用的脱敏响应结构。
     *
     * `version` 和 `source` 必须与当前请求精确一致，响应不得出现白名单外字段；歌单 key 只能是 64 位
     * SHA-256 十六进制摘要，每单最多 100 个通用歌曲身份。任一条目异常会拒绝整份响应，防止部分可信
     * 数据掩盖 Helper 协议漂移。该步骤是纯内存转换，不落库；失败可安全重试且没有补偿动作。
     *
     * @return list<array{key:string,title:string,description:string,entries:list<array{title:string,artists:list<string>,album:?string,durationMs:?int}>}>
     * @throws PublicPlaylistCatalogUnavailable
     */
    private function catalogResponse(mixed $payload, int $version, string $source): array
    {
        if (!is_array($payload) || array_is_list($payload)
            || array_diff(array_keys($payload), ['version', 'source', 'playlists']) !== []
            || ($payload['version'] ?? null) !== $version || ($payload['source'] ?? null) !== $source
            || !is_array($payload['playlists'] ?? null) || !array_is_list($payload['playlists'])
            || count($payload['playlists']) > self::MAX_CATALOG_ITEMS) {
            throw new PublicPlaylistCatalogUnavailable('PUBLIC_PLAYLIST_PROTOCOL_INVALID');
        }
        $result = [];
        foreach ($payload['playlists'] as $playlist) {
            if (!is_array($playlist) || array_is_list($playlist)
                || array_diff(array_keys($playlist), ['key', 'title', 'description', 'entries']) !== []
                || !is_string($playlist['key'] ?? null) || preg_match('/^[a-f0-9]{64}$/', $playlist['key']) !== 1
                || !$this->text($playlist['title'] ?? null, 500) || !is_string($playlist['description'] ?? null)
                || mb_strlen($playlist['description']) > 1000 || !is_array($playlist['entries'] ?? null)
                || !array_is_list($playlist['entries']) || count($playlist['entries']) > 100) {
                throw new PublicPlaylistCatalogUnavailable('PUBLIC_PLAYLIST_PROTOCOL_INVALID');
            }
            $entries = [];
            foreach ($playlist['entries'] as $entry) {
                try {
                    $entries[] = $this->entry($entry, false);
                } catch (PlaylistLinkUnavailable $exception) {
                    throw new PublicPlaylistCatalogUnavailable('PUBLIC_PLAYLIST_ENTRY_INVALID', previous: $exception);
                }
            }
            if ($entries === []) throw new PublicPlaylistCatalogUnavailable('PUBLIC_PLAYLIST_EMPTY');
            $result[] = ['key' => $playlist['key'], 'title' => trim($playlist['title']),
                'description' => trim($playlist['description']), 'entries' => $entries];
        }
        if ($result === []) throw new PublicPlaylistCatalogUnavailable('PUBLIC_PLAYLIST_EMPTY');
        return $result;
    }

    /** @param array<string,mixed> $input */
    private function run(array $input, string $errorPrefix): mixed
    {
        try {
            $process = new Process([$this->binary()]);
            $process->setInput(json_encode($input, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
            $process->setTimeout(45.0);
            $process->run();
            $output = $process->getOutput();
            if (!$process->isSuccessful() || $output === '' || strlen($output) > self::MAX_OUTPUT_BYTES) {
                throw new \RuntimeException($errorPrefix . '_HELPER_FAILED');
            }
            return json_decode($output, true, 32, JSON_THROW_ON_ERROR);
        } catch (PlaylistLinkUnavailable|PublicPlaylistCatalogUnavailable $exception) {
            throw $exception;
        } catch (JsonException|Throwable $exception) {
            $exceptionClass = str_starts_with($errorPrefix, 'PLAYLIST_LINK') ? PlaylistLinkUnavailable::class : PublicPlaylistCatalogUnavailable::class;
            throw new $exceptionClass($errorPrefix . '_UNAVAILABLE', previous: $exception);
        }
    }

    private function binary(): string
    {
        $root = realpath(dirname(__DIR__));
        $candidate = $this->binaryPath ?? (is_string($root) ? $root . '/bin/metadata-scrape-helper.bin' : '');
        $path = realpath($candidate);
        if (!is_string($path) || $path !== $candidate || is_link($candidate) || !is_file($path) || !is_executable($path)
            || ($this->binaryPath === null && (!is_string($root) || !str_starts_with($path, $root . '/bin/')))) {
            throw new PlaylistLinkUnavailable('PLAYLIST_HELPER_UNAVAILABLE');
        }
        return $path;
    }

    private function text(mixed $value, int $maximum): bool
    {
        return is_string($value) && trim($value) !== '' && mb_strlen($value) <= $maximum;
    }

    private function entry(mixed $value, bool $allowEmptyTitle): PlatformPlaylistEntry|array
    {
        $allowed = ['title', 'artists', 'album', 'durationMs'];
        if (!is_array($value) || array_is_list($value) || array_diff(array_keys($value), $allowed) !== []
            || !is_string($value['title'] ?? null) || (!$allowEmptyTitle && trim($value['title']) === '')
            || mb_strlen($value['title']) > 500 || !is_array($value['artists'] ?? null) || !array_is_list($value['artists'])
            || count($value['artists']) > 20 || (isset($value['album']) && !is_string($value['album']))
            || (isset($value['durationMs']) && (!is_int($value['durationMs']) || $value['durationMs'] < 0 || $value['durationMs'] > 86_400_000))) {
            throw new PlaylistLinkUnavailable('PLAYLIST_ENTRY_INVALID');
        }
        $artists = [];
        foreach ($value['artists'] as $artist) {
            if (!is_string($artist) || trim($artist) === '' || mb_strlen($artist) > 300) {
                throw new PlaylistLinkUnavailable('PLAYLIST_ENTRY_INVALID');
            }
            $artists[] = trim($artist);
        }
        $album = is_string($value['album'] ?? null) && trim($value['album']) !== '' ? trim($value['album']) : null;
        $duration = is_int($value['durationMs'] ?? null) && $value['durationMs'] > 0 ? $value['durationMs'] : null;
        if ($allowEmptyTitle) return new PlatformPlaylistEntry(trim($value['title']), $artists, $album, $duration, null);
        return ['title' => trim($value['title']), 'artists' => $artists, 'album' => $album, 'durationMs' => $duration];
    }
}
