<?php

declare(strict_types=1);

namespace plugin\metadata_scrape\app;

use app\application\ResourcePlugin\Contract\MetadataScrapeCompletionRequest;
use app\application\ResourcePlugin\Contract\AlbumScrapeCompletionRequest;
use JsonException;
use Symfony\Component\Process\Process;
use Throwable;

/**
 * MetadataScrapeHelperClient 通过插件包内的 Go 二进制查询固定元数据来源。
 *
 * 可执行文件只能从已安装插件目录的 `bin/metadata-scrape-helper.bin` 解析，不能由环境变量、数据库或
 * 浏览器参数替换。stdin/stdout 使用 v16 单曲协议；文件名模式先在 PHP 插件内解析为规范标题/艺人，
 * 输入的关键词只由本插件的标题派生，绝不继承核心
 * 除扫描冻结的毫秒时长外，不继承 ISRC、文件证据、任务 ID、代理或凭据。PHP 在协议边界复验来源、文本、
 * 发行字段、歌词和输出体积，
 * 进程错误统一失败关闭。此类不访问核心 source-helper、来源配置、Cookie、数据库或媒体路径。
 */
final readonly class MetadataScrapeHelperClient implements MetadataScrapeLookupGateway, MetadataScrapeAlbumLookupGateway
{
    private const PROTOCOL_VERSION = 16;
    private const MAXIMUM_OUTPUT_BYTES = 2_097_152;
    private const DEFAULT_SOURCES = [
        'netease', 'qq', 'kugou', 'kuwo', 'migu', 'soda', 'apple_music', 'musicbrainz', 'lrclib',
    ];

    public function __construct(private ?string $binaryPath = null)
    {
    }

    /**
     * 把通用歌曲请求交给插件随包 Helper，并返回经严格校验的内部结果。
     *
     * Helper 请求只从歌名、艺人、可选专辑和可选专辑艺人派生；当前固定 Helper 协议不理解专辑艺人，
     * 因而它不会被降级拼进关键词或伪造为歌曲艺人。Helper 必须恰好按固定顺序返回每个渠道的一项，任何
     * 缺项、越界字段或混入平台私有数据均使整次调用失败，防止部分结果被误当成“插件已完成优选”。
     * @return list<array<string,mixed>>
     */
    public function lookup(MetadataScrapeCompletionRequest $request): array
    {
        $input = [
            'version' => self::PROTOCOL_VERSION,
            'title' => $request->title,
            'artists' => $request->artists,
            'album' => $request->albumTitle ?? '',
            'durationMs' => $request->durationMs ?? 0,
            'sources' => $this->sources(),
        ];
        if ($input['title'] === '' || $input['artists'] === []) {
            throw $this->failure('METADATA_SCRAPE_HELPER_INPUT_INVALID', 'input', 'INPUT_INVALID', false);
        }
        $output = '';
        try {
            $process = new Process([$this->binary()]);
            $process->setInput(json_encode($input, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
            $process->setTimeout(45.0);
            $process->run();
            $output = $process->getOutput();
            if (!$process->isSuccessful()) throw $this->failure(
                'METADATA_SCRAPE_HELPER_FAILED', 'process', 'PROCESS_FAILED', true,
            );
            if ($output === '') throw $this->failure(
                'METADATA_SCRAPE_HELPER_FAILED', 'process', 'OUTPUT_EMPTY', true,
            );
            if (strlen($output) > self::MAXIMUM_OUTPUT_BYTES) throw $this->failure(
                'METADATA_SCRAPE_HELPER_PROTOCOL_INVALID', 'envelope', 'OUTPUT_TOO_LARGE', false,
            );
        } catch (MetadataScrapeHelperUnavailable $exception) {
            throw $exception;
        } catch (Throwable $exception) {
            throw $this->failure(
                'METADATA_SCRAPE_HELPER_UNAVAILABLE', 'process', 'PROCESS_FAILED', true, previous: $exception,
            );
        }
        $payload = $this->decodePayload($output);
        $this->validateEnvelope($payload, self::PROTOCOL_VERSION, count($input['sources']));
        $results = [];
        foreach ($payload['results'] as $index => $result) $results[] = $this->result($result, $input['sources'][$index]);
        return $results;
    }

    /**
     * 把专辑身份交给独立 album 协议；该请求不包含歌曲标题、时长、歌词或歌曲候选字段。
     *
     * Helper 仍由插件包固定来源目录决定渠道，PHP 只校验版本、来源顺序和专辑字段边界。协议失败抛出
     * 稳定不可用错误，调用方不得把它解释为无匹配。
     *
     * @return list<array<string,mixed>>
     */
    public function lookupAlbum(AlbumScrapeCompletionRequest $request): array
    {
        $input = [
            'version' => 15,
            'operation' => 'album',
            'album' => $request->albumTitle,
            'artists' => $request->albumArtists,
            'musicbrainzReleaseId' => $request->musicBrainzReleaseId,
            'musicbrainzReleaseGroupId' => $request->musicBrainzReleaseGroupId,
            'sources' => $this->sources(),
        ];
        if ($input['album'] === '' || $input['artists'] === []) {
            throw $this->failure('METADATA_SCRAPE_HELPER_INPUT_INVALID', 'input', 'INPUT_INVALID', false);
        }
        $output = '';
        try {
            $process = new Process([$this->binary()]);
            $process->setInput(json_encode($input, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
            $process->setTimeout(45.0);
            $process->run();
            $output = $process->getOutput();
            if (!$process->isSuccessful()) throw $this->failure(
                'METADATA_SCRAPE_HELPER_FAILED', 'process', 'PROCESS_FAILED', true,
            );
            if ($output === '') throw $this->failure(
                'METADATA_SCRAPE_HELPER_FAILED', 'process', 'OUTPUT_EMPTY', true,
            );
            if (strlen($output) > self::MAXIMUM_OUTPUT_BYTES) throw $this->failure(
                'METADATA_SCRAPE_HELPER_PROTOCOL_INVALID', 'envelope', 'OUTPUT_TOO_LARGE', false,
            );
        } catch (MetadataScrapeHelperUnavailable $exception) {
            throw $exception;
        } catch (Throwable $exception) {
            throw $this->failure(
                'METADATA_SCRAPE_HELPER_UNAVAILABLE', 'process', 'PROCESS_FAILED', true, previous: $exception,
            );
        }
        $payload = $this->decodePayload($output);
        $this->validateEnvelope($payload, 15, count($input['sources']));
        $results = [];
        foreach ($payload['results'] as $index => $result) {
            $results[] = $this->albumResult($result, $input['sources'][$index]);
        }
        return $results;
    }

    /**
     * Helper 的来源目录只从插件自有表读取；核心 `music_sources` 仅在旧插件单元测试无表时使用编译期默认值。
     * 空目录仍保持协议合法但不会发起查询，管理员停用全部来源时任务会明确归类为 unavailable。
     *
     * @return list<string>
     */
    private function sources(): array
    {
        try {
            $keys = (new MetadataScrapeRepository())->enabledSourceKeys();
            return array_values(array_intersect($keys, self::DEFAULT_SOURCES));
        } catch (Throwable) {
            return self::DEFAULT_SOURCES;
        }
    }

    /** 返回已安装包内的精确二进制，拒绝测试外的链接、越界路径和不可执行文件。 */
    private function binary(): string
    {
        $packageRoot = realpath(dirname(__DIR__));
        $candidate = $this->binaryPath ?? (is_string($packageRoot)
            ? $packageRoot . '/bin/metadata-scrape-helper.bin' : '');
        $path = realpath($candidate);
        if (!is_string($path) || $path !== $candidate || is_link($candidate) || !is_file($path) || !is_executable($path)
            || ($this->binaryPath === null && (!is_string($packageRoot)
                || !str_starts_with($path, $packageRoot . '/bin/')))) {
            throw $this->failure(
                'METADATA_SCRAPE_HELPER_UNAVAILABLE', 'process', 'BINARY_UNAVAILABLE', true,
            );
        }
        return $path;
    }

    /** @return array<string,mixed> */
    private function result(mixed $value, string $expectedSource): array
    {
        $allowed = ['source', 'status', 'candidateCount', 'best', 'errorCode', 'latencyMs'];
        if (!is_array($value) || array_is_list($value) || array_diff(array_keys($value), $allowed) !== []) {
            throw $this->failure('METADATA_SCRAPE_HELPER_PROTOCOL_INVALID', 'result', 'RESULT_FIELD_INVALID', false,
                $expectedSource, 'result');
        }
        if (($value['source'] ?? null) !== $expectedSource) throw $this->failure(
            'METADATA_SCRAPE_HELPER_PROTOCOL_INVALID', 'result', 'SOURCE_ORDER_MISMATCH', false,
            $expectedSource, 'source',
        );
        if (!in_array($value['status'] ?? null, ['matched', 'low_confidence', 'empty', 'failed', 'not_queried'], true)
            || !is_int($value['candidateCount'] ?? null) || $value['candidateCount'] < 0 || $value['candidateCount'] > 10
            || !is_int($value['latencyMs'] ?? null) || $value['latencyMs'] < 0 || $value['latencyMs'] > 30_000
            || (isset($value['errorCode']) && (!is_string($value['errorCode'])
                || preg_match('/^[A-Z][A-Z0-9_]{2,99}$/D', $value['errorCode']) !== 1))) {
            throw $this->failure('METADATA_SCRAPE_HELPER_PROTOCOL_INVALID', 'result', 'RESULT_FIELD_INVALID', false,
                $expectedSource, 'result');
        }
        try {
            $best = ($value['best'] ?? null) === null ? null : $this->candidate(
                $value['best'], $value['status'] === 'low_confidence',
            );
        } catch (MetadataScrapeHelperUnavailable $failure) {
            throw $this->candidateFailure($failure, $expectedSource);
        }
        if (in_array($value['status'], ['matched', 'low_confidence'], true) !== ($best !== null)) {
            throw $this->failure('METADATA_SCRAPE_HELPER_PROTOCOL_INVALID', 'result', 'RESULT_FIELD_INVALID', false,
                $expectedSource, 'best');
        }
        return ['source' => $expectedSource, 'status' => $value['status'], 'candidateCount' => $value['candidateCount'],
            'best' => $best, 'errorCode' => is_string($value['errorCode'] ?? null) ? $value['errorCode'] : null,
            'latencyMs' => $value['latencyMs']];
    }

    /** @return array<string,mixed> */
    private function albumResult(mixed $value, string $expectedSource): array
    {
        $allowed = ['source', 'status', 'candidateCount', 'best', 'errorCode', 'latencyMs'];
        if (!is_array($value) || array_is_list($value) || array_diff(array_keys($value), $allowed) !== []
            || ($value['source'] ?? null) !== $expectedSource
            || !in_array($value['status'] ?? null, ['matched', 'empty', 'failed', 'not_queried'], true)
            || !is_int($value['candidateCount'] ?? null) || $value['candidateCount'] < 0 || $value['candidateCount'] > 10
            || !is_int($value['latencyMs'] ?? null) || $value['latencyMs'] < 0 || $value['latencyMs'] > 30_000
            || (isset($value['errorCode']) && (!is_string($value['errorCode'])
                || preg_match('/^[A-Z][A-Z0-9_]{2,99}$/D', $value['errorCode']) !== 1))) {
            throw $this->failure('METADATA_SCRAPE_HELPER_PROTOCOL_INVALID', 'result',
                ($value['source'] ?? null) !== $expectedSource ? 'SOURCE_ORDER_MISMATCH' : 'RESULT_FIELD_INVALID',
                false, $expectedSource, ($value['source'] ?? null) !== $expectedSource ? 'source' : 'result');
        }
        try {
            $best = ($value['best'] ?? null) === null ? null : $this->albumCandidate($value['best']);
        } catch (MetadataScrapeHelperUnavailable $failure) {
            throw $this->candidateFailure($failure, $expectedSource);
        }
        if (($value['status'] === 'matched') !== ($best !== null)) {
            throw $this->failure('METADATA_SCRAPE_HELPER_PROTOCOL_INVALID', 'result', 'RESULT_FIELD_INVALID', false,
                $expectedSource, 'best');
        }
        return ['source' => $expectedSource, 'status' => $value['status'], 'candidateCount' => $value['candidateCount'],
            'best' => $best, 'errorCode' => is_string($value['errorCode'] ?? null) ? $value['errorCode'] : null,
            'latencyMs' => $value['latencyMs']];
    }

    /** @return array<string,mixed> */
    private function albumCandidate(mixed $value): array
    {
        if (!is_array($value) || array_is_list($value)
            || !is_string($value['title'] ?? null) || trim($value['title']) === ''
            || !is_array($value['artists'] ?? null) || !array_is_list($value['artists'])
            || !is_int($value['score'] ?? null) || $value['score'] < 0 || $value['score'] > 100
            || !is_array($value['reasons'] ?? null) || !array_is_list($value['reasons'])) {
            throw new MetadataScrapeHelperUnavailable('METADATA_SCRAPE_HELPER_PROTOCOL_INVALID');
        }
        $artists = $this->texts($value['artists'], 20, 300, false);
        $reasons = $this->reasons($value['reasons']);
        if ($artists === [] || $reasons === []) {
            throw new MetadataScrapeHelperUnavailable('METADATA_SCRAPE_HELPER_PROTOCOL_INVALID');
        }
        $result = ['title' => trim($value['title']), 'artists' => $artists,
            'score' => $value['score'], 'reasons' => $reasons];
        foreach (['releaseDate', 'musicbrainzReleaseId', 'musicbrainzReleaseGroupId', 'artworkUrl'] as $field) {
            if (array_key_exists($field, $value) && $value[$field] !== '') $result[$field] = $value[$field];
        }
        if (array_key_exists('discTotal', $value) && $value['discTotal'] !== null) {
            if (!is_int($value['discTotal']) || $value['discTotal'] < 1 || $value['discTotal'] > 999) {
                throw new MetadataScrapeHelperUnavailable('METADATA_SCRAPE_HELPER_PROTOCOL_INVALID');
            }
            $result['discTotal'] = $value['discTotal'];
        }
        return $result;
    }

    /** @return array<string,mixed> */
    private function candidate(mixed $value, bool $allowEmptyReasons = false): array
    {
        $allowed = ['title', 'artists', 'album', 'durationMs', 'artworkUrl', 'trackNumber', 'trackTotal', 'composer',
            'discNumber', 'discTotal', 'releaseDate', 'genres', 'isrc', 'musicbrainzTrackId',
            'musicbrainzArtistId', 'musicbrainzReleaseId', 'musicbrainzReleaseGroupId', 'score', 'reasons', 'lyrics'];
        if (!is_array($value) || array_is_list($value) || array_diff(array_keys($value), $allowed) !== []
            || ($title = $this->text($value['title'] ?? null, 500)) === null || !is_int($value['score'] ?? null)
            || $value['score'] < 0 || $value['score'] > 100 || !is_array($value['artists'] ?? null)
            || !array_is_list($value['artists']) || !is_array($value['reasons'] ?? null) || !array_is_list($value['reasons'])) {
            throw new MetadataScrapeHelperUnavailable('METADATA_SCRAPE_HELPER_PROTOCOL_INVALID');
        }
        $artists = $this->texts($value['artists'], 20, 300, false);
        $reasons = $this->reasons($value['reasons']);
        $trackNumber = $this->positiveInteger($value['trackNumber'] ?? null, 9_999);
        $trackTotal = $this->positiveInteger($value['trackTotal'] ?? null, 9_999);
        $discNumber = $this->positiveInteger($value['discNumber'] ?? null, 999);
        $discTotal = $this->positiveInteger($value['discTotal'] ?? null, 999);
        // 低置信候选允许没有评分原因：它仍是 Helper 返回的有界诊断，不能因此把整次插件调用判成协议失败。
        // 匹配候选仍必须至少有一条原因；艺人列表和音轨/碟号关系在两种状态下都必须有效。
        if ($artists === [] || (!$allowEmptyReasons && $reasons === [])
            || ($trackNumber !== null && $trackTotal !== null && $trackNumber > $trackTotal)
            || ($discNumber !== null && $discTotal !== null && $discNumber > $discTotal)) {
            throw new MetadataScrapeHelperUnavailable('METADATA_SCRAPE_HELPER_PROTOCOL_INVALID');
        }
        $releaseDate = $this->releaseDate($value['releaseDate'] ?? null);
        return ['title' => $title, 'artists' => $artists, 'album' => $this->text($value['album'] ?? null, 500),
            'composer' => $this->text($value['composer'] ?? null, 300),
            'durationMs' => $this->positiveInteger($value['durationMs'] ?? null, 86_400_000),
            'artworkUrl' => $this->artworkUrl($value['artworkUrl'] ?? null), 'trackNumber' => $trackNumber,
            'trackTotal' => $trackTotal, 'discNumber' => $discNumber, 'discTotal' => $discTotal,
            'releaseDate' => $releaseDate, 'genres' => $this->texts($value['genres'] ?? [], 16, 100, true),
            'isrc' => $this->isrc($value['isrc'] ?? null),
            'musicbrainzTrackId' => $this->musicBrainzId($value['musicbrainzTrackId'] ?? null),
            'musicbrainzArtistId' => $this->musicBrainzId($value['musicbrainzArtistId'] ?? null),
            'musicbrainzReleaseId' => $this->musicBrainzId($value['musicbrainzReleaseId'] ?? null),
            'musicbrainzReleaseGroupId' => $this->musicBrainzId($value['musicbrainzReleaseGroupId'] ?? null),
            'score' => $value['score'], 'reasons' => $reasons, 'lyrics' => $this->lyrics($value['lyrics'] ?? null)];
    }

    /** @return list<string> */
    private function texts(mixed $values, int $maximumItems, int $maximumLength, bool $allowEmpty): array
    {
        if (!is_array($values) || !array_is_list($values) || count($values) > $maximumItems) {
            throw new MetadataScrapeHelperUnavailable('METADATA_SCRAPE_HELPER_PROTOCOL_INVALID');
        }
        $result = [];
        foreach ($values as $value) {
            $text = $this->text($value, $maximumLength);
            if ($text === null) { if ($allowEmpty) continue; throw new MetadataScrapeHelperUnavailable('METADATA_SCRAPE_HELPER_PROTOCOL_INVALID'); }
            $result[] = $text;
        }
        return array_values(array_unique($result));
    }
    /** @return list<string> */
    private function reasons(array $values): array
    {
        if (count($values) > 8) throw new MetadataScrapeHelperUnavailable('METADATA_SCRAPE_HELPER_PROTOCOL_INVALID');
        foreach ($values as $reason) if (!is_string($reason) || preg_match('/^[A-Z][A-Z0-9_]{1,79}$/D', $reason) !== 1) {
            throw new MetadataScrapeHelperUnavailable('METADATA_SCRAPE_HELPER_PROTOCOL_INVALID');
        }
        return array_values(array_unique($values));
    }
    private function text(mixed $value, int $maximumLength): ?string
    {
        if (!is_string($value) || trim($value) === '' || mb_strlen(trim($value)) > $maximumLength) return null;
        return trim($value);
    }
    private function positiveInteger(mixed $value, int $maximum): ?int
    {
        if ($value === null) return null;
        if (!is_int($value) || $value < 1 || $value > $maximum) throw new MetadataScrapeHelperUnavailable('METADATA_SCRAPE_HELPER_PROTOCOL_INVALID');
        return $value;
    }
    private function releaseDate(mixed $value): ?string
    {
        if ($value === null) return null;
        if (!is_string($value) || preg_match('/^(?:1\d{3}|2\d{3})(?:-(?:0[1-9]|1[0-2])(?:-(?:0[1-9]|[12]\d|3[01]))?)?$/D', $value) !== 1) {
            throw new MetadataScrapeHelperUnavailable('METADATA_SCRAPE_HELPER_PROTOCOL_INVALID');
        }
        if (strlen($value) === 10) {
            $date = \DateTimeImmutable::createFromFormat('!Y-m-d', $value);
            if (!$date instanceof \DateTimeImmutable || $date->format('Y-m-d') !== $value) {
                throw new MetadataScrapeHelperUnavailable('METADATA_SCRAPE_HELPER_PROTOCOL_INVALID');
            }
        }
        return $value;
    }
    private function isrc(mixed $value): ?string
    {
        if ($value === null || $value === '') return null;
        if (!is_string($value) || preg_match('/^[A-Z]{2}[A-Z0-9]{3}[0-9]{7}$/D', $value) !== 1) throw new MetadataScrapeHelperUnavailable('METADATA_SCRAPE_HELPER_PROTOCOL_INVALID');
        return $value;
    }
    private function musicBrainzId(mixed $value): ?string
    {
        if ($value === null || $value === '') return null;
        if (!is_string($value) || preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/D', $value) !== 1) {
            throw new MetadataScrapeHelperUnavailable('METADATA_SCRAPE_HELPER_PROTOCOL_INVALID');
        }
        return $value;
    }
    /** 允许来源返回 HTTP 封面；核心下载边界会校验固定 CDN 并规范为 HTTPS 后再请求。 */
    private function artworkUrl(mixed $value): ?string
    {
        if ($value === null || $value === '') return null;
        if (!is_string($value) || strlen($value) > 2_000 || filter_var($value, FILTER_VALIDATE_URL) === false
            || !in_array(parse_url($value, PHP_URL_SCHEME), ['http', 'https'], true)) {
            throw new MetadataScrapeHelperUnavailable('METADATA_SCRAPE_HELPER_PROTOCOL_INVALID');
        }
        return $value;
    }
    private function lyrics(mixed $value): ?string
    {
        if ($value === null || $value === '') return null;
        if (!is_string($value) || strlen($value) > 1_048_576 || !mb_check_encoding($value, 'UTF-8')) throw new MetadataScrapeHelperUnavailable('METADATA_SCRAPE_HELPER_PROTOCOL_INVALID');
        return $value;
    }

    /** 解码 Helper 输出；JSON 语法、UTF-8 或深度错误均归入不可重试的协议包络故障。 */
    private function decodePayload(string $output): mixed
    {
        try {
            return json_decode($output, true, 32, JSON_THROW_ON_ERROR);
        } catch (JsonException $failure) {
            throw $this->failure(
                'METADATA_SCRAPE_HELPER_PROTOCOL_INVALID', 'envelope', 'JSON_INVALID', false, previous: $failure,
            );
        }
    }

    /**
     * 校验不含业务正文的顶层包络；版本、结果数量分别形成稳定诊断，便于定位偶发协议错误。
     *
     * @param mixed $payload Helper JSON 解码值
     */
    private function validateEnvelope(mixed $payload, int $version, int $resultCount): void
    {
        if (!is_array($payload) || array_is_list($payload) || array_keys($payload) !== ['version', 'results']
            || !is_array($payload['results'] ?? null) || !array_is_list($payload['results'])) {
            throw $this->failure(
                'METADATA_SCRAPE_HELPER_PROTOCOL_INVALID', 'envelope', 'ENVELOPE_KEYS_INVALID', false,
            );
        }
        if (($payload['version'] ?? null) !== $version) throw $this->failure(
            'METADATA_SCRAPE_HELPER_PROTOCOL_INVALID', 'envelope', 'VERSION_MISMATCH', false, field: 'version',
        );
        if (count($payload['results']) !== $resultCount) throw $this->failure(
            'METADATA_SCRAPE_HELPER_PROTOCOL_INVALID', 'envelope', 'RESULT_COUNT_MISMATCH', false, field: 'results',
        );
    }

    /** 把候选校验错误绑定到当前固定来源，仍不复制候选值或 Helper 正文。 */
    private function candidateFailure(
        MetadataScrapeHelperUnavailable $failure,
        string $source,
    ): MetadataScrapeHelperUnavailable {
        $diagnostics = $failure->safeDiagnostics();
        return new MetadataScrapeHelperUnavailable($failure->getMessage(), [
            'phase' => 'candidate', 'reason' => 'CANDIDATE_FIELD_INVALID', 'retryable' => false,
            'source' => $source, 'field' => $diagnostics['field'] ?? 'candidate',
        ], $failure);
    }

    /** 创建只含固定分类的异常；参数均为本类常量或已校验来源/字段名。 */
    private function failure(
        string $errorCode,
        string $phase,
        string $reason,
        bool $retryable,
        ?string $source = null,
        ?string $field = null,
        ?Throwable $previous = null,
    ): MetadataScrapeHelperUnavailable {
        return new MetadataScrapeHelperUnavailable($errorCode, [
            'phase' => $phase, 'reason' => $reason, 'retryable' => $retryable,
            'source' => $source, 'field' => $field,
        ], $previous);
    }
}
