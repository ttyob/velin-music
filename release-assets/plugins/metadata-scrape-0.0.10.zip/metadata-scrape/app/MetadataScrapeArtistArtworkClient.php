<?php

declare(strict_types=1);

namespace plugin\metadata_scrape\app;

use app\application\ResourcePlugin\Contract\ArtistArtworkScrapeRequest;
use Symfony\Component\Process\Process;
use Throwable;

/**
 * 调用插件自带 Helper 的艺人资料图协议 v2。
 *
 * 请求只包含代表歌曲和插件自有来源，Helper 返回的 URL/平台字段不会写入插件数据库；调用方收到的
 * URL 可来自固定来源的 HTTP 或 HTTPS；仍须经过核心图片下载器的固定 CDN、HTTPS 升级、DNS、MIME、尺寸
 * 和内容校验。任何进程或协议错误统一失败关闭。
 */
final readonly class MetadataScrapeArtistArtworkClient
{
    private const PROTOCOL_VERSION = 2;
    private const SOURCES = ['netease', 'qq', 'kugou', 'kuwo', 'migu', 'soda', 'apple_music'];

    public function __construct(private ?string $binaryPath = null)
    {
    }

    /** @return list<array<string,mixed>> */
    public function lookup(ArtistArtworkScrapeRequest $request): array
    {
        $sources = $this->sources();
        if ($sources === []) return [];
        $input = [
            'version' => self::PROTOCOL_VERSION, 'operation' => 'artist_artwork',
            'artist' => $request->artist,
            'representativeSong' => [
                'title' => $request->representativeTitle, 'artists' => $request->representativeArtists,
                'album' => $request->representativeAlbum ?? '', 'durationMs' => $request->representativeDurationMs ?? 0,
            ],
            'sources' => $sources,
        ];
        try {
            $process = new Process([$this->binary()]);
            $process->setInput(json_encode($input, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
            $process->setTimeout(45.0);
            $process->run();
            $output = $process->getOutput();
            if (!$process->isSuccessful() || $output === '' || strlen($output) > 524_288) {
                throw new MetadataScrapeHelperUnavailable('METADATA_SCRAPE_HELPER_FAILED');
            }
            $payload = json_decode($output, true, 24, JSON_THROW_ON_ERROR);
        } catch (MetadataScrapeHelperUnavailable $exception) {
            throw $exception;
        } catch (Throwable $exception) {
            throw new MetadataScrapeHelperUnavailable('METADATA_SCRAPE_HELPER_UNAVAILABLE', 0, $exception);
        }
        if (!is_array($payload) || array_diff(array_keys($payload), ['version', 'results']) !== []
            || ($payload['version'] ?? null) !== self::PROTOCOL_VERSION || !is_array($payload['results'] ?? null)
            || !array_is_list($payload['results']) || count($payload['results']) !== count($sources)) {
            throw new MetadataScrapeHelperUnavailable('METADATA_SCRAPE_HELPER_PROTOCOL_INVALID');
        }
        $results = [];
        foreach ($payload['results'] as $index => $value) $results[] = $this->result($value, $sources[$index]);
        return $results;
    }

    /** @return list<string> */
    private function sources(): array
    {
        try {
            return array_values(array_intersect((new MetadataScrapeRepository())->enabledSourceKeys(), self::SOURCES));
        } catch (Throwable) {
            return self::SOURCES;
        }
    }

    private function binary(): string
    {
        $root = realpath(dirname(__DIR__));
        $candidate = $this->binaryPath ?? (is_string($root) ? $root . '/bin/metadata-scrape-helper.bin' : '');
        $path = realpath($candidate);
        if (!is_string($path) || $path !== $candidate || is_link($candidate) || !is_file($path) || !is_executable($path)) {
            throw new MetadataScrapeHelperUnavailable('METADATA_SCRAPE_HELPER_UNAVAILABLE');
        }
        return $path;
    }

    /** @return array<string,mixed> */
    private function result(mixed $value, string $source): array
    {
        $allowed = ['source', 'status', 'candidateCount', 'best', 'errorCode', 'latencyMs'];
        if (!is_array($value) || array_is_list($value) || array_diff(array_keys($value), $allowed) !== []
            || ($value['source'] ?? null) !== $source
            || !in_array($value['status'] ?? null, ['matched', 'empty', 'failed', 'not_queried'], true)
            || !is_int($value['candidateCount'] ?? null) || $value['candidateCount'] < 0 || $value['candidateCount'] > 10
            || (isset($value['errorCode']) && (!is_string($value['errorCode'])
                || preg_match('/^[A-Z][A-Z0-9_]{2,99}$/D', $value['errorCode']) !== 1))
            || (isset($value['latencyMs']) && (!is_int($value['latencyMs']) || $value['latencyMs'] < 0 || $value['latencyMs'] > 30_000))) {
            throw new MetadataScrapeHelperUnavailable('METADATA_SCRAPE_HELPER_PROTOCOL_INVALID');
        }
        $best = null;
        if (isset($value['best'])) {
            $candidate = $value['best'];
            $candidateAllowed = ['artistName', 'artworkUrl', 'score', 'reasons'];
            if (!is_array($candidate) || array_is_list($candidate) || array_diff(array_keys($candidate), $candidateAllowed) !== []
                || !is_string($candidate['artistName'] ?? null)
                || trim($candidate['artistName']) === '' || !is_string($candidate['artworkUrl'] ?? null)
                || trim($candidate['artworkUrl']) === '' || filter_var($candidate['artworkUrl'], FILTER_VALIDATE_URL) === false
                || !in_array(parse_url($candidate['artworkUrl'], PHP_URL_SCHEME), ['http', 'https'], true)
                || !is_int($candidate['score'] ?? null)
                || $candidate['score'] < 0 || $candidate['score'] > 100 || !is_array($candidate['reasons'] ?? null)) {
                throw new MetadataScrapeHelperUnavailable('METADATA_SCRAPE_HELPER_PROTOCOL_INVALID');
            }
            $reasons = array_values(array_filter($candidate['reasons'], static fn (mixed $reason): bool =>
                is_string($reason) && preg_match('/^[A-Z][A-Z0-9_]{1,79}$/D', $reason) === 1));
            if (count($reasons) !== count($candidate['reasons'])) {
                throw new MetadataScrapeHelperUnavailable('METADATA_SCRAPE_HELPER_PROTOCOL_INVALID');
            }
            $best = [
                'artistName' => trim($candidate['artistName']), 'artworkUrl' => trim($candidate['artworkUrl']),
                'score' => $candidate['score'], 'reasons' => $reasons,
            ];
        }
        if (($value['status'] === 'matched') !== ($best !== null)) {
            throw new MetadataScrapeHelperUnavailable('METADATA_SCRAPE_HELPER_PROTOCOL_INVALID');
        }
        return ['source' => $source, 'status' => $value['status'], 'candidateCount' => $value['candidateCount'],
            'best' => $best];
    }
}
