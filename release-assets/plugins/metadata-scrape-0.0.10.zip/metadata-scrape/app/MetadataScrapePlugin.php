<?php

declare(strict_types=1);

namespace plugin\metadata_scrape\app;

use app\application\ResourcePlugin\Contract\ExternalMetadataScrapeHook;
use app\application\ResourcePlugin\Contract\ExternalAlbumScrapeHook;
use app\application\ResourcePlugin\Contract\MetadataScrapeCompletionRequest;
use app\application\ResourcePlugin\Contract\MetadataScrapeCompletionResult;
use app\application\ResourcePlugin\Contract\AlbumScrapeCompletionRequest;
use app\application\ResourcePlugin\Contract\AlbumScrapeCompletionResult;
use app\application\ResourcePlugin\Contract\MetadataScrapeAdminHook;
use app\application\ResourcePlugin\Contract\MetadataScrapeLogExportHook;
use app\application\ResourcePlugin\Contract\PluginDatabaseLifecycle;
use app\application\ResourcePlugin\Contract\PluginDatabaseBaselineCollapse;
use app\application\ResourcePlugin\Contract\PluginWorkerHook;
use app\application\ResourcePlugin\Contract\PluginRecommendationProviderHook;
use app\application\ResourcePlugin\Contract\RecommendationSongIdentity;
use app\application\Artist\ArtistProfileScrapeJobService;
use app\application\Metadata\AlbumMetadataScrapeJobService;
use app\application\Metadata\MetadataEntityScrapeIntentService;
use app\application\ResourcePlugin\Contract\ExternalArtistArtworkHook;
use app\application\ResourcePlugin\Contract\ExternalArtistProfileHook;
use app\application\ResourcePlugin\Contract\ExternalPlaylistIdentificationHook;
use app\application\ResourcePlugin\Contract\ExternalPlaylistSyncHook;
use app\application\ResourcePlugin\Contract\ArtistProfileScrapeRequest;
use app\application\ResourcePlugin\Contract\ArtistProfileScrapeResult;
use app\application\ResourcePlugin\Contract\ArtistArtworkScrapeRequest;
use app\application\ResourcePlugin\Contract\ArtistArtworkScrapeResult;
use Throwable;

/**
 * 元数据刮削插件在包内完成第三方查询、评分、字段补全与唯一最终结论选择。
 *
 * 歌曲查询只依赖核心稳定的通用 DTO 和随包 Go Helper；艺人资料查询使用本包固定的 HTTPS 客户端。候选、
 * Provider、原始响应、第三方 URL 和平台 ID 均停留在本包内，核心只接收最终歌曲或艺人资料结论。插件只写入
 * 自身的来源、任务和脱敏日志表；艺人 Worker 钩子可以调用核心任务服务来领取租约，但不绕过核心事务、CAS
 * 或授权边界，也不直接修改歌曲、艺人业务数据、媒体文件或缓存。
 */
final readonly class MetadataScrapePlugin implements ExternalMetadataScrapeHook, ExternalAlbumScrapeHook, ExternalArtistArtworkHook, ExternalArtistProfileHook, ExternalPlaylistIdentificationHook, ExternalPlaylistSyncHook, PluginRecommendationProviderHook, MetadataScrapeAdminHook, MetadataScrapeLogExportHook, PluginDatabaseBaselineCollapse, PluginWorkerHook
{
    private const KEY = 'metadata-scrape';

    public function __construct(
        private MetadataScrapeLookupGateway $lookup = new MetadataScrapeHelperClient(),
        private MetadataScrapeArtistProfileLookupGateway $profileLookup = new MetadataScrapeArtistProfileClient(),
        private ArtistProfileScrapeJobService $profileJobs = new ArtistProfileScrapeJobService(),
        private AlbumMetadataScrapeJobService $albumJobs = new AlbumMetadataScrapeJobService(),
        private MetadataEntityScrapeIntentService $entityIntents = new MetadataEntityScrapeIntentService(),
        private MetadataScrapePlaylistHelperClient $playlistHelper = new MetadataScrapePlaylistHelperClient(),
    )
    {
    }

    public function descriptor(): array
    {
        return [
            'key' => self::KEY,
            'name' => '元数据刮削',
            'version' => '0.0.10',
            'capabilities' => ['metadata_scrape', 'metadata_album', 'metadata_artist_artwork', 'metadata_artist_profile', 'metadata_artist_database', 'playlist_identification', 'playlist_sync', 'recommendation_provider', 'library_file_inspection', 'worker', 'database_lifecycle'],
            'description' => '由插件自带 Go Helper 完成歌曲多渠道优选、平台歌单、推荐歌单与缺失歌曲详情，并在插件内完成艺人资料与艺人辅助库管理；页面管理来源、任务、文件检查、上传状态和详细刮削日志。',
        ];
    }

    public function probe(): array
    {
        return ['available' => true, 'errorCode' => null];
    }

    /**
     * 识别公开平台歌单链接；核心随后执行本地授权匹配和幂等事务。
     *
     * URL、平台私有 ID 和原始响应只在插件 Helper 边界内存在，插件失败直接向核心报告稳定歌单错误，
     * 不回退到旧核心来源执行器。
     */
    public function identifyPlaylist(string $source, string $link): \app\application\Playlist\PlatformPlaylistDocument
    {
        return $this->playlistHelper->identify($source, $link);
    }

    /** @return list<array{key:string,name:string}> */
    public function playlistSources(): array
    {
        return [
            ['key' => 'netease', 'name' => '网易云音乐'], ['key' => 'qq', 'name' => 'QQ 音乐'],
            ['key' => 'kugou', 'name' => '酷狗音乐'], ['key' => 'kuwo', 'name' => '酷我音乐'],
            ['key' => 'migu', 'name' => '咪咕音乐'], ['key' => 'soda', 'name' => '汽水音乐'],
            ['key' => 'apple_music', 'name' => 'Apple Music'],
        ];
    }

    /** @return list<array{key:string,name:string,loginRequired:bool}> */
    public function playlistProviders(): array
    {
        return [
            ['key' => 'netease', 'name' => '网易云音乐', 'loginRequired' => false],
            ['key' => 'qq', 'name' => 'QQ 音乐', 'loginRequired' => false],
            ['key' => 'kugou', 'name' => '酷狗音乐', 'loginRequired' => false],
        ];
    }

    /** @return list<array{key:string,title:string,description:string,entries:list<array{title:string,artists:list<string>,album:?string,durationMs:?int}>}> */
    public function playlistCatalog(string $source): array
    {
        return $this->playlistHelper->catalog($source);
    }

    /**
     * 读取指定平台歌单的最新条目；key 只在插件内用于目录匹配，不会泄露到核心业务实体。
     */
    public function syncPlaylist(string $source, string $playlistKey): \app\application\Playlist\PlatformPlaylistDocument
    {
        foreach ($this->playlistHelper->catalog($source) as $item) {
            if ($item['key'] !== $playlistKey) continue;
            return new \app\application\Playlist\PlatformPlaylistDocument(
                $source,
                $item['title'],
                array_map(static fn (array $entry): \app\application\Playlist\PlatformPlaylistEntry => new \app\application\Playlist\PlatformPlaylistEntry(
                    $entry['title'], $entry['artists'], $entry['album'], $entry['durationMs'], null,
                ), $item['entries']),
            );
        }
        throw new \app\application\Recommendation\PublicPlaylistCatalogUnavailable('PUBLIC_PLAYLIST_NOT_FOUND');
    }

    /**
     * 从插件公开推荐歌单中提取每日歌曲身份。
     *
     * 当前公开推荐接口不依赖账号 Cookie，偏好 seeds 仅为未来个性化适配保留且不会交给第三方。结果按歌单和
     * 曲序稳定去重，Helper/网络失败直接抛出，由核心使用本地每日随机推荐降级；方法不写任务表、播放
     * 历史或歌单，也不返回平台 ID 和资源地址。
     *
     * @param list<RecommendationSongIdentity> $seeds
     * @return list<RecommendationSongIdentity>
     */
    public function dailyRecommendations(array $seeds, int $limit): array
    {
        $songs = [];
        foreach ($this->recommendedPlaylists(3) as $playlist) {
            foreach ($playlist['songs'] as $song) {
                $identity = $song instanceof RecommendationSongIdentity ? $song : null;
                if (!$identity instanceof RecommendationSongIdentity) continue;
                $key = hash('sha256', json_encode($identity->toArray(), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));
                $songs[$key] ??= $identity;
                if (count($songs) >= max(1, min(100, $limit))) break 2;
            }
        }
        return array_values($songs);
    }

    /**
     * 相似歌曲的第三方适配入口。
     *
     * 当前 Helper 没有可证明身份一致且不依赖平台 ID 的相似度协议，因此返回空列表，让核心使用共同艺人、
     * 专辑和流派的授权本地算法。空结果是“插件没有额外候选”，不是故障，也不会触发下载或刮削任务。
     *
     * @return list<RecommendationSongIdentity>
     */
    public function similarSongs(RecommendationSongIdentity $seed, int $limit): array
    {
        return [];
    }

    /**
     * 相似艺人的第三方适配入口；当前无平台 ID 无关的可靠协议，核心继续使用共同署名与流派算法。
     *
     * @return list<array{name:string}>
     */
    public function similarArtists(string $artistName, int $limit): array
    {
        return [];
    }

    /**
     * 返回公开推荐歌单的脱敏歌曲身份。
     *
     * 插件调用独立的 v17 公开推荐 Helper；摘要 key、标题、说明和通用歌曲身份是唯一输出。核心随后
     * 重新做本地匹配与用户授权，未入库歌曲只保留 identity。一次最多返回 20 个歌单、每单 100 首，
     * 网络和协议失败不产生持久化副作用。
     *
     * @return list<array{key:string,title:string,description:string,songs:list<RecommendationSongIdentity>}>
     */
    public function recommendedPlaylists(int $limit): array
    {
        $result = [];
        $limit = max(1, min(20, $limit));
        foreach ($this->playlistHelper->recommendations('netease', $limit) as $playlist) {
            $songs = [];
            foreach ($playlist['entries'] as $entry) {
                $songs[] = new RecommendationSongIdentity(
                    $entry['title'], $entry['artists'], $entry['album'], $entry['durationMs'],
                );
            }
            if ($songs === []) continue;
            $result[] = ['key' => $playlist['key'], 'title' => $playlist['title'],
                'description' => $playlist['description'], 'songs' => $songs];
        }
        return $result;
    }

    /**
     * 查询一个未入库歌曲身份的安全详情，不创建 metadata_scrape_tasks 记录。
     *
     * 查询复用歌曲 Helper 与最终身份复验，但只返回通用文本、时长及歌词/封面存在性；歌词正文、图片
     * URL、渠道、候选、分数和平台 ID 均留在本次内存中。Helper 故障向核心抛出并由 API 标记 Provider
     * 不可用，正常 unmatched/unavailable 返回 null。该入口不下载资源、不发布文件、不修改业务库。
     *
     * @return array<string,mixed>|null
     */
    public function missingSongDetail(RecommendationSongIdentity $identity): ?array
    {
        $request = MetadataScrapeCompletionRequest::fromMetadata(
            $identity->title, $identity->artists, $identity->album, durationMs: $identity->durationMs,
        );
        $results = [];
        foreach ($this->lookup->lookup($request) as $result) {
            $result['_queryPosition'] = 0;
            $results[] = $result;
        }
        $final = $this->finalizeLookupResults($results, [$request]);
        if ($final->status !== MetadataScrapeCompletionResult::MATCHED || !is_array($final->metadata)) return null;
        $allowed = ['title', 'artists', 'albumTitle', 'albumArtists', 'releaseDate', 'genres', 'composer', 'isrc'];
        $detail = array_intersect_key($final->metadata, array_flip($allowed));
        $detail['durationMs'] = $identity->durationMs;
        $detail['hasLyrics'] = $final->lyricsCandidates !== [];
        $detail['hasArtwork'] = $final->artworkUrls !== [] || $final->albumArtworkUrls !== [];
        return $detail;
    }

    /**
     * 插件自有数据库的版本化安装边界。
     *
     * 版本 2 创建来源、任务和日志表，并为旧任务补充可空时长证据；首次安装仍只从旧核心 `music_sources`
     * 迁移启停与优先级快照。迁移后
     * Helper 只读插件目录；核心旧来源表仅作为历史配置兼容，不再参与歌单或元数据网络请求。DDL 和初始化
     * 数据由宿主事务回滚。
     */
    public function databaseVersion(): int { return 2; }

    /** 历史 1-3 账本均可由最终表结构幂等接管；未知未来版本继续失败关闭。 */
    public function supportsLegacyDatabaseVersion(int $fromVersion): bool
    {
        return $fromVersion >= 0 && $fromVersion <= 3;
    }

    public function installDatabase(int $fromVersion): void
    {
        (new MetadataScrapeRepository())->install($fromVersion);
    }

    public function uninstallDatabase(): void
    {
        (new MetadataScrapeRepository())->uninstall();
    }

    public function metadataSources(): array
    {
        return (new MetadataScrapeRepository())->sources();
    }

    public function updateMetadataSource(string $sourceKey, array $command): array
    {
        return (new MetadataScrapeRepository())->updateSource($sourceKey, $command);
    }

    public function metadataTasks(array $query): array
    {
        return (new MetadataScrapeRepository())->tasks($query);
    }

    /**
     * 清理插件任务历史；仅删除 matched、unmatched、unavailable 和 failed 终态任务及其日志，
     * 保留 running 任务以免后台 Worker 失去正在写入的审计记录。核心刮削任务、媒体文件和扫描历史
     * 不属于插件表，因此不会被此操作触碰；重复清理是幂等的并返回本次实际删除数量。
     *
     * @return array{deletedCount:int,activeCount:int}
     */
    public function clearMetadataTasks(): array
    {
        return (new MetadataScrapeRepository())->clearTasks();
    }

    public function metadataTask(string $taskId): array
    {
        return (new MetadataScrapeRepository())->task($taskId);
    }

    /** 生成单条插件刮削任务的私有脱敏诊断文件；导出失败不改变任务或日志状态。 */
    public function exportMetadataTaskLog(string $taskId): array
    {
        return (new MetadataScrapeRepository())->exportTaskLog($taskId);
    }

    /**
     * 仅重放失败或暂不可用的元数据任务；旧任务行保持不变的身份和创建时间，重试次数写回同一行，新的
     * Helper 调用只追加到该任务的日志序列。Repository 在启动 Helper 前完成身份校验和活动任务冲突检查，
     * 确保重复点击不会创建第二条插件任务记录。
     *
     * @return array{accepted:bool,status:string,confidence:?int}
     */
    public function retryMetadataTask(string $taskId): array
    {
        $result = $this->scrapeMetadata((new MetadataScrapeRepository())->retryRequest($taskId));
        return ['accepted' => true, 'status' => $result->status, 'confidence' => $result->confidence];
    }

    /**
     * 提供插件自己的艺人辅助库管理边界。
     *
     * 上传会话、SQLite 校验、锁和原子发布均由插件调用的存储服务负责；核心只提供同源管理路由和
     * `manage_system` 授权，不再把艺人库作为系统设置资源暴露。物理目录继续使用既有固定位置，保证
     * 已发布库和核心只读身份查询不中断。
     */
    public function artistDatabaseStatus(): array
    {
        return (new MetadataScrapeArtistDatabaseService())->status();
    }

    public function startArtistDatabaseUpload(string $fileName, int $totalBytes): array
    {
        $service = new MetadataScrapeArtistDatabaseService();
        return ['upload' => $service->start($fileName, $totalBytes), 'chunkBytes' => 8 * 1024 * 1024];
    }

    public function appendArtistDatabaseChunk(string $uploadId, int $offset, string $bytes, string $sha256): array
    {
        return ['upload' => (new MetadataScrapeArtistDatabaseService())->append($uploadId, $offset, $bytes, $sha256)];
    }

    public function completeArtistDatabaseUpload(string $uploadId): array
    {
        return (new MetadataScrapeArtistDatabaseService())->complete($uploadId);
    }

    public function cancelArtistDatabaseUpload(string $uploadId): void
    {
        (new MetadataScrapeArtistDatabaseService())->cancel($uploadId);
    }

    /**
     * 对一个通用歌曲身份请求运行包内多渠道查询，并只输出插件已经选择的一条结论。
     *
     * 所有达到 85 分的内部候选按分数和固定渠道顺序稳定选择。第一名决定作品身份，其余候选还必须与
     * 第一名标题一致且至少共享一名艺人，才可分别补充缺失字段、歌词和封面。资源选择不再绑定单一渠道：
     * 按已排序可信候选取首个非空歌词与合法 HTTP(S) 图片，避免某个平台临时缺资源时丢弃其他同身份渠道
     * 的有效结果，同时拒绝 Live、翻唱或同名作品混入。核心不会看到内部候选，也不能再次排序。Helper
     * 进程或协议失败抛出异常由核心回退；所有渠道失败返回 unavailable，正常无匹配返回 unmatched。
     */
    public function scrapeMetadata(MetadataScrapeCompletionRequest $request): MetadataScrapeCompletionResult
    {
        $repository = new MetadataScrapeRepository();
        $taskId = $repository->beginAttempt($request);
        $requests = $request->mode === MetadataScrapeCompletionRequest::MODE_FILENAME
            ? (new MetadataScrapeFilenameParser())->requests($request) : [$request];
        if ($requests === []) {
            $repository->finish($taskId, MetadataScrapeCompletionResult::UNMATCHED, null, null, null);
            return new MetadataScrapeCompletionResult(MetadataScrapeCompletionResult::UNMATCHED);
        }
        $results = [];
        try {
            foreach ($requests as $requestPosition => $query) {
                foreach ($this->lookup->lookup($query) as $result) {
                    // 查询位置只在当前调用栈中绑定候选与解析身份，不进入核心 DTO、日志或数据库字段。
                    $result['_queryPosition'] = $requestPosition;
                    $results[] = $result;
                    $status = (string) ($result['status'] ?? 'failed');
                    $level = $status === 'failed' ? 'warning' : 'info';
                    $details = [
                        'candidateCount' => (int) ($result['candidateCount'] ?? 0),
                        'latencyMs' => (int) ($result['latencyMs'] ?? 0),
                        'queryPosition' => $requestPosition,
                    ];
                    if (is_array($result['best'] ?? null)) {
                        $details['score'] = (int) ($result['best']['score'] ?? 0);
                        $details['reasons'] = is_array($result['best']['reasons'] ?? null) ? array_values($result['best']['reasons']) : [];
                        $details['dataTypes'] = $this->candidateDataTypes($result['best']);
                    }
                    if (is_string($result['errorCode'] ?? null)) $details['errorCode'] = $result['errorCode'];
                    $repository->log($taskId, $level, 'lookup', is_string($result['source'] ?? null) ? $result['source'] : null,
                        $status, 'LOOKUP_' . strtoupper($status), '插件查询阶段已完成', $details);
                }
            }
        } catch (Throwable $failure) {
            // Helper 故障不能伪装成无匹配；诊断只取异常的封闭枚举，核心保留文件事实但不回退固定平台。
            $errorCode = $failure->getMessage() !== '' && preg_match('/^[A-Z][A-Z0-9_]{2,99}$/D', $failure->getMessage()) === 1
                ? $failure->getMessage() : 'METADATA_SCRAPE_HELPER_FAILED';
            $details = ['errorCode' => $errorCode];
            if ($failure instanceof MetadataScrapeHelperUnavailable) {
                $details += $failure->safeDiagnostics();
            }
            $repository->log($taskId, 'error', 'lookup', $details['source'] ?? null,
                'failed', 'HELPER_FAILED', '插件查询执行失败', $details);
            $repository->finish($taskId, 'failed', null, null, $errorCode);
            throw $failure;
        }
        try {
            $result = $this->finalizeLookupResults($results, $requests);
        } catch (Throwable $failure) {
            // 最终 DTO 校验失败也必须收口任务，不能留下永远 running 的后台记录；只记录稳定错误分类。
            $repository->log($taskId, 'error', 'complete', null, 'failed', 'RESULT_INVALID', '插件最终结果无效', [
                'errorCode' => $failure->getMessage() !== '' && preg_match('/^[A-Z][A-Z0-9_]{2,99}$/D', $failure->getMessage()) === 1
                    ? $failure->getMessage() : 'METADATA_SCRAPE_RESULT_INVALID',
            ]);
            $repository->finish($taskId, 'failed', null, null, 'METADATA_SCRAPE_RESULT_INVALID');
            throw $failure;
        }
        $repository->finish($taskId, $result->status, $result->confidence, $result->metadata, null);
        // 每次正常收口都必须有终态日志，否则 unmatched/unavailable 任务会停在某条查询记录上，管理员无法
        // 判断任务是否真正结束。日志与任务终态使用同一结果对象，且不保存来源或候选内容；日志插入发生
        // 数据库异常时继续向调用方抛出，但前一步已提交的任务终态不会被回滚成 running，重试仍复用原任务。
        $completionMessage = match ($result->status) {
            MetadataScrapeCompletionResult::MATCHED => '插件已选出最终可信结果',
            MetadataScrapeCompletionResult::UNMATCHED => '全部查询完成，未找到可信结果',
            MetadataScrapeCompletionResult::UNAVAILABLE => '全部查询完成，但查询服务均不可用',
            default => '插件刮削任务已结束',
        };
        $completionDetails = $result->confidence === null ? [] : [
            'confidence' => $result->confidence,
            'dataTypes' => $this->completionDataTypes($result),
        ];
        $repository->log($taskId, $result->status === MetadataScrapeCompletionResult::UNAVAILABLE ? 'warning' : 'info',
            'complete', null, $result->status, 'TASK_FINISHED', $completionMessage, $completionDetails);
        return $result;
    }

    /**
     * 只记录单个候选包含的数据类别，不保存字段值、歌词正文或封面地址。
     *
     * 歌名和艺人是所有合法候选的身份必填项，因此有候选就固定包含 metadata；歌词与封面只依据已经通过
     * Helper 协议校验的非空值标记。返回值是封闭枚举，可安全写入任务诊断并供前端翻译，不能扩展为字段名、
     * 来源键或远端资源信息。
     *
     * @param array<string,mixed> $candidate
     * @return list<string>
     */
    private function candidateDataTypes(array $candidate): array
    {
        $types = ['metadata'];
        if (is_string($candidate['lyrics'] ?? null) && trim($candidate['lyrics']) !== '') $types[] = 'lyrics';
        if (is_string($candidate['artworkUrl'] ?? null) && trim($candidate['artworkUrl']) !== '') $types[] = 'artwork';
        return $types;
    }

    /**
     * 记录最终返回给主程序的类别，而不是某个来源曾经提供过的类别。
     *
     * matched 结果由 DTO 保证具有通用 metadata；歌词和封面必须在同身份候选聚合及 DTO 复验后仍非空才
     * 标记。该摘要不代表核心一定入库，字段合并、资源下载和已有数据保护仍由主程序自己的规则决定。
     *
     * @return list<string>
     */
    private function completionDataTypes(MetadataScrapeCompletionResult $result): array
    {
        $types = ['metadata'];
        if ($result->lyricsCandidates !== []) $types[] = 'lyrics';
        if ($result->artworkUrls !== [] || $result->albumArtworkUrls !== []) $types[] = 'artwork';
        return $types;
    }

    /**
     * 在插件内部完成专辑多来源查询，并只向核心返回一条专辑最终结论。
     *
     * 专辑使用独立 album Helper 协议和专辑候选评分；核心不会看到内部候选，也不会把专辑结果和歌曲
     * 结果重新拼接。专辑封面只取同一最终身份的专辑图，字段写入和图片发布仍由核心负责。
     */
    public function scrapeAlbum(AlbumScrapeCompletionRequest $request): AlbumScrapeCompletionResult
    {
        if (!$this->lookup instanceof MetadataScrapeAlbumLookupGateway) {
            return new AlbumScrapeCompletionResult(AlbumScrapeCompletionResult::UNAVAILABLE);
        }
        $result = $this->finalizeAlbumLookupResults($this->lookup->lookupAlbum($request), $request);
        if ($result->status === AlbumScrapeCompletionResult::UNAVAILABLE) {
            return $result;
        }
        if ($result->status !== AlbumScrapeCompletionResult::MATCHED || !is_array($result->metadata)) {
            return new AlbumScrapeCompletionResult(AlbumScrapeCompletionResult::UNMATCHED);
        }
        return $result;
    }

    /**
     * 在插件内部把各渠道中间结果收敛成单一最终查询结论，供歌曲和专辑两个实体边界复用。
     *
     * 该方法只处理内存中的受限查询结果，不创建任务、不写日志、不访问核心数据库；空结果与全部渠道故障
     * 必须区分，避免专辑任务把临时不可用错误误记成永久无匹配。获胜候选决定身份，其余候选仅补充缺失的
     * 发行字段，保证歌曲和专辑不会各自重新排序或拼接出第三种身份。
     *
     * 每个候选必须与产生它的查询严格同名、同艺人集合；专辑只作为 Helper 的排序证据，不参与歌曲身份
     * 的硬过滤。这样目录名包含 Disc 1/2/3、版本后缀或专辑缺失时，仍可凭精准歌名和艺人识别歌曲，同时
     * 防止可信发布快照切换到 metadata 模式后重新放过额外艺人或标点污染。Helper 分数只能证明相似度，
     * 不能授权改变冻结身份。查询位置只在调用栈中使用，最终 DTO 和任务诊断均不保存该内部关联。
     *
     * @param list<array<string,mixed>> $results
     * @param list<MetadataScrapeCompletionRequest> $queries
     */
    private function finalizeLookupResults(array $results, array $queries): MetadataScrapeCompletionResult
    {
        $trusted = [];
        foreach ($results as $position => $result) {
            $best = $result['best'] ?? null;
            if (($result['status'] ?? null) !== 'matched' || !is_array($best)
                || !is_int($best['score'] ?? null) || $best['score'] < 85) continue;
            $queryPosition = $result['_queryPosition'] ?? null;
            $query = is_int($queryPosition) ? ($queries[$queryPosition] ?? null) : null;
            if (!$query instanceof MetadataScrapeCompletionRequest
                || !$this->candidateMatchesQuery($best, $query)) continue;
            $trusted[] = ['position' => $position, 'queryPosition' => $queryPosition, 'best' => $best];
        }
        if ($trusted === []) {
            $unavailable = $results === [] || count(array_filter(
                $results,
                static fn (array $result): bool => in_array($result['status'] ?? null, ['failed', 'not_queried'], true),
            )) === count($results);
            return new MetadataScrapeCompletionResult(
                $unavailable ? MetadataScrapeCompletionResult::UNAVAILABLE : MetadataScrapeCompletionResult::UNMATCHED,
            );
        }
        usort($trusted, static function (array $left, array $right): int {
            $score = $right['best']['score'] <=> $left['best']['score'];
            return $score !== 0 ? $score : $left['position'] <=> $right['position'];
        });
        $trusted = $this->sameIdentityCandidates($trusted);
        $winner = $trusted[0]['best'];
        $lyrics = [];
        $artworkUrls = [];
        foreach ($trusted as $entry) {
            $candidate = $entry['best'];
            if (is_string($candidate['lyrics'] ?? null) && trim($candidate['lyrics']) !== '') {
                $lyrics[hash('sha256', $candidate['lyrics'])] ??= $candidate['lyrics'];
            }
            if (is_string($candidate['artworkUrl'] ?? null)
                && filter_var($candidate['artworkUrl'], FILTER_VALIDATE_URL) !== false
                && in_array(strtolower((string) parse_url($candidate['artworkUrl'], PHP_URL_SCHEME)), ['http', 'https'], true)) {
                $artworkUrls[$candidate['artworkUrl']] = $candidate['artworkUrl'];
            }
        }
        $lyrics = array_values($lyrics);
        $artworkUrls = array_values($artworkUrls);
        return new MetadataScrapeCompletionResult(
            MetadataScrapeCompletionResult::MATCHED,
            $this->metadata($trusted),
            $winner['score'],
            lyricsCandidates: $lyrics,
            artworkUrls: $artworkUrls,
            albumArtworkUrls: $artworkUrls,
        );
    }

    /**
     * 要求 Helper 候选完整遵守产生该候选的单一查询身份。
     *
     * 标题和艺人集合必须严格相同；专辑只影响 Helper 的候选排序和分数，不是歌曲身份的必要条件。原文
     * 不同时只接受 Helper 在内置 OpenCC 归一化后同时给出的 `TITLE_EXACT` 和 `ARTIST_MATCH`；因此不能通过
     * 删除句点或仅共享一名艺人接受 `Sazablue, 周深.`。失败
     * 候选仍可在单渠道查询日志中保留分数与原因摘要，但不得参与最终字段、歌词或封面聚合。本方法无
     * 外部副作用。
     *
     * @param array<string,mixed> $candidate
     */
    private function candidateMatchesQuery(
        array $candidate,
        MetadataScrapeCompletionRequest $query,
    ): bool {
        $rawTitleMatches = $this->identityText((string) ($candidate['title'] ?? '')) === $this->identityText($query->title);
        $candidateArtists = is_array($candidate['artists'] ?? null)
            ? array_values(array_filter($candidate['artists'], 'is_string')) : [];
        $rawArtistsMatch = $this->identitySet($candidateArtists) === $this->identitySet($query->artists);
        if ($rawTitleMatches && $rawArtistsMatch) return true;
        $reasons = is_array($candidate['reasons'] ?? null) ? $candidate['reasons'] : [];
        return count($candidateArtists) === count($query->artists)
            && in_array('TITLE_EXACT', $reasons, true)
            && in_array('ARTIST_MATCH', $reasons, true);
    }

    /** @param list<string> $values @return list<string> */
    private function identitySet(array $values): array
    {
        $values = array_values(array_unique(array_filter(array_map($this->identityText(...), $values))));
        sort($values, SORT_STRING);
        return $values;
    }

    /**
     * 把可信候选收窄到身份获胜项描述的同一作品。
     *
     * Helper 分数证明候选与原请求相似，但跨渠道补充会扩大单一候选的影响范围，因此还要以获胜标题和艺人
     * 交集建立第二道边界。比较只做 Unicode 小写与空白归一化，不猜测别名、译名或版本后缀；不兼容项仍
     * 可保留在插件任务日志中供诊断，但不得贡献字段、歌词或图片。获胜项始终保留，返回列表不会为空。
     *
     * @param list<array{position:int,queryPosition:int,best:array<string,mixed>}> $trusted
     * @return list<array{position:int,queryPosition:int,best:array<string,mixed>}>
     */
    private function sameIdentityCandidates(array $trusted): array
    {
        $winner = $trusted[0]['best'];
        $title = $this->identityText((string) $winner['title']);
        $artists = array_fill_keys(array_map(
            fn (string $artist): string => $this->identityText($artist),
            array_values(array_filter($winner['artists'] ?? [], 'is_string')),
        ), true);
        $queryPosition = $trusted[0]['queryPosition'];
        return array_values(array_filter($trusted, function (array $entry) use ($artists, $queryPosition, $title): bool {
            $candidate = $entry['best'];
            // 同一解析查询下的高分候选已通过 candidateMatchesQuery 的繁简双重复验。
            if ($entry['queryPosition'] === $queryPosition) return true;
            if ($this->identityText((string) ($candidate['title'] ?? '')) !== $title) return false;
            foreach ($candidate['artists'] ?? [] as $artist) {
                if (is_string($artist) && isset($artists[$this->identityText($artist)])) return true;
            }
            return false;
        }));
    }

    /** 只为同身份比较折叠大小写和连续空白，不改变最终保存的第三方文本。 */
    private function identityText(string $value): string
    {
        $value = mb_convert_kana($value, 'as', 'UTF-8');
        return mb_strtolower(trim((string) preg_replace('/\s+/u', ' ', $value)), 'UTF-8');
    }

    /**
     * 从独立专辑来源结果中选择唯一最终专辑身份。
     *
     * 只有来源自身达到 85 分且标题/艺人已经由 Helper 复验的候选才能参与；第一名决定专辑身份，其余
     * 来源只能补足第一名缺失的发行字段。专辑查询不读取歌曲候选，也不会生成歌曲歌词或歌曲封面。
     *
     * @param list<array<string,mixed>> $results
     */
    private function finalizeAlbumLookupResults(
        array $results,
        AlbumScrapeCompletionRequest $request,
    ): AlbumScrapeCompletionResult
    {
        $trusted = [];
        foreach ($results as $position => $result) {
            $best = $result['best'] ?? null;
            if (($result['status'] ?? null) !== 'matched' || !is_array($best)
                || !is_int($best['score'] ?? null) || $best['score'] < 85
                || !$this->albumCandidateMatchesQuery($best, $request)) continue;
            $trusted[] = ['position' => $position, 'best' => $best];
        }
        if ($trusted === []) {
            $unavailable = $results === [] || count(array_filter($results,
                static fn (array $result): bool => in_array($result['status'] ?? null, ['failed', 'not_queried'], true),
            )) === count($results);
            return new AlbumScrapeCompletionResult($unavailable
                ? AlbumScrapeCompletionResult::UNAVAILABLE : AlbumScrapeCompletionResult::UNMATCHED);
        }
        usort($trusted, static fn (array $left, array $right): int =>
            $right['best']['score'] <=> $left['best']['score'] ?: $left['position'] <=> $right['position']);
        $trusted = $this->sameAlbumIdentityCandidates($trusted);
        $winner = $trusted[0]['best'];
        $metadata = ['title' => $winner['title'], 'albumArtists' => $winner['artists']];
        foreach (['releaseDate', 'discTotal', 'musicbrainzReleaseId', 'musicbrainzReleaseGroupId'] as $field) {
            if (array_key_exists($field, $winner)) $metadata[$field] = $winner[$field];
        }
        foreach (array_slice($trusted, 1) as $entry) {
            foreach (['releaseDate', 'discTotal', 'musicbrainzReleaseId', 'musicbrainzReleaseGroupId'] as $field) {
                if (!array_key_exists($field, $metadata) && array_key_exists($field, $entry['best'])) {
                    $metadata[$field] = $entry['best'][$field];
                }
            }
        }
        $artworkUrls = [];
        foreach ($trusted as $entry) {
            $url = $entry['best']['artworkUrl'] ?? null;
            if (is_string($url) && $url !== '') $artworkUrls[$url] = $url;
        }
        return new AlbumScrapeCompletionResult(
            AlbumScrapeCompletionResult::MATCHED,
            $metadata,
            $winner['score'],
            artworkUrls: array_values($artworkUrls),
        );
    }

    /**
     * 在跨渠道聚合前重新确认专辑候选仍属于核心请求的专辑身份。
     *
     * 原文标题和至少一名专辑艺人相同时直接接受；平台返回简体而文件保留繁体时，只接受 Helper 同时给出的
     * `ALBUM_TITLE_EXACT` 与 `ALBUM_ARTIST_OVERLAP` 证据。原因码由随包 Helper 在 `tw2s` 归一化和精确比较后
     * 产生，PHP 不自行猜测译名、别名或相似字符串。复验失败的候选不得提供发行 ID、日期或封面，且本方法
     * 只读取内存数据，没有数据库和文件副作用。
     *
     * @param array<string,mixed> $candidate
     */
    private function albumCandidateMatchesQuery(
        array $candidate,
        AlbumScrapeCompletionRequest $request,
    ): bool {
        $rawTitleMatches = $this->identityText((string) ($candidate['title'] ?? ''))
            === $this->identityText($request->albumTitle);
        $candidateArtists = is_array($candidate['artists'] ?? null)
            ? array_values(array_filter($candidate['artists'], 'is_string')) : [];
        $rawArtistOverlap = array_intersect(
            $this->identitySet($candidateArtists),
            $this->identitySet($request->albumArtists),
        ) !== [];
        if ($rawTitleMatches && $rawArtistOverlap) return true;
        $reasons = is_array($candidate['reasons'] ?? null) ? $candidate['reasons'] : [];
        return $candidateArtists !== []
            && in_array('ALBUM_TITLE_EXACT', $reasons, true)
            && in_array('ALBUM_ARTIST_OVERLAP', $reasons, true);
    }

    /**
     * 只允许与最高分专辑标题相同且至少共享一名专辑艺人的候选补充发行字段和封面。
     *
     * Helper 的 85 分门槛仍可能命中同名精选集或不同艺人的同名发行；所有输入已经先通过同一请求身份的
     * 原文或 `tw2s` 证据复验，因此繁简显示差异不会阻断补全。随后仍优先使用候选间原文交集收窄结果；
     * 两项原文不同但都带完整 Helper 身份证据时才视为同一实体，阻止无证据的 MusicBrainz ID、日期和封面
     * 串入另一实体。最高分项由协议保证具有非空艺人，因此返回结果始终非空。
     *
     * @param list<array{position:int,best:array<string,mixed>}> $trusted
     * @return list<array{position:int,best:array<string,mixed>}>
     */
    private function sameAlbumIdentityCandidates(array $trusted): array
    {
        $winner = $trusted[0]['best'];
        $title = $this->identityText((string) $winner['title']);
        $artists = array_fill_keys(array_map(fn (string $artist): string => $this->identityText($artist), $winner['artists']), true);
        return array_values(array_filter($trusted, function (array $entry) use ($artists, $title): bool {
            $candidate = $entry['best'];
            $reasons = is_array($candidate['reasons'] ?? null) ? $candidate['reasons'] : [];
            $helperProvedIdentity = in_array('ALBUM_TITLE_EXACT', $reasons, true)
                && in_array('ALBUM_ARTIST_OVERLAP', $reasons, true);
            if ($this->identityText((string) $candidate['title']) !== $title) return $helperProvedIdentity;
            foreach ($candidate['artists'] as $artist) {
                if (isset($artists[$this->identityText((string) $artist)])) return true;
            }
            return $helperProvedIdentity;
        }));
    }

    /**
     * 使用 Helper 的同平台代表歌曲证明查询艺人资料图。
     *
     * 插件只返回已选的一张图；核心仍复验实体关系并负责下载、归属和导入。Helper 故障抛出后由核心
     * 图片 Provider 回退固定来源，正常无匹配则返回 unmatched，不伪造艺人资料。
     */
    public function scrapeArtistArtwork(ArtistArtworkScrapeRequest $request): ArtistArtworkScrapeResult
    {
        $results = (new MetadataScrapeArtistArtworkClient())->lookup($request);
        $trusted = [];
        foreach ($results as $position => $result) {
            $best = $result['best'] ?? null;
            if (($result['status'] ?? null) !== 'matched' || !is_array($best)
                || !is_int($best['score'] ?? null) || $best['score'] < 85) continue;
            $trusted[] = ['position' => $position, 'best' => $best];
        }
        if ($trusted === []) {
            $unavailable = $results === [] || count(array_filter(
                $results,
                static fn (array $result): bool => in_array($result['status'] ?? null, ['failed', 'not_queried'], true),
            )) === count($results);
            return new ArtistArtworkScrapeResult($unavailable ? ArtistArtworkScrapeResult::UNAVAILABLE : ArtistArtworkScrapeResult::UNMATCHED);
        }
        usort($trusted, static fn (array $left, array $right): int =>
            ($right['best']['score'] <=> $left['best']['score']) ?: ($left['position'] <=> $right['position']));
        $winner = $trusted[0]['best'];
        return new ArtistArtworkScrapeResult(
            ArtistArtworkScrapeResult::MATCHED,
            (string) $winner['artistName'],
            (string) $winner['artworkUrl'],
            (int) $winner['score'],
        );
    }

    /**
     * 在插件内部完成艺人身份确认及 MB/Wikidata/Wikipedia 资料聚合。
     *
     * 核心只接收脱敏最终资料，插件故障统一返回 unavailable，名称歧义返回 unmatched；两种状态都不
     * 修改插件或核心数据库。核心随后按自己的任务退避和 CAS 规则决定是否再次调用。
     */
    public function scrapeArtistProfile(ArtistProfileScrapeRequest $request): ArtistProfileScrapeResult
    {
        return $this->profileLookup->lookup($request);
    }

    /**
     * 由核心通用插件 Worker 调度一条艺人资料任务。
     *
     * 任务恢复、领取、退避和 CAS 仍由核心领域服务保护业务表；本方法只把 Worker 生命周期和插件能力
     * 绑定起来，不在插件进程中直接修改歌曲或艺人资料。每轮最多执行一条，网络请求始终位于 SQLite
     * 事务之外；插件停用后注册表不会再次调用本方法。
     */
    public function processNext(string $workerId): bool
    {
        // 先分发与歌曲终态同事务写入的实体意图；失败会留在意图表退避，不阻塞本轮实体任务领取。
        if ($this->entityIntents->processOne($workerId . ':entity-intent')) return true;
        // 两类任务共用一个 Worker；每轮交换首选类型，避免艺人回填持续有任务时专辑永远得不到机会。
        static $preferArtist = true;
        $order = $preferArtist ? ['artist', 'album'] : ['album', 'artist'];
        $preferArtist = !$preferArtist;
        foreach ($order as $type) {
            if ($type === 'artist') {
                $this->profileJobs->recoverStaleLeases();
                $this->profileJobs->enqueueExisting(1);
                $job = $this->profileJobs->claimNext($workerId);
                if ($job !== null) {
                    $this->profileJobs->execute($job, $workerId);
                    return true;
                }
                continue;
            }
            $this->albumJobs->recoverStaleLeases();
            $this->albumJobs->enqueueExisting(1);
            $job = $this->albumJobs->claimNext($workerId);
            if ($job !== null) {
                $this->albumJobs->execute($job, $workerId);
                return true;
            }
        }
        return false;
    }

    /**
     * 从已经信任的插件私有候选形成一个通用字段映射。
     *
     * 获胜项的歌名和艺人不可被其他候选替换，保证结果只描述一个作品。稀疏字段只在获胜项缺失时按已排序
     * 候选补全，因此“补全”不等同于核心跨渠道重选；最终映射不携带来源键、分数、URL 或原始响应。
     *
     * @param list<array{position:int,best:array<string,mixed>}> $trusted
     * @return array<string,mixed>
     */
    private function metadata(array $trusted): array
    {
        $winner = $trusted[0]['best'];
        // 第三方结果没有独立专辑艺人时，使用同一首最终录音的艺人作为专辑艺人回退；核心仍会按
        // 文件原始专辑艺人优先，仅在共享专辑字段缺失时采用这里的补全值。
        $metadata = ['title' => $winner['title'], 'artists' => $winner['artists'], 'albumArtists' => $winner['artists']];
        $mapping = [
            'album' => 'albumTitle', 'composer' => 'composer', 'trackNumber' => 'trackNumber', 'trackTotal' => 'trackTotal',
            'discNumber' => 'discNumber', 'discTotal' => 'discTotal', 'releaseDate' => 'releaseDate',
            'genres' => 'genres', 'isrc' => 'isrc', 'musicbrainzTrackId' => 'musicbrainzTrackId',
            'musicbrainzArtistId' => 'musicbrainzArtistId', 'musicbrainzReleaseId' => 'musicbrainzReleaseId',
            'musicbrainzReleaseGroupId' => 'musicbrainzReleaseGroupId',
        ];
        foreach ($trusted as $entry) {
            foreach ($mapping as $from => $to) {
                if (array_key_exists($to, $metadata) || !array_key_exists($from, $entry['best'])
                    || $entry['best'][$from] === null || $entry['best'][$from] === []) {
                    continue;
                }
                $metadata[$to] = $entry['best'][$from];
            }
        }
        return $metadata;
    }
}
