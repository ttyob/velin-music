<?php

declare(strict_types=1);

namespace plugin\metadata_scrape\app;

use app\application\System\ArtistDatabaseStorageService;

/**
 * 元数据插件的艺人辅助库管理适配器。
 *
 * 插件页面和动态管理 API 只能通过本适配器进入上传状态机；核心不再为该资源注册系统设置路由。
 * 存储服务继续使用历史固定缓存根和原子发布协议，避免迁移时移动已发布 SQLite 或破坏核心只读
 * 身份查询。适配器不暴露路径、不改变分块顺序，也不绕过服务端权限、锁和完整性校验。
 */
final readonly class MetadataScrapeArtistDatabaseService
{
    private ArtistDatabaseStorageService $storage;

    public function __construct(?ArtistDatabaseStorageService $storage = null)
    {
        $this->storage = $storage ?? new ArtistDatabaseStorageService();
    }

    /** @return array<string,mixed> */
    public function status(): array { return $this->storage->status(); }

    /** @return array<string,mixed> */
    public function start(string $fileName, int $totalBytes): array { return $this->storage->start($fileName, $totalBytes); }

    /** @return array<string,mixed> */
    public function append(string $uploadId, int $offset, string $bytes, string $sha256): array
    {
        return $this->storage->append($uploadId, $offset, $bytes, $sha256);
    }

    /** @return array<string,mixed> */
    public function complete(string $uploadId): array { return $this->storage->complete($uploadId); }

    public function cancel(string $uploadId): void { $this->storage->cancel($uploadId); }
}
