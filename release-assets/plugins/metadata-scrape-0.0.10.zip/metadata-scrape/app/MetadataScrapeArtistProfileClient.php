<?php

declare(strict_types=1);

namespace plugin\metadata_scrape\app;

use app\application\ResourcePlugin\Contract\ArtistProfileScrapeRequest;
use app\application\ResourcePlugin\Contract\ArtistProfileScrapeResult;
use app\application\Scrape\ChineseQueryVariantNormalizer;
use Closure;
use GuzzleHttp\Client;
use GuzzleHttp\ClientInterface;
use JsonException;
use Psr\Http\Message\ResponseInterface;
use Throwable;

/**
 * MetadataScrapeArtistProfileClient 在插件包内读取 MusicBrainz、Wikidata 与中文 Wikipedia 资料。
 *
 * 名称搜索只接受高分且规范化精确相等的唯一 MBID；已知 MBID 也必须由 MusicBrainz 返回值复验。请求
 * 主机、路径、HTTPS、DNS 公网地址、固定 IP、无代理和无跳转规则全部在插件内执行，响应上限为 2 MiB。
 * MusicBrainz 是必需来源，Wikidata/Wikipedia 是可选字段；网络或协议故障收敛为 unavailable，不能把
 * 远端正文、URL 或异常细节写入核心数据库、任务日志或插件表。
 */
final class MetadataScrapeArtistProfileClient implements MetadataScrapeArtistProfileLookupGateway
{
    private const MAX_BYTES = 2_097_152;
    private ClientInterface $http;
    /** @var Closure(string):list<string> */
    private Closure $addressResolver;
    private ChineseQueryVariantNormalizer $identityNormalizer;
    private int $lastMusicBrainzRequestNs = 0;

    /**
     * @param null|callable(string):list<string> $addressResolver 仅供测试替换 DNS 数据源；返回值仍执行公网校验。
     */
    public function __construct(
        ?ClientInterface $http = null,
        ?callable $addressResolver = null,
        ?ChineseQueryVariantNormalizer $identityNormalizer = null,
    )
    {
        $this->http = $http ?? new Client(['http_errors' => false]);
        $this->identityNormalizer = $identityNormalizer ?? new ChineseQueryVariantNormalizer();
        $this->addressResolver = $addressResolver === null
            ? static function (string $host): array {
                $records = dns_get_record($host, DNS_A | DNS_AAAA);
                if (!is_array($records)) return [];
                $addresses = [];
                foreach ($records as $record) {
                    $ip = $record['ip'] ?? $record['ipv6'] ?? null;
                    if (is_string($ip)) $addresses[] = $ip;
                }
                return $addresses;
            }
            : Closure::fromCallable($addressResolver);
    }

    public function lookup(ArtistProfileScrapeRequest $request): ArtistProfileScrapeResult
    {
        try {
            $identity = $request->musicBrainzId === null
                ? $this->resolveByName($request->artistName)
                : ['id' => $request->musicBrainzId, 'name' => $request->artistName, 'country' => null];
            if ($identity === null) return new ArtistProfileScrapeResult(ArtistProfileScrapeResult::UNMATCHED);
            return new ArtistProfileScrapeResult(ArtistProfileScrapeResult::MATCHED, $this->fetch($identity));
        } catch (MetadataScrapeArtistProfileUnavailable) {
            return new ArtistProfileScrapeResult(ArtistProfileScrapeResult::UNAVAILABLE);
        }
    }

    /** @return null|array{id:string,name:?string,country:?string} */
    private function resolveByName(string $artistName): ?array
    {
        $simplifiedName = $this->identityNormalizer->simplifyText($artistName);
        $needle = $this->normalize($simplifiedName);
        if ($needle === '' || mb_strlen($artistName, 'UTF-8') > 160) return null;
        $matches = $this->resolveNameVariant($artistName, $needle);
        if ($matches === [] && $simplifiedName !== $artistName) {
            $matches = $this->resolveNameVariant($simplifiedName, $needle);
        }
        return count($matches) === 1 ? reset($matches) : null;
    }

    /**
     * 查询一个艺人名称变体，并以同一 `tw2s` 身份键复验 MusicBrainz 名称和别名。
     *
     * 原文查询始终优先，只有原文没有可信候选时调用方才使用简体变体；这避免额外请求并保留平台原始名称
     * 作为最终展示值。候选名称一次批量转换，OpenCC 缺失时自然退回原文比较。相同 MBID 的多个别名只记
     * 一项，不同 MBID 同名则保持歧义并返回 unmatched；方法不写数据库，网络异常由既有不可用边界处理。
     *
     * @return array<string,array{id:string,name:?string,country:?string}>
     */
    private function resolveNameVariant(string $queryName, string $needle): array
    {
        $escaped = addcslashes($queryName, "\\\"");
        $document = $this->json('musicbrainz.org', '/ws/2/artist', [
            'query' => 'artist:"' . $escaped . '"', 'fmt' => 'json', 'limit' => '25',
        ], true);
        $artists = is_array($document['artists'] ?? null) ? array_slice($document['artists'], 0, 25) : [];
        $nameDocuments = [];
        foreach ($artists as $artistIndex => $artist) {
            if (!is_array($artist) || (int) ($artist['score'] ?? 0) < 95) continue;
            foreach ([$artist['name'] ?? null, $artist['sort-name'] ?? null] as $name) {
                if (is_string($name)) $nameDocuments[] = ['artistIndex' => $artistIndex, 'value' => $name];
            }
            if (is_array($artist['aliases'] ?? null)) {
                foreach (array_slice($artist['aliases'], 0, 100) as $alias) {
                    if (is_array($alias) && is_string($alias['name'] ?? null)) {
                        $nameDocuments[] = ['artistIndex' => $artistIndex, 'value' => $alias['name']];
                    }
                }
            }
        }
        $simplifiedNames = $this->identityNormalizer->simplify($nameDocuments);
        $matchedArtistIndexes = [];
        foreach ($simplifiedNames as $name) {
            if (is_array($name) && is_int($name['artistIndex'] ?? null) && is_string($name['value'] ?? null)
                && $this->normalize($name['value']) === $needle) {
                $matchedArtistIndexes[$name['artistIndex']] = true;
            }
        }
        $matches = [];
        foreach ($artists as $artistIndex => $artist) {
            if (!is_array($artist) || !isset($matchedArtistIndexes[$artistIndex])) continue;
            $mbid = strtolower(trim((string) ($artist['id'] ?? '')));
            if (!$this->validMbid($mbid)) continue;
            $matches[$mbid] = ['id' => $mbid, 'name' => $this->text($artist['name'] ?? null, 255),
                'country' => $this->country($artist['country'] ?? null)];
        }
        return $matches;
    }

    /** @param array{id:string,name:?string,country:?string} $identity @return array<string,mixed> */
    private function fetch(array $identity): array
    {
        if (!$this->validMbid($identity['id'])) throw new MetadataScrapeArtistProfileUnavailable();
        $musicBrainz = $this->json('musicbrainz.org', '/ws/2/artist/' . $identity['id'],
            ['fmt' => 'json', 'inc' => 'url-rels+tags'], true);
        if (strtolower((string) ($musicBrainz['id'] ?? '')) !== $identity['id']) {
            throw new MetadataScrapeArtistProfileUnavailable();
        }
        $wikidataId = $this->wikidataId($musicBrainz['relations'] ?? null);
        $wikidata = $wikidataId === null ? [] : $this->optionalJson('www.wikidata.org', '/w/api.php', [
            'action' => 'wbgetentities', 'ids' => $wikidataId, 'props' => 'sitelinks|claims',
            'sitefilter' => 'zhwiki', 'format' => 'json',
        ]);
        $entity = is_array($wikidata['entities'][$wikidataId] ?? null) ? $wikidata['entities'][$wikidataId] : [];
        $wikiTitle = $this->text($entity['sitelinks']['zhwiki']['title'] ?? null, 255);
        $summary = $wikiTitle === null ? [] : $this->optionalJson('zh.wikipedia.org', '/w/api.php', [
            'action' => 'query', 'prop' => 'extracts', 'explaintext' => '1', 'redirects' => '1',
            'titles' => $wikiTitle, 'format' => 'json', 'formatversion' => '2',
        ]);
        $page = is_array($summary['query']['pages'][0] ?? null) ? $summary['query']['pages'][0] : [];
        $lifeSpan = is_array($musicBrainz['life-span'] ?? null) ? $musicBrainz['life-span'] : [];
        $area = is_array($musicBrainz['area'] ?? null) ? $musicBrainz['area'] : [];
        return [
            'musicBrainzArtistId' => $identity['id'],
            'wikidataId' => $wikidataId,
            'canonicalName' => $this->text($identity['name'] ?? ($musicBrainz['name'] ?? null), 255),
            'artistType' => $this->text($musicBrainz['type'] ?? null, 80),
            'gender' => $this->text($musicBrainz['gender'] ?? null, 80),
            'countryCode' => $this->country($musicBrainz['country'] ?? $identity['country']),
            'areaName' => $this->text($area['name'] ?? null, 160),
            'beginDate' => $this->date($lifeSpan['begin'] ?? null),
            'endDate' => $this->date($lifeSpan['end'] ?? null),
            'disambiguation' => $this->text($musicBrainz['disambiguation'] ?? null, 500),
            'biography' => $this->text($page['extract'] ?? null, 12_000, true),
            'officialUrl' => $this->officialUrl($entity, $musicBrainz['relations'] ?? null),
            'wikipediaUrl' => $wikiTitle === null ? null : 'https://zh.wikipedia.org/wiki/' . rawurlencode(str_replace(' ', '_', $wikiTitle)),
            'tags' => $this->tags($musicBrainz['tags'] ?? null),
            'sources' => array_values(array_filter(['musicbrainz', $wikidataId === null ? null : 'wikidata', $wikiTitle === null ? null : 'wikipedia_zh'])),
        ];
    }

    /** 可选来源失败只省略字段；MusicBrainz 失败向 lookup 收敛为 unavailable。 */
    private function optionalJson(string $host, string $path, array $query): array
    {
        try { return $this->json($host, $path, $query, false); } catch (MetadataScrapeArtistProfileUnavailable) { return []; }
    }

    /** @return array<string,mixed> */
    private function json(string $host, string $path, array $query, bool $required): array
    {
        if (!extension_loaded('curl') || !defined('CURLOPT_RESOLVE') || !$this->allowedEndpoint($host, $path)) {
            throw new MetadataScrapeArtistProfileUnavailable();
        }
        $addresses = $this->publicAddresses($host);
        if ($addresses === []) throw new MetadataScrapeArtistProfileUnavailable();
        $ip = str_contains($addresses[0], ':') ? '[' . $addresses[0] . ']' : $addresses[0];
        if ($host === 'musicbrainz.org') $this->paceMusicBrainz();
        try {
            $response = $this->http->request('GET', 'https://' . $host . $path, [
                'query' => $query, 'allow_redirects' => false, 'connect_timeout' => 4.0, 'timeout' => 12.0,
                'proxy' => '', 'http_errors' => false, 'stream' => true,
                'headers' => ['Accept' => 'application/json', 'User-Agent' => 'Velin-Music/1.0 (artist-profile-plugin)'],
                'curl' => [constant('CURLOPT_RESOLVE') => [$host . ':443:' . $ip]],
            ]);
        } catch (Throwable) { throw new MetadataScrapeArtistProfileUnavailable(); }
        return $this->decode($response, $required);
    }

    /** @return array<string,mixed> */
    private function decode(ResponseInterface $response, bool $required): array
    {
        $status = $response->getStatusCode();
        if ($status === 429 || $status >= 500 || ($required && ($status < 200 || $status >= 300))) {
            throw new MetadataScrapeArtistProfileUnavailable();
        }
        if ($status < 200 || $status >= 300) throw new MetadataScrapeArtistProfileUnavailable();
        $declared = $response->getHeaderLine('Content-Length');
        if ($declared !== '' && (!ctype_digit($declared) || (int) $declared > self::MAX_BYTES)) throw new MetadataScrapeArtistProfileUnavailable();
        $body = $response->getBody();
        $bytes = '';
        while (!$body->eof() && strlen($bytes) <= self::MAX_BYTES) $bytes .= $body->read(min(16_384, self::MAX_BYTES + 1 - strlen($bytes)));
        if ($bytes === '' || strlen($bytes) > self::MAX_BYTES) throw new MetadataScrapeArtistProfileUnavailable();
        try { $document = json_decode($bytes, true, 64, JSON_THROW_ON_ERROR); } catch (JsonException) { throw new MetadataScrapeArtistProfileUnavailable(); }
        if (!is_array($document)) throw new MetadataScrapeArtistProfileUnavailable();
        return $document;
    }

    /** @return list<string> */
    private function publicAddresses(string $host): array
    {
        $resolved = ($this->addressResolver)($host);
        if (!is_array($resolved)) return [];
        $addresses = [];
        foreach ($resolved as $ip) {
            if (!is_string($ip) || filter_var($ip, FILTER_VALIDATE_IP) === false
                || filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false) return [];
            $addresses[] = $ip;
        }
        return array_values(array_unique($addresses));
    }

    private function allowedEndpoint(string $host, string $path): bool
    {
        return match ($host) {
            'musicbrainz.org' => $path === '/ws/2/artist' || preg_match('~^/ws/2/artist/[0-9a-f-]{36}$~D', $path) === 1,
            'www.wikidata.org', 'zh.wikipedia.org' => $path === '/w/api.php',
            default => false,
        };
    }

    private function paceMusicBrainz(): void
    {
        $now = hrtime(true);
        $remaining = 1_100_000_000 - ($now - $this->lastMusicBrainzRequestNs);
        if ($this->lastMusicBrainzRequestNs > 0 && $remaining > 0) time_nanosleep(intdiv($remaining, 1_000_000_000), $remaining % 1_000_000_000);
        $this->lastMusicBrainzRequestNs = hrtime(true);
    }

    private function wikidataId(mixed $relations): ?string
    {
        if (!is_array($relations)) return null;
        foreach (array_slice($relations, 0, 200) as $relation) {
            $resource = is_array($relation) ? ($relation['url']['resource'] ?? null) : null;
            if (($relation['type'] ?? null) === 'wikidata' && is_string($resource)
                && preg_match('~^https://www\.wikidata\.org/wiki/(Q[1-9][0-9]{0,15})$~D', $resource, $match) === 1) return $match[1];
        }
        return null;
    }

    private function officialUrl(array $entity, mixed $relations): ?string
    {
        $claims = $entity['claims']['P856'] ?? null;
        if (is_array($claims)) foreach (array_slice($claims, 0, 10) as $claim) {
            $valid = $this->externalHttpsUrl($claim['mainsnak']['datavalue']['value'] ?? null);
            if ($valid !== null) return $valid;
        }
        if (!is_array($relations)) return null;
        foreach (array_slice($relations, 0, 200) as $relation) if (($relation['type'] ?? null) === 'official homepage') {
            $valid = $this->externalHttpsUrl($relation['url']['resource'] ?? null);
            if ($valid !== null) return $valid;
        }
        return null;
    }

    private function externalHttpsUrl(mixed $value): ?string
    {
        if (!is_string($value) || strlen($value) > 1000) return null;
        $parts = parse_url($value);
        if (!is_array($parts) || strtolower((string) ($parts['scheme'] ?? '')) !== 'https' || !is_string($parts['host'] ?? null)
            || filter_var($parts['host'], FILTER_VALIDATE_IP) !== false || isset($parts['user']) || isset($parts['pass']) || isset($parts['fragment'])) return null;
        return $value;
    }

    /** @return list<string> */
    private function tags(mixed $tags): array
    {
        if (!is_array($tags)) return [];
        usort($tags, static fn (mixed $left, mixed $right): int => (int) ($right['count'] ?? 0) <=> (int) ($left['count'] ?? 0));
        $result = [];
        foreach (array_slice($tags, 0, 30) as $tag) {
            $name = is_array($tag) ? $this->text($tag['name'] ?? null, 80) : null;
            if ($name !== null) $result[mb_strtolower($name, 'UTF-8')] ??= $name;
            if (count($result) >= 12) break;
        }
        return array_values($result);
    }

    private function text(mixed $value, int $maximum, bool $multiline = false): ?string
    {
        if (!is_string($value)) return null;
        $value = trim($value);
        if (!$multiline) $value = preg_replace('/\s+/u', ' ', $value) ?? $value;
        return $value === '' ? null : mb_substr($value, 0, $maximum, 'UTF-8');
    }

    private function date(mixed $value): ?string
    {
        $value = is_string($value) ? trim($value) : '';
        return preg_match('/^\d{4}(?:-\d{2}(?:-\d{2})?)?$/D', $value) === 1 ? $value : null;
    }

    private function country(mixed $value): ?string
    {
        $value = is_string($value) ? strtoupper(trim($value)) : '';
        return preg_match('/^[A-Z]{2,8}$/D', $value) === 1 ? $value : null;
    }

    private function normalize(string $value): string
    {
        $value = mb_convert_kana($value, 'as', 'UTF-8');
        $value = mb_strtolower($value, 'UTF-8');
        return preg_replace('/[\p{Z}\s]+/u', ' ', trim($value)) ?? trim($value);
    }

    private function validMbid(string $value): bool
    {
        return preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/D', $value) === 1;
    }
}

/** 插件资料查询的稳定失败分类；不携带远端正文、URL 或异常细节。 */
final class MetadataScrapeArtistProfileUnavailable extends \RuntimeException
{
}
