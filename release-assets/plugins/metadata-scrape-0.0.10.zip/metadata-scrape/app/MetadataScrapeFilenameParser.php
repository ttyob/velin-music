<?php

declare(strict_types=1);

namespace plugin\metadata_scrape\app;

use app\application\ResourcePlugin\Contract\MetadataScrapeCompletionRequest;

/**
 * 在插件边界解析文件名查询输入。
 *
 * 核心只提供三个已清理的名称片段；本类负责去除曲号/格式噪声、识别 feat 和常见艺人-标题方向，
 * 并最多生成两个有界查询请求。解析失败时仍保留完整文件名，避免主程序猜测目录语义或丢失可检索事实。
 */
final readonly class MetadataScrapeFilenameParser
{
    /** @return list<MetadataScrapeCompletionRequest> */
    public function requests(MetadataScrapeCompletionRequest $input): array
    {
        $file = $this->clean(pathinfo($input->fileName ?? $input->title, PATHINFO_FILENAME));
        if ($file === '') return [];
        $parent = $this->clean((string) ($input->parentDirectory ?? ''));
        $grandparent = $this->clean((string) ($input->grandparentDirectory ?? ''));
        $album = $parent !== '' ? $parent : null;
        $artist = $grandparent !== '' ? $grandparent : null;
        // 目录只在插件内解释：`艺人 - 专辑 2020 FLAC` 取右侧专辑并清除明确技术后缀。
        if ($album !== null && preg_match('/^(.{1,160}?)\s+[-–—]\s+(.{1,240})$/u', $album, $m) === 1
            && ($artist === null || $this->same($artist, $this->clean($m[1]))
                || preg_match('/(?:19|20)\d{2}|flac|mp3|m4a|aac|lossless|无损/iu', $m[2]) === 1)) {
            $artist ??= $this->clean($m[1]);
            $album = $this->clean($m[2]);
        }
        $album = $album === null ? null : (string) preg_replace('/\s+(?:19|20)\d{2}(?:\s+.*)?$/u', '', $album);
        $album = $album === null ? null : (string) preg_replace('/\s+(?:flac|mp3|m4a|aac|lossless|无损)(?:\s+.*)?$/iu', '', $album);
        $album = $album === '' ? null : $album;
        $file = (string) preg_replace('/^\s*(?:\d{1,4}[ ._-]+|[A-Z]?\d{1,3}[ ._-]+)(?=\S)/iu', '', $file);
        $file = (string) preg_replace('/\s*[\(\[（【][^\)\]）】]{0,80}(?:live|remix|mix|instrumental|karaoke|伴奏|现场|混音)[^\)\]）】]*[\)\]）】]\s*$/iu', '', $file);
        $featured = [];
        if (preg_match('/^(.*?)\s*[\(\[（【](?:feat\.?|ft\.?|featuring)\s+(.+?)[\)\]）】]\s*$/iu', $file, $m) === 1) {
            $file = $this->clean($m[1]);
            $featured = $this->artists($m[2]);
        }
        $parts = $this->parts($file);
        $variants = [];
        if (count($parts) === 2) {
            [$left, $right] = $parts;
            if ($artist !== null && $this->same($artist, $left)) {
                $variants[] = [$right, array_merge($this->artists($artist), $featured)];
            } elseif ($artist !== null && $this->same($artist, $right)) {
                $variants[] = [$left, array_merge($this->artists($artist), $featured)];
            } else {
                $variants[] = [$right, array_merge($this->artists($left), $featured)];
                $variants[] = [$left, array_merge($this->artists($right), $featured)];
            }
        } else {
            $variants[] = [$file, array_merge($artist === null ? ['未知艺术家'] : $this->artists($artist), $featured)];
        }
        $requests = [];
        foreach ($variants as [$title, $artists]) {
            $title = $this->clean($title);
            if ($title === '') continue;
            $requests[] = MetadataScrapeCompletionRequest::fromMetadata(
                $title,
                $artists,
                $album,
                $artist === null ? null : $this->artists($artist),
                durationMs: $input->durationMs,
            );
            if (count($requests) >= 2) break;
        }
        return $requests;
    }

    /** @return list<string> */
    private function parts(string $value): array
    {
        foreach ([
            '/^(.{1,160}?)\s+[-–—]\s+(.{1,240})$/u',
            '/^([^–—]{1,160})[–—]([^–—]{1,240})$/u',
            '/^([^-]{1,160})\s+-\s+([^-]{1,240})$/u',
        ] as $pattern) {
            if (preg_match($pattern, $value, $m) === 1) return [$this->clean($m[1]), $this->clean($m[2])];
        }
        return [];
    }

    /** @return list<string> */
    private function artists(string $value): array
    {
        $parts = preg_split('/\s*(?:、|,|，|;|；|&)\s*/u', $value) ?: [];
        $result = [];
        foreach ($parts as $part) if (($part = $this->clean($part)) !== '' && !in_array($part, $result, true)) $result[] = $part;
        return $result === [] ? ['未知艺术家'] : array_slice($result, 0, 8);
    }

    private function clean(string $value): string
    {
        return trim((string) preg_replace('/\s+/u', ' ', $value));
    }

    private function same(string $left, string $right): bool
    {
        return mb_strtolower($this->clean($left), 'UTF-8') === mb_strtolower($this->clean($right), 'UTF-8');
    }
}
