<?php

declare(strict_types=1);

namespace plugin\metadata_scrape\app;

use app\application\ResourcePlugin\Contract\MetadataScrapeCompletionRequest;

/**
 * MetadataScrapeLookupGateway 隔离元数据插件的最终选择器与其自带 Go 查询二进制。
 *
 * 输入只能是核心冻结后的歌名、艺人及可选专辑信息；关键词由插件自行派生。实现不得读取核心来源目录、
 * 代理、Cookie 或环境变量指定的可执行路径。返回值仍是插件私有的多源查询中间结果，必须在本插件内完成
 * 评分、合成和收敛，不能透传给核心任务表、审计或浏览器。实现故障抛出异常，由核心入口回退旧 Provider。
 */
interface MetadataScrapeLookupGateway
{
    /**
     * 查询插件编译期固定的第三方来源。
     *
     * 每次调用只运行一个短命 Helper 进程，不写数据库、媒体文件或缓存。结果的来源顺序和字段边界
     * 由实现复验；网络、超时、退出码和协议错误必须失败关闭，不能被解释为正常的 unmatched。
     *
     * @return list<array<string,mixed>> 插件内部使用的受限渠道结果，禁止直接返回给核心。
     */
    public function lookup(MetadataScrapeCompletionRequest $request): array;
}
