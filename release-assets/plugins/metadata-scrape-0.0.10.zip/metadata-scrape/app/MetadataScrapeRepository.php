<?php

declare(strict_types=1);

namespace plugin\metadata_scrape\app;

use app\application\ResourcePlugin\Contract\MetadataScrapeCompletionRequest;
use app\application\ResourcePlugin\PhpResourcePluginOperationConflict;
use stdClass;
use support\Db;
use Symfony\Component\Uid\Ulid;

/**
 * 元数据刮削插件的持久化边界。
 *
 * 这里的三张表完全属于插件：核心只通过管理合同读取脱敏投影，第三方来源启停、任务生命周期和内部
 * 诊断不会写入核心刮削任务表。所有 JSON 都在写入前由调用方限制为通用字段或稳定诊断码；本类绝不
 * 保存第三方原始响应、请求 URL、凭据、歌词正文、远端封面地址、平台私有 ID、物理路径或 Worker 租约。
 */
final readonly class MetadataScrapeRepository
{
    private const EXPORT_MAX_LOGS = 10_000;
    private const EXPORT_MAX_BYTES = 4_194_304;
    private const EXPORT_TTL_SECONDS = 3600;

    /** @var list<array{key:string,name:string,priority:int}> */
    private const DEFAULT_SOURCES = [
        ['key' => 'netease', 'name' => '网易云音乐', 'priority' => 10],
        ['key' => 'qq', 'name' => 'QQ 音乐', 'priority' => 20],
        ['key' => 'kugou', 'name' => '酷狗音乐', 'priority' => 30],
        ['key' => 'kuwo', 'name' => '酷我音乐', 'priority' => 40],
        ['key' => 'migu', 'name' => '咪咕音乐', 'priority' => 50],
        ['key' => 'soda', 'name' => '汽水音乐', 'priority' => 60],
        ['key' => 'apple_music', 'name' => 'Apple Music', 'priority' => 70],
        ['key' => 'musicbrainz', 'name' => 'MusicBrainz', 'priority' => 80],
        ['key' => 'lrclib', 'name' => 'LRCLIB', 'priority' => 90],
    ];

    /** 创建插件自有表。调用者保证此方法运行在核心生命周期事务内。 */
    public function install(int $fromVersion): void
    {
        if ($fromVersion < 0 || $fromVersion > 3) throw new \RuntimeException('METADATA_SCRAPE_DATABASE_VERSION_INVALID');
        Db::connection()->statement(<<<'SQL'
CREATE TABLE IF NOT EXISTS metadata_scrape_sources (
    source_key TEXT PRIMARY KEY NOT NULL,
    display_name TEXT NOT NULL,
    enabled INTEGER NOT NULL DEFAULT 1 CHECK (enabled IN (0, 1)),
    priority INTEGER NOT NULL CHECK (priority BETWEEN 1 AND 1000),
    version INTEGER NOT NULL DEFAULT 1 CHECK (version >= 1),
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
)
SQL);
        Db::connection()->statement(<<<'SQL'
CREATE TABLE IF NOT EXISTS metadata_scrape_tasks (
    id TEXT PRIMARY KEY NOT NULL,
    title TEXT NOT NULL,
    artists_json TEXT NOT NULL,
    album_title TEXT NULL,
    album_artists_json TEXT NULL,
    duration_ms INTEGER NULL CHECK (duration_ms IS NULL OR duration_ms BETWEEN 1 AND 86400000),
    status TEXT NOT NULL CHECK (status IN ('running','matched','unmatched','unavailable','failed')),
    confidence INTEGER NULL CHECK (confidence IS NULL OR confidence BETWEEN 85 AND 100),
    metadata_json TEXT NOT NULL DEFAULT '{}',
    error_code TEXT NULL,
    core_task_id TEXT NULL,
    attempt_count INTEGER NOT NULL DEFAULT 1 CHECK (attempt_count >= 1),
    retry_count INTEGER NOT NULL DEFAULT 0 CHECK (retry_count >= 0),
    created_at TEXT NOT NULL,
    started_at TEXT NOT NULL,
    finished_at TEXT NULL
)
SQL);
        Db::connection()->statement('CREATE INDEX IF NOT EXISTS idx_metadata_scrape_tasks_created ON metadata_scrape_tasks(created_at)');
        Db::connection()->statement('CREATE INDEX IF NOT EXISTS idx_metadata_scrape_tasks_status ON metadata_scrape_tasks(status, created_at)');
        Db::connection()->statement(<<<'SQL'
CREATE TABLE IF NOT EXISTS metadata_scrape_task_logs (
    id TEXT PRIMARY KEY NOT NULL,
    task_id TEXT NOT NULL REFERENCES metadata_scrape_tasks(id) ON DELETE CASCADE,
    sequence INTEGER NOT NULL CHECK (sequence >= 1),
    level TEXT NOT NULL CHECK (level IN ('info','warning','error')),
    stage TEXT NOT NULL,
    source_key TEXT NULL,
    status TEXT NOT NULL,
    event_code TEXT NOT NULL,
    message TEXT NOT NULL,
    details_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL,
    UNIQUE(task_id, sequence)
)
SQL);
        Db::connection()->statement('CREATE INDEX IF NOT EXISTS idx_metadata_scrape_task_logs_task ON metadata_scrape_task_logs(task_id, sequence)');
        foreach ([
            ['metadata_scrape_tasks', 'metadata_json', "TEXT NOT NULL DEFAULT '{}'"],
            ['metadata_scrape_tasks', 'core_task_id', 'TEXT NULL'],
            ['metadata_scrape_tasks', 'attempt_count', 'INTEGER NOT NULL DEFAULT 1'],
            ['metadata_scrape_tasks', 'retry_count', 'INTEGER NOT NULL DEFAULT 0'],
            ['metadata_scrape_tasks', 'duration_ms', 'INTEGER NULL'],
        ] as [$table, $column, $definition]) {
            $this->ensureColumn($table, $column, $definition);
        }
        Db::connection()->statement(
            'CREATE UNIQUE INDEX IF NOT EXISTS idx_metadata_scrape_tasks_core_task ON metadata_scrape_tasks(core_task_id) WHERE core_task_id IS NOT NULL',
        );
        $this->seedSources();
    }

    /** 为历史表补充最终基线列；仅添加缺失列，保留任务、日志和重试计数原值。 */
    private function ensureColumn(string $table, string $column, string $definition): void
    {
        $columns = Db::connection()->select("PRAGMA table_info('{$table}')");
        foreach ($columns as $current) {
            if ((string) ($current->name ?? '') === $column) return;
        }
        Db::connection()->statement("ALTER TABLE {$table} ADD COLUMN {$column} {$definition}");
    }

    /** 从旧固定来源表只迁移一次启停和优先级；迁移后 Helper 不再依赖核心来源表。 */
    private function seedSources(): void
    {
        $now = gmdate('Y-m-d\\TH:i:s\\Z');
        $legacy = [];
        if (Db::connection()->getSchemaBuilder()->hasTable('music_sources')) {
            foreach (Db::table('music_sources')->whereIn('source_key', array_column(self::DEFAULT_SOURCES, 'key'))->get() as $row) {
                $legacy[(string) $row->source_key] = $row;
            }
        }
        foreach (self::DEFAULT_SOURCES as $source) {
            $row = $legacy[$source['key']] ?? null;
            if (Db::table('metadata_scrape_sources')->where('source_key', $source['key'])->exists()) continue;
            Db::table('metadata_scrape_sources')->insert([
                'source_key' => $source['key'], 'display_name' => is_object($row) ? (string) $row->display_name : $source['name'],
                'enabled' => is_object($row) ? (int) $row->enabled : 1,
                'priority' => is_object($row) ? (int) $row->priority : $source['priority'], 'version' => 1,
                'created_at' => $now, 'updated_at' => $now,
            ]);
        }
    }

    /** @return list<string> 当前插件启用来源，供 Helper 使用；表缺失只为单元测试保留固定安全默认值。 */
    public function enabledSourceKeys(): array
    {
        if (!Db::connection()->getSchemaBuilder()->hasTable('metadata_scrape_sources')) {
            return array_column(self::DEFAULT_SOURCES, 'key');
        }
        return Db::table('metadata_scrape_sources')->where('enabled', 1)->orderBy('priority')->orderBy('source_key')
            ->pluck('source_key')->map(static fn (mixed $key): string => (string) $key)->all();
    }

    /** @return array{version:int,sources:list<array<string,mixed>>} */
    public function sources(): array
    {
        $rows = Db::table('metadata_scrape_sources')->orderBy('priority')->orderBy('source_key')->get();
        $sources = [];
        $version = 1;
        foreach ($rows as $row) {
            $version = max($version, (int) $row->version);
            $sources[] = ['key' => (string) $row->source_key, 'name' => (string) $row->display_name,
                'enabled' => (bool) $row->enabled, 'priority' => (int) $row->priority, 'version' => (int) $row->version,
                'status' => 'configured'];
        }
        return ['version' => $version, 'sources' => $sources];
    }

    /** @param array<string,mixed> $command */
    public function updateSource(string $sourceKey, array $command): array
    {
        if (preg_match('/^[a-z][a-z0-9_]{1,31}$/D', $sourceKey) !== 1
            || array_diff(array_keys($command), ['enabled', 'priority', 'expectedVersion']) !== []
            || !is_bool($command['enabled'] ?? null) || !is_int($command['priority'] ?? null)
            || $command['priority'] < 1 || $command['priority'] > 1000
            || !is_int($command['expectedVersion'] ?? null) || $command['expectedVersion'] < 1) {
            throw new \InvalidArgumentException('METADATA_SCRAPE_SOURCE_INVALID');
        }
        $now = gmdate('Y-m-d\\TH:i:s\\Z');
        $changed = Db::table('metadata_scrape_sources')->where('source_key', $sourceKey)
            ->where('version', $command['expectedVersion'])->update([
                'enabled' => $command['enabled'] ? 1 : 0, 'priority' => $command['priority'],
                'version' => Db::raw('version + 1'), 'updated_at' => $now,
            ]);
        if ($changed !== 1) throw new \RuntimeException('METADATA_SCRAPE_SOURCE_VERSION_CONFLICT');
        return $this->sources();
    }

    /**
     * 为一次插件调用取得唯一任务记录，并把重试归并到原任务。
     *
     * 核心 target 的不透明关联键是唯一边界；同一 target 的自动重试或管理员重试只增加 attempt/retry
     * 计数并复用同一个 task_id。旧调用没有关联键时仍创建独立记录，以保持插件接口的向后兼容。所有尝试
     * 都追加到同一日志序列，任务终态由最后一次调用更新；本方法不把关联键或重试次数交给 Helper。
     */
    public function beginAttempt(MetadataScrapeCompletionRequest $request): ?string
    {
        if (!Db::connection()->getSchemaBuilder()->hasTable('metadata_scrape_tasks')) return null;
        return Db::transaction(function () use ($request): string {
            $now = gmdate('Y-m-d\\TH:i:s\\Z');
            $identity = $request->taskIdentity;
            $payload = [
                'id' => (string) new Ulid(), 'title' => $request->title,
                'artists_json' => json_encode($request->artists, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE),
                'album_title' => $request->albumTitle,
                'album_artists_json' => $request->albumArtists === null ? null : json_encode($request->albumArtists, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE),
                'duration_ms' => $request->durationMs,
                'status' => 'running', 'metadata_json' => '{}', 'core_task_id' => $identity,
                'attempt_count' => 1, 'retry_count' => 0, 'created_at' => $now, 'started_at' => $now,
            ];
            $inserted = $identity === null
                ? Db::table('metadata_scrape_tasks')->insert($payload)
                : Db::table('metadata_scrape_tasks')->insertOrIgnore($payload);
            if ($inserted === 1) {
                $this->log((string) $payload['id'], 'info', 'task', null, 'running', 'TASK_STARTED', '已开始执行插件刮削任务', [
                    'attempt' => 1, 'retryCount' => 0,
                ]);
                return (string) $payload['id'];
            }
            $row = Db::table('metadata_scrape_tasks')->where('core_task_id', $identity)->first(['id']);
            if (!$row instanceof stdClass) throw new \RuntimeException('METADATA_SCRAPE_TASK_CONFLICT');
            $changed = Db::table('metadata_scrape_tasks')->where('id', (string) $row->id)->update([
                'status' => 'running', 'confidence' => null, 'metadata_json' => '{}', 'error_code' => null,
                'finished_at' => null, 'attempt_count' => Db::raw('attempt_count + 1'), 'retry_count' => Db::raw('retry_count + 1'),
                'duration_ms' => $request->durationMs,
            ]);
            if ($changed !== 1) throw new \RuntimeException('METADATA_SCRAPE_TASK_CONFLICT');
            $current = Db::table('metadata_scrape_tasks')->where('id', (string) $row->id)->first(['attempt_count', 'retry_count']);
            $attempt = $current instanceof stdClass ? (int) $current->attempt_count : 0;
            $retryCount = $current instanceof stdClass ? (int) $current->retry_count : 0;
            $this->log((string) $row->id, 'info', 'task', null, 'running', 'TASK_RETRY_STARTED', '正在重试插件刮削任务', [
                'attempt' => $attempt, 'retryCount' => $retryCount,
            ]);
            return (string) $row->id;
        });
    }

    /** 兼容旧调用方名称；新代码应使用 beginAttempt 以明确重试复用语义。 */
    public function createTask(MetadataScrapeCompletionRequest $request): ?string
    {
        return $this->beginAttempt($request);
    }

    /** @param array<string,mixed> $details */
    public function log(?string $taskId, string $level, string $stage, ?string $sourceKey, string $status,
        string $eventCode, string $message, array $details): void
    {
        if ($taskId === null) return;
        $next = (int) (Db::table('metadata_scrape_task_logs')->where('task_id', $taskId)->max('sequence') ?? 0) + 1;
        Db::table('metadata_scrape_task_logs')->insert([
            'id' => (string) new Ulid(), 'task_id' => $taskId, 'sequence' => $next, 'level' => $level,
            'stage' => $stage, 'source_key' => $sourceKey, 'status' => $status, 'event_code' => $eventCode,
            'message' => $message, 'details_json' => json_encode($details, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE),
            'created_at' => gmdate('Y-m-d\\TH:i:s\\Z'),
        ]);
    }

    /** @param array<string,mixed>|null $metadata */
    public function finish(?string $taskId, string $status, ?int $confidence = null, ?array $metadata = null, ?string $errorCode = null): void
    {
        if ($taskId === null) return;
        Db::table('metadata_scrape_tasks')->where('id', $taskId)->update([
            'status' => $status, 'confidence' => $confidence, 'metadata_json' => json_encode($metadata ?? [], JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE),
            'error_code' => $errorCode, 'finished_at' => gmdate('Y-m-d\\TH:i:s\\Z'),
        ]);
    }

    /**
     * 按稳定顺序返回插件任务分页。
     *
     * query 已由核心约束为受支持状态、1-50 的 limit 和非负 offset；插件仍再次收敛数值，避免内部调用绕过
     * HTTP 边界。total 与当前页在同一请求内顺序读取，但不持有写事务，允许 Worker 继续完成任务；因此这是
     * 管理视图快照而非并发锁。排序同时使用 created_at 和不可变 ULID，时间相同也不会随机换页。清理导致
     * offset 超出范围时归一到最后一个有效页，空集合固定返回 offset=0。响应只投影脱敏任务字段。
     *
     * @param array<string,mixed> $query
     * @return array{tasks:list<array<string,mixed>>,total:int,limit:int,offset:int}
     */
    public function tasks(array $query): array
    {
        $limit = min(50, max(1, (int) ($query['limit'] ?? 50)));
        $offset = min(1_000_000, max(0, (int) ($query['offset'] ?? 0)));
        $builder = Db::table('metadata_scrape_tasks');
        if (is_string($query['status'] ?? null) && in_array($query['status'], ['running','matched','unmatched','unavailable','failed'], true)) {
            $builder->where('status', $query['status']);
        }
        $total = (int) (clone $builder)->count();
        $offset = $total === 0 ? 0 : min($offset, intdiv($total - 1, $limit) * $limit);
        $items = $builder->orderByDesc('created_at')->orderByDesc('id')->offset($offset)->limit($limit)->get()
            ->map(fn (stdClass $row): array => $this->taskProjection($row))->all();
        return ['tasks' => $items, 'total' => $total, 'limit' => $limit, 'offset' => $offset];
    }

    /**
     * 清理插件任务历史中的终态记录。
     *
     * 前置条件：调用者已经通过核心管理边界完成 Session、权限、CSRF 和插件数据库版本校验。事务内先
     * 统计 running 任务，再锁定并删除其余终态任务的日志和任务行；running 任务及其日志始终保留，避免
     * Worker 在网络调用期间失去审计归属。删除范围只包含插件自有表，不会修改核心任务、媒体文件或扫描
     * 历史。重复调用没有终态记录时返回 0，数据库失败整体回滚。
     *
     * @return array{deletedCount:int,activeCount:int}
     */
    public function clearTasks(): array
    {
        if (!Db::connection()->getSchemaBuilder()->hasTable('metadata_scrape_tasks')) {
            return ['deletedCount' => 0, 'activeCount' => 0];
        }
        return Db::transaction(function (): array {
            $activeCount = (int) Db::table('metadata_scrape_tasks')->where('status', 'running')->count();
            $taskIds = Db::table('metadata_scrape_tasks')
                ->whereIn('status', ['matched', 'unmatched', 'unavailable', 'failed'])
                ->pluck('id')->map(static fn (mixed $id): string => (string) $id)->all();
            if ($taskIds === []) return ['deletedCount' => 0, 'activeCount' => $activeCount];

            // 显式删除日志而不是依赖 SQLite 外键开关，确保不同部署连接配置下都不会留下孤立诊断记录。
            Db::table('metadata_scrape_task_logs')->whereIn('task_id', $taskIds)->delete();
            $deletedCount = Db::table('metadata_scrape_tasks')->whereIn('id', $taskIds)->delete();
            return ['deletedCount' => (int) $deletedCount, 'activeCount' => $activeCount];
        });
    }

    /**
     * 返回单个插件任务及其按执行顺序排列的日志。
     *
     * 日志中的 source_key 是插件内部稳定渠道身份，任务详情允许同时投影配置表中的中文显示名，便于管理员
     * 区分每条候选来自哪个渠道；该身份只存在于插件管理页，不回流核心刮削记录。删除来源配置或读取不到
     * 显示名时保留稳定 key 供前端回退，不能因此查询远端或暴露平台资源 ID、URL、正文与凭据。
     *
     * @return array<string,mixed>
     */
    public function task(string $taskId): array
    {
        if (preg_match('/^[0-9A-HJKMNP-TV-Z]{26}$/D', $taskId) !== 1) throw new \InvalidArgumentException('METADATA_SCRAPE_TASK_INVALID');
        $row = Db::table('metadata_scrape_tasks')->where('id', $taskId)->first();
        if (!$row instanceof stdClass) throw new \RuntimeException('METADATA_SCRAPE_TASK_NOT_FOUND');
        $logs = Db::table('metadata_scrape_task_logs as logs')
            ->leftJoin('metadata_scrape_sources as sources', 'sources.source_key', '=', 'logs.source_key')
            ->where('logs.task_id', $taskId)->orderBy('logs.sequence')
            ->get(['logs.*', 'sources.display_name as source_name'])
            ->map(static fn (stdClass $log): array => ['id' => (string) $log->id, 'sequence' => (int) $log->sequence,
                'level' => (string) $log->level, 'stage' => (string) $log->stage,
                'status' => (string) $log->status, 'eventCode' => (string) $log->event_code, 'message' => (string) $log->message,
                'sourceKey' => $log->source_key === null ? null : (string) $log->source_key,
                'sourceName' => $log->source_name === null ? null : (string) $log->source_name,
                'details' => json_decode((string) $log->details_json, true, 16, JSON_THROW_ON_ERROR), 'createdAt' => (string) $log->created_at])->all();
        $projection = $this->taskProjection($row);
        $projection['logs'] = $logs;
        return $projection;
    }

    /**
     * 生成单个插件刮削任务的安全诊断文件。
     *
     * taskId 只能定位一条插件任务；调用者已经在核心路由完成管理员 Session 和插件生命周期校验，
     * 本方法仍重新查询任务，避免导出过程依赖前端之前读到的快照。导出只保留任务身份、状态、阶段、
     * 稳定错误码和白名单诊断数值，不输出 metadata_json、候选内容、第三方 URL、原始响应、绝对路径或
     * 凭据。文件先以 0600 临时文件写完并校验，再原子改名；任意失败都会删除临时文件且不会改变任务。
     *
     * @return array{path:string,downloadName:string,sha256:string,byteSize:int,recordCount:int}
     */
    public function exportTaskLog(string $taskId): array
    {
        $this->assertTaskId($taskId);
        $task = Db::table('metadata_scrape_tasks')->where('id', $taskId)->first([
            'id', 'title', 'artists_json', 'album_title', 'album_artists_json', 'duration_ms', 'status',
            'confidence', 'error_code', 'attempt_count', 'retry_count', 'created_at', 'started_at', 'finished_at',
        ]);
        if (!$task instanceof stdClass) throw new \RuntimeException('METADATA_SCRAPE_TASK_NOT_FOUND');

        $logs = Db::table('metadata_scrape_task_logs as logs')
            ->leftJoin('metadata_scrape_sources as sources', 'sources.source_key', '=', 'logs.source_key')
            ->where('logs.task_id', $taskId)->orderBy('logs.sequence')->limit(self::EXPORT_MAX_LOGS + 1)
            ->get(['logs.*', 'sources.display_name as source_name'])->all();
        if (count($logs) > self::EXPORT_MAX_LOGS) throw new \RuntimeException('METADATA_SCRAPE_LOG_EXPORT_TOO_LARGE');

        $document = [
            'schemaVersion' => 1,
            'generatedAt' => gmdate('c'),
            'task' => $this->safeTaskForExport($task),
            'logs' => array_map(fn (stdClass $log): array => $this->safeLogForExport($log), $logs),
        ];
        $json = json_encode($document, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (strlen($json) > self::EXPORT_MAX_BYTES) throw new \RuntimeException('METADATA_SCRAPE_LOG_EXPORT_TOO_LARGE');

        $root = $this->prepareExportRoot();
        $this->cleanupExportArtifacts($root);
        $suffix = bin2hex(random_bytes(8));
        $temporary = $root . DIRECTORY_SEPARATOR . '.' . $taskId . '-' . $suffix . '.tmp';
        $target = $root . DIRECTORY_SEPARATOR . $taskId . '-' . $suffix . '.json';
        try {
            $written = file_put_contents($temporary, $json, LOCK_EX);
            if ($written !== strlen($json) || !chmod($temporary, 0600)) {
                throw new \RuntimeException('METADATA_SCRAPE_LOG_EXPORT_WRITE_FAILED');
            }
            if (!rename($temporary, $target) || !chmod($target, 0600)) {
                throw new \RuntimeException('METADATA_SCRAPE_LOG_EXPORT_PUBLISH_FAILED');
            }
            return [
                'path' => $target,
                'downloadName' => 'velin-music-metadata-scrape-' . $taskId . '.json',
                'sha256' => hash('sha256', $json),
                'byteSize' => strlen($json),
                'recordCount' => count($logs),
            ];
        } catch (\Throwable $failure) {
            if (is_file($temporary)) @unlink($temporary);
            if (is_file($target)) @unlink($target);
            throw $failure;
        }
    }

    /** @return array<string,mixed> */
    private function safeTaskForExport(stdClass $task): array
    {
        return [
            'id' => (string) $task->id,
            'title' => $this->safeText((string) $task->title, 512),
            'artists' => $this->safeStringList($this->decodeList($task->artists_json), 8, 256),
            'albumTitle' => $task->album_title === null ? null : $this->safeText((string) $task->album_title, 512),
            'albumArtists' => $task->album_artists_json === null
                ? null : $this->safeStringList($this->decodeList($task->album_artists_json), 8, 256),
            'durationMs' => $task->duration_ms === null ? null : (int) $task->duration_ms,
            'status' => $this->safeToken((string) $task->status, 32),
            'confidence' => $task->confidence === null ? null : (int) $task->confidence,
            'errorCode' => $task->error_code === null ? null : $this->safeErrorCode((string) $task->error_code),
            'attemptCount' => (int) $task->attempt_count,
            'retryCount' => (int) $task->retry_count,
            'createdAt' => (string) $task->created_at,
            'startedAt' => (string) $task->started_at,
            'finishedAt' => $task->finished_at === null ? null : (string) $task->finished_at,
        ];
    }

    /** @return array<string,mixed> */
    private function safeLogForExport(stdClass $log): array
    {
        return [
            'id' => (string) $log->id,
            'sequence' => (int) $log->sequence,
            'level' => $this->safeToken((string) $log->level, 16),
            'stage' => $this->safeToken((string) $log->stage, 64),
            'status' => $this->safeToken((string) $log->status, 32),
            'eventCode' => $this->safeToken((string) $log->event_code, 100),
            'sourceKey' => $log->source_key === null ? null : $this->safeToken((string) $log->source_key, 48),
            'sourceName' => $log->source_name === null ? null : $this->safeText((string) $log->source_name, 120),
            'message' => $this->safeText((string) $log->message, 512),
            'details' => $this->safeDetails($log->details_json),
            'createdAt' => (string) $log->created_at,
        ];
    }

    /** @return array<string,mixed> */
    private function safeDetails(mixed $encoded): array
    {
        if (!is_string($encoded) || strlen($encoded) > 65_536) return [];
        try {
            $details = json_decode($encoded, true, 16, JSON_THROW_ON_ERROR);
        } catch (\Throwable) {
            return [];
        }
        if (!is_array($details) || array_is_list($details)) return [];
        $safe = [];
        foreach (['candidateCount', 'latencyMs', 'score', 'queryPosition', 'confidence', 'attempt', 'retryCount'] as $key) {
            if (is_int($details[$key] ?? null) || is_float($details[$key] ?? null)) {
                $safe[$key] = (int) $details[$key];
            }
        }
        if (is_string($details['errorCode'] ?? null)) $safe['errorCode'] = $this->safeErrorCode($details['errorCode']);
        if (is_array($details['reasons'] ?? null)) {
            $safe['reasons'] = $this->safeStringList($details['reasons'], 16, 80);
        }
        if (is_array($details['dataTypes'] ?? null)) {
            $safe['dataTypes'] = array_values(array_intersect(
                array_map(static fn (mixed $item): string => is_string($item) ? $item : '', $details['dataTypes']),
                ['metadata', 'lyrics', 'artwork'],
            ));
        }
        return $safe;
    }

    /** @return list<mixed> */
    private function decodeList(mixed $encoded): array
    {
        if (!is_string($encoded) || strlen($encoded) > 16_384) return [];
        try {
            $decoded = json_decode($encoded, true, 16, JSON_THROW_ON_ERROR);
        } catch (\Throwable) {
            return [];
        }
        return is_array($decoded) && array_is_list($decoded) ? $decoded : [];
    }

    /** @param list<mixed> $values @return list<string> */
    private function safeStringList(array $values, int $maximumItems, int $maximumLength): array
    {
        $safe = [];
        foreach (array_slice($values, 0, $maximumItems) as $value) {
            if (!is_string($value)) continue;
            $safe[] = $this->safeText($value, $maximumLength);
        }
        return array_values(array_filter($safe, static fn (string $value): bool => $value !== ''));
    }

    private function safeText(string $value, int $maximumLength): string
    {
        $value = preg_replace('/https?:\\/\\/[^\\s<>"\']+/iu', '[redacted-url]', $value) ?? '';
        $value = preg_replace('/(token|password|passwd|secret|authorization)\\s*[=:]\\s*[^\\s,;]+/iu', '$1=[redacted]', $value) ?? $value;
        $value = preg_replace('~(?<![A-Za-z0-9])/(?:[^/\\s]+/){1,}[^\\s]+~u', '[redacted-path]', $value) ?? $value;
        $value = preg_replace('/[\\x00-\\x1F\\x7F]/u', ' ', $value) ?? $value;
        return mb_substr(trim(preg_replace('/\\s+/u', ' ', $value) ?? ''), 0, $maximumLength, 'UTF-8');
    }

    private function safeToken(string $value, int $maximumLength): string
    {
        $value = $this->safeText($value, $maximumLength);
        return preg_match('/^[A-Za-z0-9_.:-]+$/D', $value) === 1 ? $value : '[invalid]';
    }

    private function safeErrorCode(string $value): string
    {
        return preg_match('/^[A-Z][A-Z0-9_]{2,99}$/D', $value) === 1 ? $value : 'REDACTED_ERROR';
    }

    private function assertTaskId(string $taskId): void
    {
        if (preg_match('/^[0-9A-HJKMNP-TV-Z]{26}$/D', $taskId) !== 1) {
            throw new \InvalidArgumentException('METADATA_SCRAPE_TASK_INVALID');
        }
    }

    private function prepareExportRoot(): string
    {
        $root = base_path('runtime/plugin-reports/metadata-scrape');
        if (is_link($root)) throw new \RuntimeException('METADATA_SCRAPE_LOG_EXPORT_ROOT_INVALID');
        if (!is_dir($root) && !mkdir($root, 0700, true) && !is_dir($root)) {
            throw new \RuntimeException('METADATA_SCRAPE_LOG_EXPORT_ROOT_UNAVAILABLE');
        }
        if (!chmod($root, 0700)) throw new \RuntimeException('METADATA_SCRAPE_LOG_EXPORT_ROOT_UNAVAILABLE');
        $resolved = realpath($root);
        if (!is_string($resolved) || !is_dir($resolved) || is_link($resolved)) {
            throw new \RuntimeException('METADATA_SCRAPE_LOG_EXPORT_ROOT_INVALID');
        }
        return $resolved;
    }

    private function cleanupExportArtifacts(string $root): void
    {
        $entries = scandir($root);
        if (!is_array($entries)) return;
        $deadline = time() - self::EXPORT_TTL_SECONDS;
        $checked = 0;
        foreach ($entries as $entry) {
            if (++$checked > 200 || preg_match('/^(?:[0-9A-HJKMNP-TV-Z]{26}-[a-f0-9]{16}\\.json|\\.[0-9A-HJKMNP-TV-Z]{26}-[a-f0-9]{16}\\.tmp)$/', $entry) !== 1) continue;
            $path = $root . DIRECTORY_SEPARATOR . $entry;
            $stat = lstat($path);
            if (!is_array($stat) || is_link($path) || (($stat['mode'] ?? 0) & 0170000) !== 0100000) continue;
            if ((int) ($stat['mtime'] ?? PHP_INT_MAX) < $deadline) @unlink($path);
        }
    }

    /**
     * 根据旧任务保存的通用身份重建一次刮削请求。
     *
     * 只有 `failed` 与 `unavailable` 表示可以由管理员主动恢复；`unmatched` 是正常的无可信结果，不应
     * 通过按钮制造重试。提交前按核心关联键或完整身份检查活动任务，以处理双击和多个管理员同时操作；
     * 冲突直接返回 409，不会启动第二个 Helper。关联键存在时重试复用同一任务行并追加日志，旧表只保存
     * 元数据模式所需的标题、艺人和专辑字段；空艺人列表作为历史文件名模式标记重试，但不伪造缺失的目录上下文。
     */
    public function retryRequest(string $taskId): MetadataScrapeCompletionRequest
    {
        if (preg_match('/^[0-9A-HJKMNP-TV-Z]{26}$/D', $taskId) !== 1) {
            throw new \InvalidArgumentException('METADATA_SCRAPE_TASK_INVALID');
        }
        $row = Db::table('metadata_scrape_tasks')->where('id', $taskId)->first();
        if (!$row instanceof stdClass) throw new \RuntimeException('METADATA_SCRAPE_TASK_NOT_FOUND');
        if (!in_array((string) $row->status, ['failed', 'unavailable'], true)) {
            throw new \InvalidArgumentException('METADATA_SCRAPE_TASK_NOT_RETRYABLE');
        }
        $artists = json_decode((string) $row->artists_json, true, 16, JSON_THROW_ON_ERROR);
        $albumArtists = $row->album_artists_json === null
            ? null : json_decode((string) $row->album_artists_json, true, 16, JSON_THROW_ON_ERROR);
        if (!is_array($artists) || !array_is_list($artists)
            || ($albumArtists !== null && (!is_array($albumArtists) || !array_is_list($albumArtists)))) {
            throw new \InvalidArgumentException('METADATA_SCRAPE_TASK_IDENTITY_INVALID');
        }
        // 升级前的历史行没有核心 target 关联；为它绑定只在插件内部使用的稳定别名，人工重试仍复用原行。
        $taskIdentity = isset($row->core_task_id) && $row->core_task_id !== null
            ? (string) $row->core_task_id : 'metadata-plugin:' . $taskId;
        $runningQuery = Db::table('metadata_scrape_tasks')->where('status', 'running');
        if (isset($row->core_task_id) && $row->core_task_id !== null) {
            $runningQuery->where('core_task_id', (string) $row->core_task_id);
        } else {
            $runningQuery->where('title', (string) $row->title)->where('artists_json', (string) $row->artists_json)
                ->where(function ($query) use ($row): void {
                    if ($row->album_title === null) $query->whereNull('album_title');
                    else $query->where('album_title', (string) $row->album_title);
                })
                ->where(function ($query) use ($row): void {
                    if ($row->album_artists_json === null) $query->whereNull('album_artists_json');
                    else $query->where('album_artists_json', (string) $row->album_artists_json);
                });
        }
        $running = $runningQuery->exists();
        if ($running) throw new PhpResourcePluginOperationConflict('METADATA_SCRAPE_TASK_ALREADY_RUNNING');
        if ($row->core_task_id === null) {
            Db::table('metadata_scrape_tasks')->where('id', $taskId)->whereNull('core_task_id')->update([
                'core_task_id' => $taskIdentity,
            ]);
        }
        if ($artists === []) {
            // 旧表没有单独的 mode 列；空艺人列表是文件名模式的可辨识标记，目录上下文缺失时仍可安全重试。
            return MetadataScrapeCompletionRequest::fromFilename((string) $row->title, null, null,
                $taskIdentity, isset($row->duration_ms) && $row->duration_ms !== null ? (int) $row->duration_ms : null);
        }
        foreach ($artists as $artist) {
            if (!is_string($artist)) throw new \InvalidArgumentException('METADATA_SCRAPE_TASK_IDENTITY_INVALID');
        }
        if ($albumArtists !== null) {
            foreach ($albumArtists as $artist) {
                if (!is_string($artist)) throw new \InvalidArgumentException('METADATA_SCRAPE_TASK_IDENTITY_INVALID');
            }
        }
        return MetadataScrapeCompletionRequest::fromMetadata(
            (string) $row->title,
            array_values(array_map(static fn (mixed $artist): string => (string) $artist, $artists)),
            $row->album_title === null ? null : (string) $row->album_title,
            $albumArtists === null ? null : array_values(array_map(static fn (mixed $artist): string => (string) $artist, $albumArtists)),
            $taskIdentity,
            isset($row->duration_ms) && $row->duration_ms !== null ? (int) $row->duration_ms : null,
        );
    }

    /** @return array<string,mixed> */
    private function taskProjection(stdClass $row): array
    {
        return ['id' => (string) $row->id, 'title' => (string) $row->title,
            'artists' => json_decode((string) $row->artists_json, true, 16, JSON_THROW_ON_ERROR),
            'albumTitle' => $row->album_title === null ? null : (string) $row->album_title,
            'albumArtists' => $row->album_artists_json === null ? null : json_decode((string) $row->album_artists_json, true, 16, JSON_THROW_ON_ERROR),
            'status' => (string) $row->status, 'confidence' => $row->confidence === null ? null : (int) $row->confidence,
            'retryable' => in_array((string) $row->status, ['failed', 'unavailable'], true),
            'attemptCount' => (int) ($row->attempt_count ?? 1), 'retryCount' => (int) ($row->retry_count ?? 0),
            'metadata' => json_decode((string) $row->metadata_json, true, 16, JSON_THROW_ON_ERROR), 'errorCode' => $row->error_code === null ? null : (string) $row->error_code,
            'createdAt' => (string) $row->created_at, 'startedAt' => (string) $row->started_at,
            'finishedAt' => $row->finished_at === null ? null : (string) $row->finished_at];
    }

    public function uninstall(): void
    {
        Db::connection()->statement('DROP TABLE IF EXISTS metadata_scrape_task_logs');
        Db::connection()->statement('DROP TABLE IF EXISTS metadata_scrape_tasks');
        Db::connection()->statement('DROP TABLE IF EXISTS metadata_scrape_sources');
    }
}
