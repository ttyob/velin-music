<?php

declare(strict_types=1);

namespace plugin\metadata_scrape\app;

use app\application\ResourcePlugin\Contract\ArtistProfileScrapeRequest;
use app\application\ResourcePlugin\Contract\ArtistProfileScrapeResult;

/**
 * MetadataScrapeArtistProfileLookupGateway 是插件内部艺人资料查询实现的测试替换边界。
 *
 * 核心只能看到 ExternalArtistProfileHook；该接口不属于核心协议，因而 MusicBrainz、Wikidata 和
 * Wikipedia 的请求、聚合和失败分类可以在插件内演进。实现不得产生数据库、媒体文件或缓存副作用。
 */
interface MetadataScrapeArtistProfileLookupGateway
{
    public function lookup(ArtistProfileScrapeRequest $request): ArtistProfileScrapeResult;
}
