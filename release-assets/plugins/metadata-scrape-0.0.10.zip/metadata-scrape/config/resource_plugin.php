<?php

declare(strict_types=1);

use plugin\metadata_scrape\app\MetadataScrapePlugin;

/**
 * 元数据刮削插件 manifest。
 *
 * 插件通过随包 Go Helper 完成歌曲多源查询、平台歌单识别与目录同步，并在同包 PHP 边界完成艺人资料三方请求；插件页面管理自有
 * 来源目录、平台歌单配置、刮削任务、艺人辅助 SQLite 和脱敏来源日志。字段写入、歌词/封面发布、艺人资料落库和核心
 * 业务任务终态继续由
 * 核心状态机统一负责。包不得调用核心 source-helper 或在升级后读取核心来源配置。
 */
return [
    'key' => 'metadata-scrape',
    'name' => '元数据刮削',
    'version' => '0.0.10',
    'protocolVersion' => 1,
    'capabilities' => ['metadata_scrape', 'metadata_album', 'metadata_artist_artwork', 'metadata_artist_profile', 'metadata_artist_database', 'playlist_identification', 'playlist_sync', 'recommendation_provider', 'library_file_inspection', 'worker', 'database_lifecycle'],
    'adminPage' => [
        'path' => '/admin/plugins/metadata-scrape',
        'title' => '元数据刮削',
        'description' => '数据源、刮削任务、本地库文件检查与详细日志',
        'entry' => 'public/plugin-pages/metadata-scrape.html',
        'capability' => 'manage_system',
    ],
    'class' => MetadataScrapePlugin::class,
];
