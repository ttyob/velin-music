<?php

declare(strict_types=1);

namespace plugin\lx_music\app\application\Security;

use RuntimeException;

/**
 * LxSecretCipher 加密来源令牌、搜索引用和已解析下载上下文。
 *
 * 根密钥来自部署级 `VELIN_CREDENTIAL_KEY`，再通过 LX Music 独立 HKDF context 派生，密文不能与其他
 * 插件或核心凭据互换。purpose 进入认证明文，阻止把来源令牌密文误作下载 URL。明文不得进入日志、
 * 审计、HTTP 响应或异常；认证失败统一关闭，不暴露密钥轮换和数据损坏差异。
 */
final readonly class LxSecretCipher
{
    private string $key;

    public function __construct(?string $deploymentSecret = null)
    {
        $root = $deploymentSecret ?? getenv('VELIN_CREDENTIAL_KEY') ?: 'velin-development-credential-key-change-me';
        if (strlen($root) < 16) throw new RuntimeException('LX_MUSIC_CREDENTIAL_KEY_INVALID');
        $this->key = hash_hkdf('sha256', $root, SODIUM_CRYPTO_SECRETBOX_KEYBYTES, 'velin-lx-music-v1');
    }

    /** 加密已由调用方按用途验证的非空文本；随机 nonce 保证相同内容不会产生相同数据库值。 */
    public function encrypt(string $purpose, string $value): string
    {
        if (!$this->valid($purpose, $value)) throw new RuntimeException('LX_MUSIC_SECRET_INVALID');
        $nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        $plain = $purpose . "\0" . $value;
        return 'v1:' . base64_encode($nonce . sodium_crypto_secretbox($plain, $nonce, $this->key));
    }

    /** 解密并认证指定用途的密文；调用方使用后应尽快 `sodium_memzero()` 清理返回值。 */
    public function decrypt(string $purpose, ?string $payload): string
    {
        if (!is_string($payload) || !str_starts_with($payload, 'v1:')) {
            throw new RuntimeException('LX_MUSIC_SECRET_UNAVAILABLE');
        }
        $decoded = base64_decode(substr($payload, 3), true);
        if (!is_string($decoded) || strlen($decoded) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES) {
            throw new RuntimeException('LX_MUSIC_SECRET_UNAVAILABLE');
        }
        $plain = sodium_crypto_secretbox_open(
            substr($decoded, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES),
            substr($decoded, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES),
            $this->key,
        );
        $prefix = $purpose . "\0";
        if (!is_string($plain) || !str_starts_with($plain, $prefix)) {
            throw new RuntimeException('LX_MUSIC_SECRET_UNAVAILABLE');
        }
        $value = substr($plain, strlen($prefix));
        if (!$this->valid($purpose, $value)) throw new RuntimeException('LX_MUSIC_SECRET_UNAVAILABLE');
        return $value;
    }

    private function valid(string $purpose, string $value): bool
    {
        return in_array($purpose, ['source_token', 'search_reference', 'resolved_download'], true)
            && $value !== '' && strlen($value) <= 16_384 && !str_contains($value, "\0");
    }
}
