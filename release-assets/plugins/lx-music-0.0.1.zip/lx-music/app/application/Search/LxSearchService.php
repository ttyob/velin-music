<?php

declare(strict_types=1);

namespace plugin\lx_music\app\application\Search;

use app\application\Scrape\ChineseQueryVariantNormalizer;
use plugin\lx_music\app\application\Completion\LxCompletionSearch;
use plugin\lx_music\app\application\Download\LxDownloadQualityPolicy;
use plugin\lx_music\app\application\Download\LxDownloadSettingsService;
use plugin\lx_music\app\application\Security\LxSecretCipher;
use plugin\lx_music\app\application\Source\LxScriptRunnerClient;
use plugin\lx_music\app\application\Source\LxScriptRunnerFailure;
use plugin\lx_music\app\application\Source\LxSourceSuccessStatsService;
use plugin\lx_music\app\application\Source\LxSourceSettingsService;
use plugin\lx_music\app\application\Source\LxSourceHealthService;
use Symfony\Component\Uid\Ulid;
use support\Db;
use Throwable;

/**
 * LxSearchService 使用 Velin Go Helper 搜索平台，再绑定可解析地址的 LX 脚本来源。
 *
 * Go Helper 返回 LX API v2 `musicInfo`，但不返回播放 URL；每个启用脚本初始化后声明自己的平台和音质，
 * 搜索结果只展开双方共同支持的音质。完整 musicInfo、脚本 key 和平台 source 被加密进 15 分钟 actor
 * 租约，浏览器只得到展示字段。来源目录只接受 LX API v2 脚本，不再混入另一套 HTTP 搜索协议。
 * 连续三次后台 init 检测失败的来源会被健康服务排除，避免搜索继续向已确认异常的第三方源发请求；
 * 未达到阈值的瞬时失败仍保留在搜索候选中，避免一次网络抖动扩大为业务中断。
 */
final readonly class LxSearchService implements LxCompletionSearch
{
    public function __construct(
        private LxSourceSettingsService $settings = new LxSourceSettingsService(),
        private LxSecretCipher $cipher = new LxSecretCipher(),
        private LxHelperSearchClient $helper = new LxHelperSearchClient(),
        private LxScriptRunnerClient $runner = new LxScriptRunnerClient(),
        private LxDownloadSettingsService $downloadSettings = new LxDownloadSettingsService(),
        private LxSourceSuccessStatsService $stats = new LxSourceSuccessStatsService(),
        private LxSourceHealthService $health = new LxSourceHealthService(),
        private ChineseQueryVariantNormalizer $identityNormalizer = new ChineseQueryVariantNormalizer(),
    ) {
    }

    /**
     * 返回每个解析来源的真实初始化状态。
     *
     * 脚本来源会下载并初始化脚本，因此状态同时证明 Node runner、目标 HTTP(S) 地址和 LX v2 声明可用。
     * 错误只公开稳定码，不返回脚本地址、摘要、响应或 Token。
     */
    public function status(): array
    {
        $snapshot = $this->settings->snapshot();
        $enabled = array_values(array_filter($snapshot['sources'], static fn (array $source): bool => $source['enabled']));
        $connections = [];
        $scripts = [];
        foreach ($enabled as $source) {
            try {
                $connection = $this->settings->connection($source['key']);
                $connections[$source['key']] = $connection;
                if ($connection['type'] === 'lx_script') $scripts[$source['key']] = [
                    'scriptUrl' => $connection['baseUrl'], 'sourceToken' => $connection['token'],
                ];
            } catch (Throwable) {
                // 目录快照与连接投影来自同一设置；若并发更新或密文损坏，后续按来源不可用返回。
            }
        }
        $inspected = $scripts === [] ? ['details' => [], 'errors' => []] : $this->runner->inspectMany($scripts);
        foreach ($scripts as &$script) {
            if (is_string($script['sourceToken']) && $script['sourceToken'] !== '') sodium_memzero($script['sourceToken']);
        }
        unset($script);
        $available = 0;
        $states = [];
        foreach ($enabled as $source) {
            $connection = $connections[$source['key']] ?? null;
            try {
                if (!is_array($connection)) throw new LxSourceUnavailable();
                if (!isset($inspected['details'][$source['key']])) {
                    throw new LxScriptRunnerFailure($inspected['errors'][$source['key']] ?? 'LX_SOURCE_UNAVAILABLE');
                }
                $details = $inspected['details'][$source['key']];
                $health = is_array($source['health'] ?? null) ? $source['health'] : [];
                $healthAvailable = ($health['status'] ?? 'unknown') !== 'unhealthy';
                if ($healthAvailable) $available++;
                $states[] = ['key' => $source['key'], 'name' => $source['name'], 'type' => $source['type'],
                    'available' => $healthAvailable, 'errorCode' => $healthAvailable ? null : ($health['lastErrorCode'] ?? 'LX_SOURCE_UNAVAILABLE'),
                    'health' => $health,
                    'script' => ['name' => $details['name'], 'version' => $details['version'],
                        'sources' => $details['sources'], 'sha256' => $details['sha256']]];
            } catch (Throwable $failure) {
                $errorCode = match (true) {
                    $failure instanceof LxScriptRunnerFailure => $failure->errorCode,
                    default => 'LX_SOURCE_UNAVAILABLE',
                };
                $states[] = ['key' => $source['key'], 'name' => $source['name'], 'type' => $source['type'],
                    'available' => false, 'errorCode' => $errorCode,
                    'health' => is_array($source['health'] ?? null) ? $source['health'] : [], 'script' => null];
            } finally {
                if (is_array($connection) && is_string($connection['token'] ?? null) && $connection['token'] !== '') {
                    sodium_memzero($connection['token']);
                }
            }
        }
        return ['available' => $available > 0, 'enabledSources' => count($enabled), 'availableSources' => $available,
            'sources' => $states, 'errorCode' => $available > 0 ? null : ($enabled === [] ? 'LX_SOURCE_NOT_CONFIGURED' : 'LX_SOURCE_UNAVAILABLE'),
            'version' => $snapshot['version'], 'updatedAt' => $snapshot['updatedAt']];
    }

    /** @return array{query:string,total:int,limited:bool,items:list<array<string,mixed>>} */
    public function search(string $query, int $limit, string $actorId): array
    {
        $query = trim($query);
        $limit = max(1, min(50, $limit));
        if (mb_strlen($query, 'UTF-8') < 2 || mb_strlen($query, 'UTF-8') > 200
            || preg_match('/[\x00-\x1F\x7F]/u', $query) === 1
            || preg_match('/^[0-9A-HJKMNP-TV-Z]{26}$/D', $actorId) !== 1) throw new LxSearchInvalid();
        $raw = [];
        $successful = 0;
        $scripts = [];
        $connections = $this->health->filterAvailable($this->settings->activeConnections());
        $scriptConfigs = [];
        foreach ($connections as $connection) $scriptConfigs[$connection['key']] = [
            'scriptUrl' => $connection['baseUrl'], 'sourceToken' => $connection['token'],
        ];
        $inspected = $scriptConfigs === [] ? ['details' => [], 'errors' => []] : $this->runner->inspectMany($scriptConfigs);
        foreach ($scriptConfigs as &$scriptConfig) {
            if (is_string($scriptConfig['sourceToken']) && $scriptConfig['sourceToken'] !== '') {
                sodium_memzero($scriptConfig['sourceToken']);
            }
        }
        unset($scriptConfig);
        $successWeights = $this->stats->weights();
        foreach ($connections as $connection) {
            $details = $inspected['details'][$connection['key']] ?? null;
            if (is_array($details)) $scripts[] = $connection + [
                'capabilities' => $details['sources'], 'actions' => $details['actions'] ?? [],
                'sha256' => $details['sha256'],
                'successWeight' => $successWeights[$connection['key']] ?? 0,
            ];
        }
        if ($scripts !== []) {
            try {
                $helper = $this->helper->search($query, $limit);
                $normalizedIdentities = $this->normalizeIdentities($helper['items']);
                foreach ($helper['items'] as $index => $item) {
                    // OpenCC 只改变展示和聚合身份；租约中的 musicInfo 仍必须保留 Helper 原始值，避免解析引用失效。
                    $identity = is_array($normalizedIdentities[$index] ?? null) ? $normalizedIdentities[$index] : [];
                    $title = is_string($identity['title'] ?? null) && trim($identity['title']) !== ''
                        ? trim($identity['title']) : $item['title'];
                    $artist = is_string($identity['artist'] ?? null) ? trim($identity['artist']) : $item['artist'];
                    $album = is_string($identity['album'] ?? null) ? trim($identity['album']) : $item['album'];
                    foreach ($scripts as $script) {
                        $supported = $script['capabilities'][$item['source']] ?? [];
                        foreach ($item['qualities'] as $helperQuality) {
                            if (!in_array($helperQuality, $supported, true)) continue;
                            $quality = $helperQuality === 'flac24bit' ? 'flac24' : $helperQuality;
                            $raw[] = ['title' => $title, 'artist' => $artist, 'album' => $album,
                                'durationMs' => $item['durationMs'], 'qualities' => [[
                                    'quality' => $quality, 'format' => str_starts_with($quality, 'flac') ? 'flac' : 'mp3',
                                    'sizeBytes' => $this->size($item['musicInfo'], $helperQuality),
                                ]], 'sourceKey' => $script['key'],
                                'sourceName' => $this->platformName($item['source']) . ' / ' . $script['name'],
                                'platformKey' => $item['source'], 'platformName' => $this->platformName($item['source']),
                                'resolverName' => $script['name'], 'manualWeight' => $script['weight'],
                                'successWeight' => $script['successWeight'],
                                'referenceContext' => ['kind' => 'lx_script', 'source' => $item['source'],
                                    'musicInfo' => $item['musicInfo'], 'scriptSha256' => $script['sha256'],
                                    'assetActions' => $script['actions'][$item['source']] ?? [],
                                    'artworkUrl' => $item['artworkUrl'] === '' ? null : $item['artworkUrl']],
                            ];
                        }
                    }
                }
                $successful++;
            } catch (Throwable) {
                // Helper 全部平台失败时，插件没有其他搜索协议可回退，最终返回统一不可用错误。
            }
        }
        if ($successful === 0) throw new LxSearchUnavailable();
        $expanded = [];
        foreach ($raw as $item) {
            foreach ($item['qualities'] as $quality) {
                $key = mb_strtolower($item['title'] . "\0" . $item['artist'] . "\0" . $item['album'], 'UTF-8')
                    . "\0" . (string) ($item['durationMs'] ?? '') . "\0" . $quality['quality']
                    . "\0" . $item['platformKey'] . "\0" . $item['sourceKey'];
                $expanded[$key] ??= $item + $quality;
            }
        }
        $all = array_values($expanded);
        foreach ($all as $index => &$candidate) $candidate['originalIndex'] = $index;
        unset($candidate);
        usort($all, static function (array $left, array $right): int {
            $manual = $right['manualWeight'] <=> $left['manualWeight'];
            if ($manual !== 0) return $manual;
            $success = $right['successWeight'] <=> $left['successWeight'];
            if ($success !== 0) return $success;
            $quality = array_search($right['quality'], ['128k', '320k', 'flac', 'flac24'], true)
                <=> array_search($left['quality'], ['128k', '320k', 'flac', 'flac24'], true);
            return $quality !== 0 ? $quality : $left['originalIndex'] <=> $right['originalIndex'];
        });
        $groups = [];
        $ungrouped = 0;
        foreach ($all as $candidate) {
            $groupKey = $this->aggregationKey($candidate['title'], $candidate['artist']);
            if ($groupKey === null) $groupKey = "__single__\0" . $ungrouped++;
            $channelKey = $candidate['platformKey'] . "\0" . $candidate['sourceKey'] . "\0" . $candidate['quality'];
            $groups[$groupKey][$channelKey] ??= $candidate;
        }
        $limited = count($groups) > $limit;
        $selected = array_slice($groups, 0, $limit, true);
        $all = [];
        foreach ($selected as $candidates) $all = [...$all, ...array_values($candidates)];
        $minimumQuality = $this->downloadSettings->snapshot()['minimumQuality'];
        $leased = $this->lease($all, $actorId, $minimumQuality);
        return ['query' => $query, 'total' => count($selected), 'limited' => $limited,
            'items' => $this->aggregate($leased)];
    }

    /**
     * 以有界批次把 Helper 的歌曲身份转换为简体比较字段。
     *
     * OpenCC 失败时 normalizer 原样返回，因此不会把可用搜索升级成系统错误；返回值只供标题、艺人和
     * 专辑的展示/聚合使用，调用方必须继续从原始 Helper item 读取 musicInfo、平台和封面引用，保证租约
     * 的解析证据与第三方协议完全一致。
     *
     * @param list<array<string,mixed>> $items
     * @return list<array<string,mixed>>
     */
    private function normalizeIdentities(array $items): array
    {
        $variants = array_map(static fn (array $item): array => [
            'title' => $item['title'], 'artist' => $item['artist'], 'album' => $item['album'],
        ], $items);
        $normalized = [];
        foreach (array_chunk($variants, 8) as $batch) {
            $normalized = [...$normalized, ...$this->identityNormalizer->simplify($batch)];
        }
        return $normalized;
    }

    /**
     * 为展示结果签发 actor 绑定租约，并按当前最低质量投影可下载状态。
     *
     * 低质量结果仍保存租约并展示，便于管理员理解来源实际能力，但 `downloadable=false`。任务创建与
     * Worker 会再次读取实时配置，不能依赖该展示快照授权；本事务只写租约，不访问来源或创建文件。
     *
     * @param list<array<string,mixed>> $items
     * @return list<array<string,mixed>>
     */
    private function lease(array $items, string $actorId, string $minimumQuality): array
    {
        $now = gmdate('Y-m-d\TH:i:s\Z');
        $expires = gmdate('Y-m-d\TH:i:s\Z', time() + 900);
        return Db::transaction(function () use ($items, $actorId, $minimumQuality, $now, $expires): array {
            $expired = Db::table('lx_music_search_leases')->where('expires_at', '<', $now)
                ->whereNotExists(function ($query): void {
                    $query->selectRaw('1')->from('lx_music_download_jobs')
                        ->whereColumn('lx_music_download_jobs.search_lease_id', 'lx_music_search_leases.id');
                })->limit(100)->pluck('id')->all();
            if ($expired !== []) Db::table('lx_music_search_leases')->whereIn('id', $expired)->delete();
            $result = [];
            foreach ($items as $item) {
                $id = (string) new Ulid();
                $reference = json_encode($item['referenceContext'], JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                Db::table('lx_music_search_leases')->insert([
                    'id' => $id, 'actor_id' => $actorId, 'source_key' => $item['sourceKey'],
                    'title' => $item['title'], 'artist' => $item['artist'], 'album' => $item['album'],
                    'duration_ms' => $item['durationMs'], 'quality' => $item['quality'], 'format' => $item['format'],
                    'size_bytes' => $item['sizeBytes'],
                    'reference_ciphertext' => $this->cipher->encrypt('search_reference', $reference),
                    'expires_at' => $expires, 'created_at' => $now,
                ]);
                sodium_memzero($reference);
                $result[] = ['id' => $id, 'title' => $item['title'], 'artist' => $item['artist'],
                    'album' => $item['album'], 'durationMs' => $item['durationMs'], 'source' => $item['sourceName'],
                    'sourceKey' => $item['sourceKey'], 'platform' => $item['platformName'],
                    'platformKey' => $item['platformKey'], 'resolver' => $item['resolverName'],
                    'weight' => $item['manualWeight'], 'successWeight' => $item['successWeight'],
                    'quality' => $item['quality'], 'format' => $item['format'], 'sizeBytes' => $item['sizeBytes'],
                    'downloadable' => LxDownloadQualityPolicy::accepts(
                        (string) $item['quality'],
                        $minimumQuality,
                    )];
            }
            return $result;
        });
    }

    /**
     * 把标题和艺人一致的候选折叠为一首歌曲，同时保留每个下载渠道自己的 actor 租约。
     *
     * 渠道身份由平台、LX 解析源和音质共同组成；同平台不同脚本仍是不同可审计解析路径，不能在浏览器
     * 提交后再由服务端猜测。输入已经按管理员权重、历史成功次数和音质稳定排序，因此首项是默认渠道。
     * 聚合只发生在租约成功写入后，任何数据库或加密失败会回滚整批，不返回不可下载的展示占位项。
     *
     * @param list<array<string,mixed>> $leased
     * @return list<array<string,mixed>>
     */
    private function aggregate(array $leased): array
    {
        $groups = [];
        $single = 0;
        foreach ($leased as $candidate) {
            $key = $this->aggregationKey($candidate['title'] ?? null, $candidate['artist'] ?? null);
            if ($key === null) $key = "__single__\0" . $single++;
            $groups[$key][] = $candidate;
        }
        $result = [];
        foreach ($groups as $candidates) {
            $primary = current(array_filter(
                $candidates,
                static fn (array $candidate): bool => $candidate['downloadable'] === true,
            ));
            if (!is_array($primary)) $primary = $candidates[0];
            $primary['channels'] = array_map(static fn (array $candidate): array => [
                'leaseId' => $candidate['id'], 'source' => $candidate['source'],
                'platform' => $candidate['platform'], 'resolver' => $candidate['resolver'],
                'weight' => $candidate['weight'], 'successWeight' => $candidate['successWeight'],
                'quality' => $candidate['quality'], 'format' => $candidate['format'],
                'durationMs' => $candidate['durationMs'], 'sizeBytes' => $candidate['sizeBytes'],
                'downloadable' => $candidate['downloadable'],
            ], $candidates);
            unset($primary['sourceKey'], $primary['platformKey']);
            $result[] = $primary;
        }
        return $result;
    }

    /** 生成保守的歌曲身份键；缺少标题或艺人时返回 null，调用方必须保持结果独立。 */
    private function aggregationKey(mixed $title, mixed $artist): ?string
    {
        if (!is_string($title) || !is_string($artist)) return null;
        $normalize = static function (string $value): string {
            $value = trim($value);
            if (class_exists('Normalizer')) $value = \Normalizer::normalize($value, \Normalizer::FORM_KC) ?: $value;
            return preg_replace('/\s+/u', ' ', mb_strtolower($value, 'UTF-8')) ?? $value;
        };
        $title = $normalize($title);
        $artist = $normalize($artist);
        return $title === '' || $artist === '' ? null : $title . "\0" . $artist;
    }

    private function platformName(string $source): string
    {
        return ['wy' => '网易音乐', 'tx' => 'QQ 音乐', 'kg' => '酷狗音乐', 'kw' => '酷我音乐', 'mg' => '咪咕音乐'][$source] ?? $source;
    }

    private function size(array $musicInfo, string $quality): ?int
    {
        $value = $musicInfo['_types'][$quality]['size'] ?? null;
        return is_int($value) && $value > 0 ? $value : null;
    }
}

final class LxSearchInvalid extends \RuntimeException {}
final class LxSearchUnavailable extends \RuntimeException {}
