<?php

declare(strict_types=1);

namespace plugin\lx_music\app\application\Search;

use JsonException;
use Symfony\Component\Process\Process;
use Throwable;

/**
 * LxHelperSearchClient 调用 LX Music 插件包自带 Helper 的 external_search v12 协议。
 *
 * Helper 只接受固定五平台和搜索文本，不能接收 URL、Cookie 或浏览器请求头。本客户端再次绑定请求平台
 * 顺序并严格白名单化 LX musicInfo；平台 ID 只返回给搜索服务加密成 actor 租约，不进入公开 API、日志
 * 或错误消息。默认路径固定在本插件安装目录，禁止通过环境变量切换到主程序 Helper；每次调用使用独立
 * 进程和 45 秒硬超时，无数据库与文件副作用。
 */
final readonly class LxHelperSearchClient
{
    private const VERSION = 12;
    private const MAXIMUM_OUTPUT_BYTES = 4_194_304;
    private const SOURCES = ['netease', 'qq', 'kugou', 'kuwo', 'migu'];
    private const LX_SOURCES = ['wy', 'tx', 'kg', 'kw', 'mg'];

    public function __construct(private ?string $binaryPath = null)
    {
    }

    /**
     * 搜索固定平台并返回能够直接传给 LX API v2 musicUrl 请求的内部候选。
     *
     * 单平台 failed 被保留为状态，至少一个平台成功即可返回；全部失败时抛出稳定不可用错误。limit 是
     * 每个平台上限，调用方仍需在聚合、展开音质后施加最终页面上限。
     *
     * @return array{items:list<array<string,mixed>>,sources:list<array{key:string,available:bool,errorCode:?string}>}
     */
    public function search(string $query, int $limit): array
    {
        $path = $this->binary();
        $input = ['version' => self::VERSION, 'operation' => 'external_search', 'query' => $query,
            'limit' => max(1, min(50, $limit)), 'sources' => self::SOURCES];
        $process = new Process([$path]);
        $process->setInput(json_encode($input, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        $process->setTimeout(45.0);
        try {
            $process->run();
        } catch (Throwable $exception) {
            throw new LxHelperSearchUnavailable('LX_HELPER_TIMEOUT', previous: $exception);
        }
        $output = $process->getOutput();
        if (!$process->isSuccessful() || $output === '' || strlen($output) > self::MAXIMUM_OUTPUT_BYTES) {
            throw new LxHelperSearchUnavailable('LX_HELPER_FAILED');
        }
        try {
            $payload = json_decode($output, true, 48, JSON_THROW_ON_ERROR);
        } catch (JsonException $exception) {
            throw new LxHelperSearchUnavailable('LX_HELPER_PROTOCOL_INVALID', previous: $exception);
        }
        if (!is_array($payload) || array_is_list($payload) || array_keys($payload) !== ['version', 'results']
            || $payload['version'] !== self::VERSION || !is_array($payload['results'])
            || !array_is_list($payload['results']) || count($payload['results']) !== count(self::LX_SOURCES)) {
            throw new LxHelperSearchUnavailable('LX_HELPER_PROTOCOL_INVALID');
        }
        $items = [];
        $states = [];
        $successful = 0;
        foreach ($payload['results'] as $index => $result) {
            $expected = self::LX_SOURCES[$index];
            if (!is_array($result) || array_is_list($result) || ($result['source'] ?? null) !== $expected
                || !in_array($result['status'] ?? null, ['ok', 'failed'], true)
                || !is_array($result['items'] ?? null) || !array_is_list($result['items'])
                || count($result['items']) > $limit || array_diff(array_keys($result), ['source', 'status', 'items', 'errorCode']) !== []) {
                throw new LxHelperSearchUnavailable('LX_HELPER_PROTOCOL_INVALID');
            }
            $available = $result['status'] === 'ok';
            if ($available) $successful++;
            $states[] = ['key' => $expected, 'available' => $available,
                'errorCode' => $available ? null : 'SOURCE_REQUEST_FAILED'];
            if (!$available) continue;
            foreach ($result['items'] as $item) $items[] = $this->item($item, $expected);
        }
        if ($successful === 0) throw new LxHelperSearchUnavailable('LX_HELPER_ALL_SOURCES_FAILED');
        return ['items' => $items, 'sources' => $states];
    }

    /**
     * 返回当前 LX 插件包内唯一允许执行的 Helper。
     *
     * 默认路径由已加载 PHP 类反推当前插件根，并要求 realpath 与候选路径完全一致、文件不是符号链接且
     * 位于包内 bin 目录；这样升级或安装过程不会被环境变量、后台配置或链接替换成主程序外部二进制。
     * 测试注入路径仍允许使用真实普通可执行文件，但同样必须通过 realpath 和文件类型校验。
     */
    private function binary(): string
    {
        $packageRoot = realpath(dirname(__DIR__, 3));
        $candidate = $this->binaryPath ?? (is_string($packageRoot)
            ? $packageRoot . '/bin/lx-music-helper.bin'
            : base_path('plugin/lx-music/bin/lx-music-helper.bin'));
        $path = realpath($candidate);
        if (!is_string($path) || $path !== $candidate || is_link($candidate)
            || !is_file($path) || !is_executable($path)
            || ($this->binaryPath === null && (!is_string($packageRoot)
                || !str_starts_with($path, $packageRoot . '/bin/')))) {
            throw new LxHelperSearchUnavailable('LX_HELPER_UNAVAILABLE');
        }
        return $path;
    }

    /** @return array<string,mixed> */
    private function item(mixed $value, string $source): array
    {
        $allowed = ['title', 'artist', 'album', 'durationMs', 'artworkUrl', 'qualities', 'musicInfo'];
        if (!is_array($value) || array_is_list($value) || array_diff(array_keys($value), $allowed) !== []
            || !is_string($value['title'] ?? null) || trim($value['title']) === '' || mb_strlen($value['title']) > 500
            || !is_string($value['artist'] ?? null) || mb_strlen($value['artist']) > 500
            || !is_string($value['album'] ?? null) || mb_strlen($value['album']) > 500
            || (isset($value['durationMs']) && (!is_int($value['durationMs']) || $value['durationMs'] < 0 || $value['durationMs'] > 86_400_000))
            || !is_array($value['qualities'] ?? null) || !array_is_list($value['qualities'])
            || $value['qualities'] === [] || count($value['qualities']) > 4
            || !is_array($value['musicInfo'] ?? null) || array_is_list($value['musicInfo'])
            || ($value['musicInfo']['source'] ?? null) !== $source) {
            throw new LxHelperSearchUnavailable('LX_HELPER_ITEM_INVALID');
        }
        // 封面是搜索结果的可选增强，不是歌曲租约成立的前提。固定平台偶尔返回 HTTP 封面或其他不合规
        // 地址时，不能让一条候选的展示图片异常升级为整次五平台搜索失败；同时也不能把该地址带入租约，
        // 因为后续 Worker 只接受 HTTPS、无凭据、无片段的图片地址。这里将不安全值收窄为空值，音质、
        // musicInfo 和歌曲身份仍按同一协议继续校验，下载阶段不依赖该可选字段即可正常进行。
        $artworkUrl = $this->nullableArtworkUrl($value['artworkUrl'] ?? null)
            ? (is_string($value['artworkUrl'] ?? null) ? trim($value['artworkUrl']) : '') : '';
        $qualities = [];
        foreach ($value['qualities'] as $quality) {
            if (!is_string($quality) || !in_array($quality, ['128k', '320k', 'flac', 'flac24bit'], true)
                || in_array($quality, $qualities, true)) throw new LxHelperSearchUnavailable('LX_HELPER_ITEM_INVALID');
            $qualities[] = $quality;
        }
        $encoded = json_encode($value['musicInfo'], JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (strlen($encoded) > 32_768 || str_contains($encoded, '"url"')) {
            throw new LxHelperSearchUnavailable('LX_HELPER_ITEM_INVALID');
        }
        return ['source' => $source, 'title' => trim($value['title']), 'artist' => trim($value['artist']),
            'album' => trim($value['album']), 'durationMs' => $value['durationMs'] ?? null,
            'artworkUrl' => $artworkUrl,
            'qualities' => $qualities, 'musicInfo' => $value['musicInfo']];
    }

    /**
     * 校验 Helper 可选封面候选，只允许无凭据、无片段的有界 HTTPS URL。
     *
     * URL 仍不是可信图片：Worker 下载时会再次执行公开 DNS 固定、无重定向、MIME 和 8 MiB 上限。本层
     * 只阻止平台响应把任意协议、内嵌账号或异常长地址写入加密租约；空值表示没有搜索封面并正常通过。
     */
    private function nullableArtworkUrl(mixed $value): bool
    {
        if ($value === null || $value === '') return true;
        if (!is_string($value) || strlen($value) > 8192 || preg_match('/[\x00-\x20\x7F]/', $value) === 1) return false;
        $parts = parse_url($value);
        return is_array($parts) && strtolower((string) ($parts['scheme'] ?? '')) === 'https'
            && is_string($parts['host'] ?? null) && $parts['host'] !== ''
            && !isset($parts['user']) && !isset($parts['pass']) && !isset($parts['fragment']);
    }
}

final class LxHelperSearchUnavailable extends \RuntimeException
{
    public function __construct(public readonly string $errorCode, ?Throwable $previous = null)
    {
        parent::__construct($errorCode, previous: $previous);
    }
}
