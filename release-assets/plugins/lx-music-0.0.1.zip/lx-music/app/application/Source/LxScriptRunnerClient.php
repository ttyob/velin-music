<?php

declare(strict_types=1);

namespace plugin\lx_music\app\application\Source;

use JsonException;
use stdClass;
use Symfony\Component\Process\Process;
use Throwable;

/**
 * LxScriptRunnerClient 通过独立 Node 进程运行管理员配置的 LX API v2 脚本。
 *
 * PHP 只传入固定脚本 URL、Go Helper 生成的 musicInfo、白名单音质及该来源的可选专用 Token；runner
 * 不获得业务数据库、平台账号 Token 或目标媒体路径。来源 Token 仅经单次 stdin 传入并由 Node 限定到
 * 脚本同源请求。进程限制 96 MiB 堆、20 秒墙钟和 2 MiB 输出；错误只转为稳定 errorCode，不读取或记录
 * 可能包含脚本秘密的 stderr。runner 返回的 URL 仍须经过下载器的 DNS/HTTPS 安全策略。
 */
final readonly class LxScriptRunnerClient
{
    public function __construct(
        private ?string $nodePath = null,
        private ?string $runnerPath = null,
    ) {
    }

    /** @return array{name:string,description:string,version:string,author:string,homepage:string,sha256:string,sources:array<string,list<string>>,actions:array<string,list<string>>} */
    public function inspect(string $scriptUrl, ?string $sourceToken = null): array
    {
        $payload = $this->run(['version' => 1, 'operation' => 'init', 'scriptUrl' => $scriptUrl,
            'sourceToken' => $sourceToken]);
        return $this->inspectedPayload($payload);
    }

    /**
     * 并发初始化一组互相独立的 LX 脚本。
     *
     * 输入 key 来自已经校验的插件来源目录且必须唯一；所有 Node 子进程先启动再逐个收割，因此总耗时
     * 接近最慢脚本而不是各脚本耗时之和。单个脚本失败只写入对应 errors，不取消或污染其他结果；方法
     * 不缓存脚本正文或能力，调用方仍以本次返回的 SHA 绑定搜索租约，避免来源在线更新后的语义混用。
     *
     * sourceToken 是插件设置服务解密出的短生命周期副本，只进入对应子进程 stdin；本方法不记录或返回它。
     *
     * @param array<string,array{scriptUrl:string,sourceToken:?string}> $scripts
     * @return array{details:array<string,array{name:string,description:string,version:string,author:string,homepage:string,sha256:string,sources:array<string,list<string>>,actions:array<string,list<string>>}>,errors:array<string,string>}
     */
    public function inspectMany(array $scripts): array
    {
        if ($scripts === [] || count($scripts) > 10) {
            throw new LxScriptRunnerFailure('LX_RUNNER_INPUT_INVALID');
        }
        $processes = [];
        $errors = [];
        foreach ($scripts as $key => $script) {
            if (!is_string($key) || $key === '' || !is_array($script)
                || array_keys($script) !== ['scriptUrl', 'sourceToken']
                || !is_string($script['scriptUrl']) || $script['scriptUrl'] === ''
                || (!is_null($script['sourceToken']) && !is_string($script['sourceToken']))) {
                throw new LxScriptRunnerFailure('LX_RUNNER_INPUT_INVALID');
            }
            try {
                $process = $this->process(['version' => 1, 'operation' => 'init',
                    'scriptUrl' => $script['scriptUrl'], 'sourceToken' => $script['sourceToken']]);
                $process->start();
                $processes[$key] = $process;
            } catch (LxScriptRunnerFailure $failure) {
                $errors[$key] = $failure->errorCode;
            } catch (Throwable) {
                $errors[$key] = 'LX_SCRIPT_RUNNER_TIMEOUT';
            }
        }
        $details = [];
        foreach ($processes as $key => $process) {
            try {
                $process->wait();
                $details[$key] = $this->inspectedPayload($this->payload($process, 'init'));
            } catch (LxScriptRunnerFailure $failure) {
                $errors[$key] = $failure->errorCode;
            } catch (Throwable) {
                $errors[$key] = 'LX_SCRIPT_RUNNER_TIMEOUT';
            }
        }
        return ['details' => $details, 'errors' => $errors];
    }

    /** @return array{name:string,description:string,version:string,author:string,homepage:string,sha256:string,sources:array<string,list<string>>,actions:array<string,list<string>>} */
    private function inspectedPayload(array $payload): array
    {
        if (!is_array($payload['script'] ?? null) || !is_array($payload['sources'] ?? null)
            || (array_key_exists('actions', $payload) && !is_array($payload['actions']))) {
            throw new LxScriptRunnerFailure('LX_SCRIPT_PROTOCOL_INVALID');
        }
        $script = $payload['script'];
        foreach (['name', 'description', 'version', 'author', 'homepage', 'sha256'] as $field) {
            if (!is_string($script[$field] ?? null)) throw new LxScriptRunnerFailure('LX_SCRIPT_PROTOCOL_INVALID');
        }
        if (preg_match('/^[a-f0-9]{64}$/D', $script['sha256']) !== 1) {
            throw new LxScriptRunnerFailure('LX_SCRIPT_PROTOCOL_INVALID');
        }
        $sources = $this->sources($payload['sources']);
        $legacyActions = array_fill_keys(array_keys($sources), ['musicUrl']);
        return $script + ['sources' => $sources,
            'actions' => $this->actions($payload['actions'] ?? $legacyActions)];
    }

    /**
     * 请求脚本解析临时音乐地址。
     *
     * musicInfo 必须来自刚才通过 v12 Helper 协议验证并加密的租约，source 与对象内 source 必须一致。
     * 本方法不尝试下载 URL，也不接受自定义 action；脚本变化后的 SHA 会随结果返回供任务诊断。
     *
     * @return array{url:string,sha256:string}
     */
    public function resolve(
        string $scriptUrl,
        string $source,
        string $quality,
        array $musicInfo,
        ?string $sourceToken = null,
    ): array
    {
        if (($musicInfo['source'] ?? null) !== $source) throw new LxScriptRunnerFailure('LX_SCRIPT_MUSIC_INFO_INVALID');
        // LX Desktop 的旧版 DTO 明确把 typeUrl 定义为空对象。PHP 关联解码会把 `{}` 折叠成 `[]`，
        // 这里仅恢复这个无数据占位字段的 JSON 形状，不补造播放地址，也不修改平台 ID 或音质证据。
        if (($musicInfo['typeUrl'] ?? null) === []) $musicInfo['typeUrl'] = new stdClass();
        $payload = $this->run(['version' => 1, 'operation' => 'resolve', 'scriptUrl' => $scriptUrl,
            'sourceToken' => $sourceToken, 'source' => $source, 'quality' => $quality, 'musicInfo' => $musicInfo]);
        if (!is_string($payload['url'] ?? null) || !is_string($payload['sha256'] ?? null)
            || preg_match('/^https?:\/\//iD', $payload['url']) !== 1
            || preg_match('/^[a-f0-9]{64}$/D', $payload['sha256']) !== 1) {
            throw $this->protocolFailure('resolve', 'invalid_success_payload', $payload, [
                'urlType' => $this->valueType($payload, 'url'),
                'sha256Type' => $this->valueType($payload, 'sha256'),
            ]);
        }
        return ['url' => $payload['url'], 'sha256' => $payload['sha256']];
    }

    /**
     * 请求脚本获取可选歌词或封面地址。
     *
     * action 只允许 lyric|pic，且 musicInfo 必须来自同一 actor 租约并匹配平台 source。歌词限制为有效
     * UTF-8、无 NUL、50 KiB；封面只接受标准 HTTP(S) URL，真正下载时仍由 PHP 下载器执行 HTTPS、公开
     * DNS 固定、MIME 和大小复验。方法不写数据库或文件，失败由 Worker 记录为可选增强失败，不影响音频。
     *
     * @return array{action:string,sha256:string,lyric?:string,url?:string}
     */
    public function resolveMetadata(
        string $scriptUrl,
        string $source,
        string $action,
        array $musicInfo,
        ?string $sourceToken = null,
    ): array {
        if (!in_array($action, ['lyric', 'pic'], true) || ($musicInfo['source'] ?? null) !== $source) {
            throw new LxScriptRunnerFailure('LX_SCRIPT_MUSIC_INFO_INVALID');
        }
        if (($musicInfo['typeUrl'] ?? null) === []) $musicInfo['typeUrl'] = new stdClass();
        $payload = $this->run(['version' => 1, 'operation' => 'metadata', 'scriptUrl' => $scriptUrl,
            'sourceToken' => $sourceToken, 'source' => $source, 'action' => $action,
            'musicInfo' => $musicInfo]);
        if (($payload['action'] ?? null) !== $action || !is_string($payload['sha256'] ?? null)
            || preg_match('/^[a-f0-9]{64}$/D', $payload['sha256']) !== 1) {
            throw $this->protocolFailure('metadata', 'invalid_success_payload', $payload);
        }
        if ($action === 'lyric') {
            $lyric = $payload['lyric'] ?? null;
            if (!is_string($lyric) || trim($lyric) === '' || strlen($lyric) > 51_200
                || !mb_check_encoding($lyric, 'UTF-8') || str_contains($lyric, "\0")) {
                throw $this->protocolFailure('metadata', 'invalid_success_payload', $payload);
            }
            return ['action' => $action, 'lyric' => trim($lyric), 'sha256' => $payload['sha256']];
        }
        if (!is_string($payload['url'] ?? null) || preg_match('/^https?:\/\//iD', $payload['url']) !== 1
            || strlen($payload['url']) > 8192) {
            throw $this->protocolFailure('metadata', 'invalid_success_payload', $payload);
        }
        return ['action' => $action, 'url' => $payload['url'], 'sha256' => $payload['sha256']];
    }

    /** @return array<string,mixed> */
    private function run(array $input): array
    {
        $process = $this->process($input);
        try {
            $process->run();
        } catch (Throwable $exception) {
            throw new LxScriptRunnerFailure('LX_SCRIPT_RUNNER_TIMEOUT', [], $exception);
        }
        return $this->payload($process, (string) $input['operation']);
    }

    /**
     * 创建尚未启动的受限 Node 进程。
     *
     * 调用方只可传入本类构造的固定协议对象；stdin 使用 JSON 且进程没有数据库或媒体路径参数。返回进程
     * 可以立即 run，也可以由 inspectMany 先批量 start。创建失败没有外部副作用，已启动进程仍受 20 秒
     * Symfony 墙钟约束和 Node 96 MiB 堆限制。
     */
    private function process(array $input): Process
    {
        $node = $this->nodePath ?? (string) (getenv('VELIN_NODE_PATH') ?: '/usr/bin/node');
        $runner = $this->runnerPath ?? dirname(__DIR__, 3) . '/runtime/lx-runner.js';
        if ($node === '' || $node[0] !== DIRECTORY_SEPARATOR || !is_file($node) || !is_executable($node)
            || !is_file($runner) || is_link($runner)) throw new LxScriptRunnerFailure('LX_SCRIPT_RUNNER_UNAVAILABLE');
        $process = new Process([$node, '--max-old-space-size=96', '--disable-proto=delete', $runner]);
        $process->setInput(json_encode($input, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        $process->setTimeout(20.0);
        return $process;
    }

    /** @return array<string,mixed> */
    private function payload(Process $process, string $operation): array
    {
        $output = $process->getOutput();
        if ($output === '') throw $this->protocolFailure($operation, 'empty_output');
        if (strlen($output) > 2_097_152) {
            throw $this->protocolFailure($operation, 'output_too_large', null, ['responseBytes' => 2_097_152]);
        }
        try {
            $payload = json_decode($output, true, 32, JSON_THROW_ON_ERROR);
        } catch (JsonException $exception) {
            throw $this->protocolFailure($operation, 'invalid_json', null, ['responseBytes' => strlen($output)], $exception);
        }
        if (!is_array($payload) || array_is_list($payload) || ($payload['version'] ?? null) !== 1) {
            throw $this->protocolFailure($operation, 'invalid_envelope', is_array($payload) ? $payload : null);
        }
        if (!$process->isSuccessful()) {
            $code = is_string($payload['errorCode'] ?? null) && preg_match('/^LX_[A-Z0-9_]{1,80}$/D', $payload['errorCode']) === 1
                ? $payload['errorCode'] : 'LX_SCRIPT_RUNNER_FAILED';
            try {
                $diagnostic = $this->diagnostic($payload['diagnostic'] ?? null);
            } catch (LxScriptRunnerFailure $failure) {
                throw $this->protocolFailure($operation, 'invalid_error_diagnostic', $payload, [], $failure);
            }
            throw new LxScriptRunnerFailure($code, $diagnostic);
        }
        return $payload;
    }

    /**
     * 校验 runner 失败诊断的完整白名单。
     *
     * 诊断不允许自由文本，也没有 URL、Header 或正文槽位。任何未知字段、越界数字、异常内容类型或
     * JSON 字段名都会使整个 runner 响应降级为协议错误，避免受信边界外的脚本借诊断通道外带数据。
     *
     * @return array<string,mixed>
     */
    private function diagnostic(mixed $input): array
    {
        if ($input === null) return [];
        if (!is_array($input) || array_is_list($input)) throw new LxScriptRunnerFailure('LX_SCRIPT_PROTOCOL_INVALID');
        $allowed = ['operation', 'method', 'statusCode', 'contentType', 'responseBytes', 'bodyType',
            'topLevelKeys', 'scriptSha256', 'stage', 'upstreamCode', 'upstreamStatus',
            'upstreamError', 'upstreamMessage', 'upstreamText', 'runtimeMessage'];
        foreach (array_keys($input) as $key) {
            if (!is_string($key) || !in_array($key, $allowed, true)) {
                throw new LxScriptRunnerFailure('LX_SCRIPT_PROTOCOL_INVALID');
            }
        }
        if (!in_array($input['operation'] ?? null, ['init', 'resolve', 'metadata'], true)) {
            throw new LxScriptRunnerFailure('LX_SCRIPT_PROTOCOL_INVALID');
        }
        $hasMethod = array_key_exists('method', $input);
        $hasStage = array_key_exists('stage', $input);
        if ($hasMethod !== $hasStage || ($hasMethod
            && (!in_array($input['method'], ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD'], true)
                || !in_array($input['stage'], ['script_fetch', 'upstream_request'], true)))) {
            throw new LxScriptRunnerFailure('LX_SCRIPT_PROTOCOL_INVALID');
        }
        foreach (['statusCode' => 599, 'responseBytes' => 2_097_152] as $key => $maximum) {
            if (array_key_exists($key, $input)
                && (!is_int($input[$key]) || $input[$key] < 0 || $input[$key] > $maximum)) {
                throw new LxScriptRunnerFailure('LX_SCRIPT_PROTOCOL_INVALID');
            }
        }
        if (isset($input['contentType']) && (!is_string($input['contentType'])
            || strlen($input['contentType']) > 128
            || preg_match('/^[a-z0-9!#$&^_.+\/-]+$/D', $input['contentType']) !== 1)) {
            throw new LxScriptRunnerFailure('LX_SCRIPT_PROTOCOL_INVALID');
        }
        if (isset($input['bodyType']) && !in_array($input['bodyType'], [
            'empty', 'text', 'object', 'array', 'number', 'boolean', 'null',
        ], true)) throw new LxScriptRunnerFailure('LX_SCRIPT_PROTOCOL_INVALID');
        if (isset($input['scriptSha256']) && (!is_string($input['scriptSha256'])
            || preg_match('/^[a-f0-9]{64}$/D', $input['scriptSha256']) !== 1)) {
            throw new LxScriptRunnerFailure('LX_SCRIPT_PROTOCOL_INVALID');
        }
        if (isset($input['topLevelKeys'])) {
            if (!is_array($input['topLevelKeys']) || !array_is_list($input['topLevelKeys'])
                || count($input['topLevelKeys']) > 20) throw new LxScriptRunnerFailure('LX_SCRIPT_PROTOCOL_INVALID');
            foreach ($input['topLevelKeys'] as $key) {
                if (!is_string($key) || preg_match('/^[A-Za-z0-9_.-]{1,64}$/D', $key) !== 1) {
                    throw new LxScriptRunnerFailure('LX_SCRIPT_PROTOCOL_INVALID');
                }
            }
        }
        foreach (['upstreamCode' => 80, 'upstreamStatus' => 80, 'upstreamError' => 240,
            'upstreamMessage' => 500, 'upstreamText' => 500, 'runtimeMessage' => 500] as $key => $maximum) {
            if (!isset($input[$key])) continue;
            if (!is_string($input[$key]) || $input[$key] === '' || mb_strlen($input[$key], 'UTF-8') > $maximum
                || preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', $input[$key]) === 1
                || preg_match('/https?:\/\/|bearer\s|(?:token|cookie|signature|secret|api[_-]?key)\s*[=:]/iu',
                    $input[$key]) === 1) {
                throw new LxScriptRunnerFailure('LX_SCRIPT_PROTOCOL_INVALID');
            }
        }
        return $input;
    }

    /**
     * 构造不含输出正文的协议故障摘要。
     *
     * payload 只用于枚举顶层字段名，不读取或返回字段值；类型摘要只区分容器/标量类型。这样管理员能
     * 判断 runner 是空输出、非法 JSON、包络错误还是成功字段缺失，同时临时 URL 和错误正文仍不可见。
     *
     * @param array<string,mixed>|null $payload
     * @param array<string,mixed> $extra
     */
    private function protocolFailure(
        string $operation,
        string $issue,
        ?array $payload = null,
        array $extra = [],
        ?Throwable $previous = null,
    ): LxScriptRunnerFailure {
        $keys = $payload === null ? [] : array_values(array_slice(array_filter(array_keys($payload),
            static fn (mixed $key): bool => is_string($key)
                && preg_match('/^[A-Za-z0-9_.-]{1,64}$/D', $key) === 1), 0, 20));
        sort($keys);
        return new LxScriptRunnerFailure('LX_SCRIPT_PROTOCOL_INVALID', [
            'operation' => $operation,
            'stage' => 'runner_protocol',
            'protocolIssue' => $issue,
            ...($keys === [] ? [] : ['topLevelKeys' => $keys]),
            ...$extra,
        ], $previous);
    }

    /** @param array<string,mixed> $payload */
    private function valueType(array $payload, string $key): string
    {
        if (!array_key_exists($key, $payload)) return 'absent';
        $value = $payload[$key];
        if ($value === null) return 'null';
        if (is_array($value)) return array_is_list($value) ? 'array' : 'object';
        return match (gettype($value)) {
            'string' => 'string', 'integer', 'double' => 'number', 'boolean' => 'boolean', default => 'object',
        };
    }

    /** @return array<string,list<string>> */
    private function sources(array $input): array
    {
        $sources = [];
        foreach ($input as $key => $qualities) {
            if (!in_array($key, ['kw', 'kg', 'tx', 'wy', 'mg'], true) || !is_array($qualities) || !array_is_list($qualities)) {
                throw new LxScriptRunnerFailure('LX_SCRIPT_PROTOCOL_INVALID');
            }
            $sources[$key] = array_values(array_filter($qualities,
                static fn (mixed $quality): bool => is_string($quality)
                    && in_array($quality, ['128k', '320k', 'flac', 'flac24bit'], true)));
        }
        return $sources;
    }

    /** @return array<string,list<string>> */
    private function actions(array $input): array
    {
        $actions = [];
        foreach ($input as $key => $values) {
            if (!in_array($key, ['kw', 'kg', 'tx', 'wy', 'mg'], true)
                || !is_array($values) || !array_is_list($values)) {
                throw new LxScriptRunnerFailure('LX_SCRIPT_PROTOCOL_INVALID');
            }
            $actions[$key] = array_values(array_unique(array_filter($values,
                static fn (mixed $action): bool => is_string($action)
                    && in_array($action, ['musicUrl', 'lyric', 'pic'], true))));
        }
        return $actions;
    }
}

final class LxScriptRunnerFailure extends \RuntimeException
{
    /** @param array<string,mixed> $diagnostic 只含经过严格协议校验的脱敏响应结构摘要 */
    public function __construct(
        public readonly string $errorCode,
        public readonly array $diagnostic = [],
        ?Throwable $previous = null,
    )
    {
        parent::__construct($errorCode, previous: $previous);
    }
}
