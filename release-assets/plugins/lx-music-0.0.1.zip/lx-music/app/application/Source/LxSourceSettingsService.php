<?php

declare(strict_types=1);

namespace plugin\lx_music\app\application\Source;

use app\infrastructure\Audit\AuditLogger;
use InvalidArgumentException;
use JsonException;
use plugin\lx_music\app\application\Security\LxSecretCipher;
use stdClass;
use support\Db;

/**
 * LxSourceSettingsService 管理插件自己的解析来源目录。
 *
 * 来源只允许 LX API v2 脚本 URL。脚本是管理员明确启用的受信代码，仅由独立 Node runner 执行；可选
 * Token 以插件密文保存。每个来源的 cooldownMs 只控制下载任务启动解析的最小间隔，不改变搜索结果或
 * 任务失败语义。更新使用整份目录 CAS，保存事务不访问网络，审计只记录 key 和启用数量，不记录地址、
 * 令牌、脚本正文或响应。健康检测的运行时状态由 LxSourceHealthService 独立维护，本服务只负责把
 * 脱敏状态合并到公开目录投影，不在读取配置时触发网络检测。
 */
final readonly class LxSourceSettingsService
{
    private const SETTING_KEY = 'plugin.lx_music.sources';
    private const MAX_WEIGHT = 1000;
    private const MAX_COOLDOWN_MS = 600_000;

    public function __construct(
        private LxSecretCipher $cipher = new LxSecretCipher(),
        private AuditLogger $audit = new AuditLogger(),
    ) {
    }

    /** @return array{sources:list<array{key:string,name:string,type:string,enabled:bool,baseUrl:string,configured:bool,weight:int,successWeight:int,cooldownMs:int,health:array<string,mixed>}>,version:int,updatedAt:string} */
    public function snapshot(): array
    {
        $setting = $this->setting();
        $successWeights = (new LxSourceSuccessStatsService())->weights();
        $healthStates = (new LxSourceHealthService())->states(array_column($setting['sources'], 'key'));
        return [
            'sources' => array_map(static fn (array $source): array => [
                'key' => $source['key'], 'name' => $source['name'], 'enabled' => $source['enabled'],
                'type' => $source['type'], 'baseUrl' => $source['baseUrl'],
                'configured' => is_string($source['tokenCiphertext']) && $source['tokenCiphertext'] !== '',
                'weight' => $source['weight'], 'successWeight' => $successWeights[$source['key']] ?? 0,
                'cooldownMs' => $source['cooldownMs'],
                'health' => $healthStates[$source['key']] ?? [
                    'status' => 'unknown', 'available' => true, 'consecutiveFailures' => 0,
                    'lastErrorCode' => null, 'lastCheckedAtMs' => null, 'nextCheckAtMs' => null,
                ],
            ], $setting['sources']),
            'version' => $setting['version'], 'updatedAt' => $setting['updatedAt'],
        ];
    }

    /**
     * 返回搜索/解析使用的活动连接。
     *
     * 该内部投影包含令牌明文，只能在单次来源请求中使用；调用方必须在 finally 清理。指定 key 不存在、
     * 已关闭或密文损坏时失败关闭，不能回退到另一个来源猜测平台对象语义。
     *
     * @return array{key:string,name:string,type:string,baseUrl:string,token:?string,weight:int,cooldownMs:int}
     */
    public function connection(string $key): array
    {
        foreach ($this->setting()['sources'] as $source) {
            if ($source['key'] !== $key) continue;
            if (!$source['enabled']) throw new LxSourceUnavailable();
            return ['key' => $source['key'], 'name' => $source['name'], 'type' => $source['type'],
                'weight' => $source['weight'],
                'baseUrl' => $source['baseUrl'],
                'token' => is_string($source['tokenCiphertext'])
                    ? $this->cipher->decrypt('source_token', $source['tokenCiphertext']) : null,
                'cooldownMs' => $source['cooldownMs']];
        }
        throw new LxSourceUnavailable();
    }

    /** 返回已校验来源的下载解析冷却毫秒数，不解密 Token 也不访问来源网络。 */
    public function cooldownMs(string $key): int
    {
        foreach ($this->setting()['sources'] as $source) {
            if ($source['key'] === $key) return $source['cooldownMs'];
        }
        throw new LxSourceUnavailable();
    }

    /** @return list<array{key:string,name:string,type:string,baseUrl:string,token:?string,weight:int,cooldownMs:int}> */
    public function activeConnections(): array
    {
        $connections = [];
        foreach ($this->setting()['sources'] as $source) {
            if (!$source['enabled']) continue;
            $connections[] = ['key' => $source['key'], 'name' => $source['name'], 'type' => $source['type'],
                'weight' => $source['weight'],
                'baseUrl' => $source['baseUrl'],
                'token' => is_string($source['tokenCiphertext'])
                    ? $this->cipher->decrypt('source_token', $source['tokenCiphertext']) : null,
                'cooldownMs' => $source['cooldownMs']];
        }
        return $connections;
    }

    /**
     * 原子替换来源目录并按 key 保留未提交的新令牌。
     *
     * payload 固定为 `sources + expectedVersion`。最多 10 个来源，key 在插件内唯一；token 省略表示保留
     * 同 key 密文，空串清除。type 只能是 `lx_script`；脚本 URL 允许 HTTP 或 HTTPS 以及平台常用查询参数，
     * 且允许管理员明确配置回环、私网或公开地址。URL 仍不得包含认证信息和片段。任一项非法时整份目录不写入，
     * 并以参数错误返回而不是伪装成服务故障。这里的放宽仅作用于受信脚本及其上游请求，不改变最终音频下载器
     * 自己的地址安全策略。
     */
    public function update(array $payload, string $actorId, string $requestId): array
    {
        $payloadKeys = array_keys($payload);
        sort($payloadKeys);
        if ($payloadKeys !== ['expectedVersion', 'sources']
            || !is_array($payload['sources']) || !array_is_list($payload['sources'])
            || count($payload['sources']) > 10 || !is_int($payload['expectedVersion'])) {
            throw new LxSourceInvalid();
        }
        return Db::transaction(function () use ($payload, $actorId, $requestId): array {
            $before = $this->setting();
            if ($payload['expectedVersion'] !== $before['version']) throw new LxSourceConflict();
            $old = [];
            foreach ($before['sources'] as $source) $old[$source['key']] = $source;
            $sources = [];
            $keys = [];
            foreach ($payload['sources'] as $item) {
                if (!is_array($item) || array_is_list($item)) throw new LxSourceInvalid();
                $allowed = ['baseUrl', 'cooldownMs', 'enabled', 'key', 'name', 'token', 'type', 'weight'];
                if (array_diff(array_keys($item), $allowed) !== []
                    || !is_string($item['key'] ?? null) || !is_string($item['name'] ?? null)
                    || !is_bool($item['enabled'] ?? null) || !is_string($item['baseUrl'] ?? null)
                    || !is_string($item['type'] ?? null)
                    || $item['type'] !== 'lx_script') {
                    throw new LxSourceInvalid();
                }
                $key = trim($item['key']);
                $name = $this->text($item['name'], 80);
                if (preg_match('/^[a-z0-9][a-z0-9_-]{1,31}$/D', $key) !== 1 || $name === '' || isset($keys[$key])) {
                    throw new LxSourceInvalid();
                }
                $keys[$key] = true;
                $type = $item['type'];
                $baseUrl = $this->normalizeUrl($item['baseUrl'], $type);
                $weight = $item['weight'] ?? ($old[$key]['weight'] ?? 0);
                if (!is_int($weight) || $weight < 0 || $weight > self::MAX_WEIGHT) {
                    throw new LxSourceInvalid();
                }
                $cooldownMs = $item['cooldownMs'] ?? ($old[$key]['cooldownMs'] ?? 0);
                if (!is_int($cooldownMs) || $cooldownMs < 0 || $cooldownMs > self::MAX_COOLDOWN_MS) {
                    throw new LxSourceInvalid();
                }
                $ciphertext = $old[$key]['tokenCiphertext'] ?? null;
                if (array_key_exists('token', $item)) {
                    if (!is_string($item['token'])) throw new LxSourceInvalid();
                    $token = trim($item['token']);
                    if ($token === '') $ciphertext = null;
                    elseif (strlen($token) > 4096 || preg_match('/[\x00-\x1F\x7F]/', $token) === 1) {
                        throw new LxSourceInvalid();
                    } else {
                        $ciphertext = $this->cipher->encrypt('source_token', $token);
                        sodium_memzero($token);
                    }
                }
                $sources[] = ['key' => $key, 'name' => $name, 'type' => $type, 'enabled' => $item['enabled'],
                    'baseUrl' => $baseUrl, 'tokenCiphertext' => $ciphertext, 'weight' => $weight,
                    'cooldownMs' => $cooldownMs];
            }
            $changed = Db::table('system_settings')->where('setting_key', self::SETTING_KEY)
                ->where('version', $before['version'])->update([
                    'value_json' => json_encode(['sources' => $sources], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR),
                    'version' => Db::raw('version + 1'), 'updated_by' => $actorId,
                    'updated_at' => gmdate('Y-m-d\TH:i:s\Z'),
                ]);
            if ($changed !== 1) throw new LxSourceConflict();
            // 来源 key 是健康账本的身份；删除旧 key 的运行时行，避免同 key 后续重新添加时继承历史异常。
            $healthRows = Db::table('lx_music_source_health');
            if ($keys === []) $healthRows->delete();
            else $healthRows->whereNotIn('source_key', array_keys($keys))->delete();
            $this->audit->record($actorId, 'plugin.lx_music.sources.update', 'system_setting', self::SETTING_KEY,
                'success', $requestId, ['source_count' => count($sources),
                    'enabled_count' => count(array_filter($sources, static fn (array $source): bool => $source['enabled']))]);
            return $this->snapshot();
        });
    }

    /** @return array{sources:list<array{key:string,name:string,type:string,enabled:bool,baseUrl:string,tokenCiphertext:?string,weight:int,cooldownMs:int}>,version:int,updatedAt:string} */
    private function setting(): array
    {
        $row = Db::table('system_settings')->where('setting_key', self::SETTING_KEY)->first();
        if (!$row instanceof stdClass) throw new LxSourceUnavailable();
        try {
            $value = json_decode((string) $row->value_json, true, 16, JSON_THROW_ON_ERROR);
        } catch (JsonException) {
            throw new LxSourceUnavailable();
        }
        if (!is_array($value) || array_keys($value) !== ['sources'] || !is_array($value['sources'])
            || !array_is_list($value['sources']) || count($value['sources']) > 10) throw new LxSourceUnavailable();
        $sources = [];
        foreach ($value['sources'] as $source) {
            $allowedKeys = ['key', 'name', 'type', 'enabled', 'baseUrl', 'tokenCiphertext', 'weight', 'cooldownMs'];
            if (!is_array($source) || array_diff(array_keys($source), $allowedKeys) !== []
                || !is_string($source['key']) || !is_string($source['name']) || !is_bool($source['enabled'])
                || !is_string($source['type']) || $source['type'] !== 'lx_script'
                || !is_string($source['baseUrl'])
                || (!is_null($source['tokenCiphertext']) && !is_string($source['tokenCiphertext']))
                || (array_key_exists('weight', $source) && (!is_int($source['weight'])
                    || $source['weight'] < 0 || $source['weight'] > self::MAX_WEIGHT))
                || (array_key_exists('cooldownMs', $source) && (!is_int($source['cooldownMs'])
                    || $source['cooldownMs'] < 0 || $source['cooldownMs'] > self::MAX_COOLDOWN_MS))) {
                throw new LxSourceUnavailable();
            }
            $source['weight'] = (int) ($source['weight'] ?? 0);
            $source['cooldownMs'] = (int) ($source['cooldownMs'] ?? 0);
            try {
                $source['baseUrl'] = $this->normalizeUrl($source['baseUrl'], $source['type']);
            } catch (LxSourceInvalid) {
                throw new LxSourceUnavailable();
            }
            $sources[] = $source;
        }
        return ['sources' => $sources, 'version' => (int) $row->version, 'updatedAt' => (string) $row->updated_at];
    }

    private function normalizeUrl(string $input, string $type): string
    {
        $url = trim($input);
        if ($url === '' || strlen($url) > 2048 || preg_match('/[\x00-\x20\x7F]/', $url) === 1) {
            throw new LxSourceInvalid();
        }
        $parts = parse_url($url);
        $path = is_array($parts) ? (string) ($parts['path'] ?? '') : '';
        if (!is_array($parts) || !in_array(strtolower((string) ($parts['scheme'] ?? '')), ['http', 'https'], true)
            || !is_string($parts['host'] ?? null) || $parts['host'] === ''
            || isset($parts['user']) || isset($parts['pass']) || isset($parts['fragment'])
            || (isset($parts['port']) && ((int) $parts['port'] < 1 || (int) $parts['port'] > 65535))
            || preg_match('~(^|/)(?:\.|\.\.)(?:/|$)~', rawurldecode($path)) === 1) throw new LxSourceInvalid();
        return $url;
    }

    private function text(string $value, int $limit): string
    {
        $value = trim($value);
        if ($value === '' || !mb_check_encoding($value, 'UTF-8') || preg_match('/[\x00-\x1F\x7F]/u', $value) === 1) return '';
        return mb_substr($value, 0, $limit, 'UTF-8');
    }
}

final class LxSourceInvalid extends InvalidArgumentException {}
final class LxSourceConflict extends \RuntimeException {}
final class LxSourceUnavailable extends \RuntimeException {}
