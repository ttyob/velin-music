<?php

declare(strict_types=1);

namespace plugin\lx_music\app\application\Source;

use RuntimeException;
use support\Db;

/**
 * LxSourceSuccessStatsService 维护 LX 解析源已经完成入库的累计成功次数。
 *
 * 统计以管理员配置的稳定来源 key 为身份，不与脚本内部的网易、QQ 等平台 key 混用。成功次数只用于
 * 同一歌曲候选的次级排序和后台说明，不代表实时健康度或成功率；管理员显式权重始终优先。递增必须
 * 与任务 publishing -> succeeded 的状态 CAS 位于同一数据库事务，事务回滚时计数同步回滚，重复领取
 * 不会重复累计。SQLite 使用 insertOrIgnore 和原子表达式更新，未来迁移 MySQL 时需替换为等价 upsert。
 */
final readonly class LxSourceSuccessStatsService
{
    private const MAX_WEIGHT = 2_147_483_647;

    /** @return array<string,int> 返回解析源 key 到累计成功次数的只读映射。 */
    public function weights(): array
    {
        $weights = [];
        foreach (Db::table('lx_music_source_success_stats')->get(['source_key', 'success_weight']) as $row) {
            $weights[(string) $row->source_key] = max(0, (int) $row->success_weight);
        }
        return $weights;
    }

    /**
     * 为已经成功发布的任务原子增加一次来源成功计数。
     *
     * sourceKey 必须来自受校验的来源目录；方法不访问网络或文件。达到 SQLite 安全整数上限后保持饱和，
     * 表缺失或读取异常会抛错并让外层任务终态事务回滚，避免成功任务与排序统计产生不可解释的分叉。
     */
    public function incrementSuccess(string $sourceKey): int
    {
        if (preg_match('/^[a-z0-9][a-z0-9_-]{1,31}$/D', $sourceKey) !== 1) {
            throw new RuntimeException('LX_SOURCE_SUCCESS_KEY_INVALID');
        }
        $now = gmdate('Y-m-d\TH:i:s\Z');
        Db::table('lx_music_source_success_stats')->insertOrIgnore([
            'source_key' => $sourceKey, 'success_weight' => 0,
            'created_at' => $now, 'updated_at' => $now,
        ]);
        Db::table('lx_music_source_success_stats')->where('source_key', $sourceKey)
            ->where('success_weight', '<', self::MAX_WEIGHT)->update([
                'success_weight' => Db::raw('success_weight + 1'), 'updated_at' => $now,
            ]);
        $value = Db::table('lx_music_source_success_stats')->where('source_key', $sourceKey)
            ->value('success_weight');
        if (!is_int($value) && !is_numeric($value)) {
            throw new RuntimeException('LX_SOURCE_SUCCESS_WEIGHT_UNAVAILABLE');
        }
        return max(0, min(self::MAX_WEIGHT, (int) $value));
    }
}
