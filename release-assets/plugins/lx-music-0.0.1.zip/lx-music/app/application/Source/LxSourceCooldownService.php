<?php

declare(strict_types=1);

namespace plugin\lx_music\app\application\Source;

use Illuminate\Database\QueryException;
use RuntimeException;
use support\Db;

/**
 * LxSourceCooldownService 为第三方 LX 源保留跨任务的下载解析冷却窗口。
 *
 * 冷却状态独立于来源配置和下载任务，使用毫秒时间戳避免秒级数据库时间造成过早放行。服务只在
 * SQLite 短事务中读取或预约下一次允许时间，不访问网络、不修改任务状态；当前插件 Worker 是单消费者，
 * 但数据库条件更新仍防止未来出现并发消费者时重复放行。冷却未到期返回 false，调用方必须让任务保持排队，
 * 不能把等待当作失败或消耗自动重试次数。MySQL 迁移时需保留同样的主键条件更新语义。
 */
final readonly class LxSourceCooldownService
{
    private const TABLE = 'lx_music_source_cooldowns';

    /** 返回来源当前是否可以启动一次新的解析调用。 */
    public function isReady(string $sourceKey, ?int $nowMs = null): bool
    {
        $this->assertKey($sourceKey);
        $nowMs ??= $this->nowMs();
        $next = Db::table(self::TABLE)->where('source_key', $sourceKey)->value('next_allowed_at_ms');
        return $next === null || (int) $next <= $nowMs;
    }

    /**
     * 原子预约一次来源调用。
     *
     * cooldownMs 必须是已由来源配置服务验证过的 0-600000 毫秒。返回 false 表示已有任务预约了窗口，
     * 本次调用没有数据库副作用；返回 true 后调用方才可执行脚本。冷却值为 0 时不写状态，完整保留旧行为。
     */
    public function reserve(string $sourceKey, int $cooldownMs, ?int $nowMs = null): bool
    {
        $this->assertKey($sourceKey);
        if ($cooldownMs < 0 || $cooldownMs > 600_000) {
            throw new RuntimeException('LX_SOURCE_COOLDOWN_INVALID');
        }
        if ($cooldownMs === 0) return true;
        $nowMs ??= $this->nowMs();
        $nextAllowed = $nowMs + $cooldownMs;

        return Db::transaction(function () use ($sourceKey, $nowMs, $nextAllowed): bool {
            $changed = Db::table(self::TABLE)->where('source_key', $sourceKey)
                ->where('next_allowed_at_ms', '<=', $nowMs)
                ->update(['next_allowed_at_ms' => $nextAllowed, 'updated_at_ms' => $nowMs]);
            if ($changed === 1) return true;
            try {
                Db::table(self::TABLE)->insert([
                    'source_key' => $sourceKey,
                    'next_allowed_at_ms' => $nextAllowed,
                    'updated_at_ms' => $nowMs,
                ]);
                return true;
            } catch (QueryException $exception) {
                if (str_contains(strtolower($exception->getMessage()), 'unique')) return false;
                throw $exception;
            }
        });
    }

    private function assertKey(string $sourceKey): void
    {
        if (preg_match('/^[a-z0-9][a-z0-9_-]{1,31}$/D', $sourceKey) !== 1) {
            throw new RuntimeException('LX_SOURCE_COOLDOWN_KEY_INVALID');
        }
    }

    private function nowMs(): int
    {
        return (int) floor(microtime(true) * 1000);
    }
}
