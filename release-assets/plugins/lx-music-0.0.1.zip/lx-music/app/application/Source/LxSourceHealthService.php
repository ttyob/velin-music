<?php

declare(strict_types=1);

namespace plugin\lx_music\app\application\Source;

use Throwable;
use support\Db;

/**
 * LxSourceHealthService 负责第三方 LX 脚本来源的周期性可用性检测。
 *
 * 健康状态与来源配置、下载任务分开保存：配置变更不会抹掉可审计的失败计数，检测失败也不会把
 * 下载任务伪装成失败。检测实际执行 LX API v2 的 init 握手，因此同时覆盖脚本地址、Node runner
 * 和协议声明；令牌只进入一次 runner 进程，绝不进入状态表、响应或日志。正常来源每 5 分钟检测一次，
 * 连续 3 次失败后标记为 unhealthy，并改为每 10 分钟重试；一次成功即清零计数并恢复 healthy。
 * SQLite 当前只有一个资源插件消费者，但领取时仍使用条件 UPDATE，未来增加消费者时不会重复预约
 * 同一来源。网络调用始终在短事务外执行；领取进程若崩溃，预先推进的时间窗会在下一周期自动重试。
 */
final readonly class LxSourceHealthService
{
    private const TABLE = 'lx_music_source_health';
    private const NORMAL_INTERVAL_MS = 300_000;
    private const UNHEALTHY_INTERVAL_MS = 600_000;
    private const FAILURE_THRESHOLD = 3;

    public function __construct(
        private LxSourceSettingsService $settings = new LxSourceSettingsService(),
        private LxScriptRunnerClient $runner = new LxScriptRunnerClient(),
    ) {
    }

    /**
     * 批量领取并执行当前到期的来源检测。
     *
     * 每个来源最多在本次调用中检测一次；已启用来源首次出现时立即到期。多个来源先全部启动 runner
     * 再等待结果，避免一个慢源阻塞其他源的检测。返回 false 只表示当前没有到期源，不代表来源异常；
     * 单个来源的网络、脚本或协议错误会转成稳定错误码并继续处理其他来源。调用方不应依据返回值修改
     * 下载任务状态。
     */
    public function processDue(?int $nowMs = null): bool
    {
        $nowMs ??= $this->nowMs();
        $connections = $this->settings->activeConnections();
        if ($connections === []) return false;

        $due = $this->claimDue($connections, $nowMs);
        if ($due === []) return false;

        $scripts = [];
        foreach ($due as $connection) {
            $scripts[$connection['key']] = [
                'scriptUrl' => $connection['baseUrl'], 'sourceToken' => $connection['token'],
            ];
        }
        try {
            $result = $this->runner->inspectMany($scripts);
        } catch (Throwable) {
            $result = ['details' => [], 'errors' => array_fill_keys(array_keys($scripts), 'LX_SOURCE_UNAVAILABLE')];
        } finally {
            foreach ($scripts as &$script) {
                if (is_string($script['sourceToken']) && $script['sourceToken'] !== '') {
                    sodium_memzero($script['sourceToken']);
                }
            }
            unset($script);
            foreach ($due as &$connection) {
                if (is_string($connection['token'] ?? null) && $connection['token'] !== '') {
                    sodium_memzero($connection['token']);
                }
            }
            unset($connection);
        }

        foreach ($due as $connection) {
            $key = (string) $connection['key'];
            if (is_array($result['details'][$key] ?? null)) {
                $this->recordSuccess($key, $nowMs);
                continue;
            }
            $errorCode = is_string($result['errors'][$key] ?? null)
                ? $result['errors'][$key] : 'LX_SOURCE_UNAVAILABLE';
            $this->recordFailure($key, $errorCode, $nowMs);
        }
        return true;
    }

    /**
     * 在不解密 Token、不访问第三方网络的前提下判断是否有到期检测。
     *
     * 核心 Worker 用此方法决定是否暂时让健康检查优先于一个下载单步；没有到期源时只做本地配置和
     * 健康账本读取，保持原有下载吞吐。首次看到的启用来源没有健康行，按立即到期处理；异常来源的
     * 十分钟窗口由账本中的 nextCheckAtMs 决定。该方法没有数据库写副作用，实际领取仍必须再次执行
     * processDue 的条件 UPDATE。
     */
    public function hasDue(?int $nowMs = null): bool
    {
        $nowMs ??= $this->nowMs();
        $sources = $this->settings->snapshot()['sources'];
        $states = $this->states(array_values(array_map(static fn (array $source): string => $source['key'], $sources)));
        foreach ($sources as $source) {
            if (!$source['enabled']) continue;
            if (($states[$source['key']]['nextCheckAtMs'] ?? null) === null
                || $states[$source['key']]['nextCheckAtMs'] <= $nowMs) return true;
        }
        return false;
    }

    /** 返回来源当前的脱敏健康状态；未检测来源使用 unknown，不预设为异常。 */
    public function state(string $sourceKey): array
    {
        $states = $this->states([$sourceKey]);
        return $states[$sourceKey] ?? $this->defaultState();
    }

    /**
     * 返回来源 key 到健康状态的映射。
     *
     * sourceKeys 必须来自已校验的来源目录；缺少运行时行是合法的首次安装状态，不创建数据库副作用。
     * 时间字段使用毫秒 Unix 时间，避免 SQLite 文本时间比较和时区变化影响前端倒计时。
     *
     * @param list<string> $sourceKeys
     * @return array<string,array{status:string,available:bool,consecutiveFailures:int,lastErrorCode:?string,lastCheckedAtMs:?int,nextCheckAtMs:?int}>
     */
    public function states(array $sourceKeys): array
    {
        if ($sourceKeys === []) return [];
        $rows = Db::table(self::TABLE)->whereIn('source_key', $sourceKeys)->get();
        $states = array_fill_keys($sourceKeys, $this->defaultState());
        foreach ($rows as $row) {
            $status = in_array((string) $row->status, ['unknown', 'healthy', 'degraded', 'unhealthy'], true)
                ? (string) $row->status : 'unknown';
            $states[(string) $row->source_key] = [
                'status' => $status,
                'available' => $status !== 'unhealthy',
                'consecutiveFailures' => max(0, min(self::FAILURE_THRESHOLD, (int) $row->consecutive_failures)),
                'lastErrorCode' => is_string($row->last_error_code) ? $row->last_error_code : null,
                'lastCheckedAtMs' => $row->last_checked_at_ms === null ? null : (int) $row->last_checked_at_ms,
                'nextCheckAtMs' => (int) $row->next_check_at_ms,
            ];
        }
        return $states;
    }

    /** 过滤已达到三次连续失败阈值的来源，避免新搜索继续压垮明确异常的第三方源。 */
    public function filterAvailable(array $connections): array
    {
        $states = $this->states(array_values(array_map(static fn (array $connection): string => $connection['key'], $connections)));
        return array_values(array_filter($connections, static fn (array $connection): bool =>
            ($states[$connection['key']]['status'] ?? 'unknown') !== 'unhealthy'));
    }

    /** @param list<array{key:string,name:string,type:string,baseUrl:string,token:?string,weight:int,cooldownMs:int}> $connections */
    private function claimDue(array $connections, int $nowMs): array
    {
        return Db::transaction(function () use ($connections, $nowMs): array {
            foreach ($connections as $connection) {
                Db::table(self::TABLE)->insertOrIgnore([
                    'source_key' => $connection['key'], 'status' => 'unknown', 'consecutive_failures' => 0,
                    'last_error_code' => null, 'last_checked_at_ms' => null, 'next_check_at_ms' => $nowMs,
                    'updated_at_ms' => $nowMs,
                ]);
            }
            $due = [];
            foreach ($connections as $connection) {
                $changed = Db::table(self::TABLE)->where('source_key', $connection['key'])
                    ->where('next_check_at_ms', '<=', $nowMs)->update([
                        // 先预约一个正常窗口；检测成功或失败后会在事务外写入准确的下一次时间。
                        'next_check_at_ms' => $nowMs + self::NORMAL_INTERVAL_MS,
                        'updated_at_ms' => $nowMs,
                    ]);
                if ($changed === 1) $due[] = $connection;
            }
            return $due;
        });
    }

    private function recordSuccess(string $sourceKey, int $nowMs): void
    {
        Db::table(self::TABLE)->where('source_key', $sourceKey)->update([
            'status' => 'healthy', 'consecutive_failures' => 0, 'last_error_code' => null,
            'last_checked_at_ms' => $nowMs, 'next_check_at_ms' => $nowMs + self::NORMAL_INTERVAL_MS,
            'updated_at_ms' => $nowMs,
        ]);
    }

    private function recordFailure(string $sourceKey, string $errorCode, int $nowMs): void
    {
        $row = Db::table(self::TABLE)->where('source_key', $sourceKey)->first();
        if ($row === null) return;
        $failures = min(self::FAILURE_THRESHOLD, max(0, (int) $row->consecutive_failures) + 1);
        $status = $failures >= self::FAILURE_THRESHOLD ? 'unhealthy' : 'degraded';
        Db::table(self::TABLE)->where('source_key', $sourceKey)->update([
            'status' => $status, 'consecutive_failures' => $failures, 'last_error_code' => $this->errorCode($errorCode),
            'last_checked_at_ms' => $nowMs,
            'next_check_at_ms' => $nowMs + ($status === 'unhealthy' ? self::UNHEALTHY_INTERVAL_MS : self::NORMAL_INTERVAL_MS),
            'updated_at_ms' => $nowMs,
        ]);
    }

    private function errorCode(string $errorCode): string
    {
        return preg_match('/^LX_[A-Z0-9_]{1,80}$/D', $errorCode) === 1 ? $errorCode : 'LX_SOURCE_UNAVAILABLE';
    }

    /** @return array{status:string,available:bool,consecutiveFailures:int,lastErrorCode:?string,lastCheckedAtMs:?int,nextCheckAtMs:?int} */
    private function defaultState(): array
    {
        return ['status' => 'unknown', 'available' => true, 'consecutiveFailures' => 0,
            'lastErrorCode' => null, 'lastCheckedAtMs' => null, 'nextCheckAtMs' => null];
    }

    private function nowMs(): int
    {
        return (int) floor(microtime(true) * 1000);
    }
}
