<?php

declare(strict_types=1);

namespace plugin\lx_music\app\application\Download;

/**
 * 表示第三方 LX 源仍在配置的冷却窗口内。
 *
 * 这是 Worker 内部的调度信号，不是下载失败：调用方不得写入 failed、诊断错误或消耗 attempt，任务应
 * 保持 queued/resolving，下一轮再尝试。单独定义异常可让它在通用 Throwable 收口前被明确拦截。
 */
final class LxSourceCooldownDeferred extends \RuntimeException
{
}
