<?php

declare(strict_types=1);

namespace plugin\lx_music\app\application\Download;

use GuzzleHttp\Client;
use GuzzleHttp\ClientInterface;
use Throwable;

/**
 * LxDirectDownloader 把已解析的临时音频正文写入任务独占文件。
 *
 * 调用方必须先创建不存在的目标文件并提供插件设置的硬大小上限。搜索来源声明的 sizeBytes 只是平台
 * 估算值，只用于进度展示，不能缩小安全上限或在下载完成后拒绝有效音频。本类固定 DNS、关闭代理和
 * 重定向，仅接受 200 响应及音频或 octet-stream MIME；按流写入并逐块检查上限，失败删除精确目标。
 * 不实现跨进程 Range 续传，重试从零开始以避免临时 URL、ETag 或正文变化拼接出损坏媒体。
 */
final readonly class LxDirectDownloader
{
    public function __construct(
        private ?ClientInterface $http = null,
        private LxDownloadUrlPolicy $policy = new LxDownloadUrlPolicy(),
    ) {
    }

    /**
     * @param array{url:string,headers:array<string,string>,format:string,sizeBytes:?int} $resolved
     * @param callable(int,int):void|null $progress
     * @return int 实际写入字节数。
     */
    public function download(array $resolved, string $target, int $maximumBytes, ?callable $progress = null): int
    {
        $endpoint = $this->policy->resolve($resolved['url']);
        $declared = $resolved['sizeBytes'];
        $limit = $maximumBytes;
        if ($limit < 1 || file_exists($target) || is_link($target)) throw new LxDownloadFailure('LX_DOWNLOAD_STAGING_INVALID');
        $output = @fopen($target, 'x+b');
        if ($output === false) throw new LxDownloadFailure('LX_DOWNLOAD_STAGING_UNAVAILABLE');
        $completed = false;
        try {
            if (!defined('CURLOPT_RESOLVE')) throw new LxDownloadFailure('LX_DOWNLOAD_DNS_PINNING_UNAVAILABLE');
            $curl = [CURLOPT_RESOLVE => [$endpoint['host'] . ':443:' . $endpoint['ip']]];
            $response = ($this->http ?? new Client(['http_errors' => false]))->request('GET', $endpoint['url'], [
                'headers' => ['Accept' => 'audio/*,application/octet-stream'] + $resolved['headers'],
                'connect_timeout' => 5.0, 'timeout' => 3600.0, 'allow_redirects' => false,
                'proxy' => '', 'stream' => true, 'curl' => $curl,
            ]);
            if ($response->getStatusCode() !== 200) throw new LxDownloadFailure('LX_DOWNLOAD_HTTP_FAILED');
            $contentType = strtolower(trim(explode(';', $response->getHeaderLine('Content-Type'))[0]));
            if ($contentType !== '' && $contentType !== 'application/octet-stream'
                && !str_starts_with($contentType, 'audio/')) throw new LxDownloadFailure('LX_DOWNLOAD_MIME_INVALID');
            $headerLength = $response->getHeaderLine('Content-Length');
            if ($headerLength !== '' && (!ctype_digit($headerLength) || (int) $headerLength > $limit)) {
                throw new LxDownloadFailure('LX_DOWNLOAD_TOO_LARGE');
            }
            $body = $response->getBody();
            $written = 0;
            while (!$body->eof()) {
                $chunk = $body->read(65_536);
                if ($chunk === '') break;
                $written += strlen($chunk);
                if ($written > $limit || fwrite($output, $chunk) !== strlen($chunk)) {
                    throw new LxDownloadFailure($written > $limit ? 'LX_DOWNLOAD_TOO_LARGE' : 'LX_DOWNLOAD_WRITE_FAILED');
                }
                if ($progress !== null) $progress($written, is_int($declared) ? $declared : 0);
            }
            if ($written <= 0 || !fflush($output) || (function_exists('fsync') && !fsync($output))) {
                throw new LxDownloadFailure('LX_DOWNLOAD_EMPTY');
            }
            @chmod($target, 0600);
            $completed = true;
            return $written;
        } catch (LxDownloadFailure $failure) {
            throw $failure;
        } catch (Throwable) {
            throw new LxDownloadFailure('LX_DOWNLOAD_NETWORK_FAILED');
        } finally {
            fclose($output);
            if (!$completed) @unlink($target);
        }
    }

    /**
     * 下载已经由 LX 脚本或 Helper 提供的封面候选到当前任务目录。
     *
     * 候选地址仍执行与音频相同的 HTTPS、公网 DNS 固定和无重定向策略；正文只接受 JPEG/PNG，独立限制
     * 为 8 MiB 并流式写入新文件。失败删除精确目标且不影响音频 partial，调用方可把它记录为可选增强
     * 失败。返回 MIME 已归一化，后续标签写入器不能接受浏览器或脚本伪造的类型。
     *
     * @return array{bytes:int,mime:string}
     */
    public function downloadArtwork(string $url, string $target, int $maximumBytes = 8_388_608): array
    {
        $endpoint = $this->policy->resolve($url);
        if ($maximumBytes < 1 || file_exists($target) || is_link($target)) {
            throw new LxDownloadFailure('LX_DOWNLOAD_ARTWORK_STAGING_INVALID');
        }
        $output = @fopen($target, 'x+b');
        if ($output === false) throw new LxDownloadFailure('LX_DOWNLOAD_ARTWORK_STAGING_UNAVAILABLE');
        $completed = false;
        try {
            if (!defined('CURLOPT_RESOLVE')) throw new LxDownloadFailure('LX_DOWNLOAD_DNS_PINNING_UNAVAILABLE');
            $response = ($this->http ?? new Client(['http_errors' => false]))->request('GET', $endpoint['url'], [
                'headers' => ['Accept' => 'image/jpeg,image/jpg,image/png'],
                'connect_timeout' => 5.0, 'timeout' => 60.0, 'allow_redirects' => false,
                'proxy' => '', 'stream' => true,
                'curl' => [CURLOPT_RESOLVE => [$endpoint['host'] . ':443:' . $endpoint['ip']]],
            ]);
            if ($response->getStatusCode() !== 200) throw new LxDownloadFailure('LX_DOWNLOAD_ARTWORK_HTTP_FAILED');
            $mime = strtolower(trim(explode(';', $response->getHeaderLine('Content-Type'))[0]));
            $canonicalMime = match ($mime) {
                'image/jpeg', 'image/png' => $mime,
                'image/jpg' => 'image/jpeg',
                default => throw new LxDownloadFailure('LX_DOWNLOAD_ARTWORK_MIME_INVALID'),
            };
            $body = $response->getBody();
            $written = 0;
            while (!$body->eof()) {
                $chunk = $body->read(65_536);
                if ($chunk === '') break;
                $written += strlen($chunk);
                if ($written > $maximumBytes || fwrite($output, $chunk) !== strlen($chunk)) {
                    throw new LxDownloadFailure('LX_DOWNLOAD_ARTWORK_TOO_LARGE');
                }
            }
            if ($written <= 0 || !fflush($output) || (function_exists('fsync') && !fsync($output))) {
                throw new LxDownloadFailure('LX_DOWNLOAD_ARTWORK_EMPTY');
            }
            @chmod($target, 0600);
            $completed = true;
            return ['bytes' => $written, 'mime' => $canonicalMime];
        } catch (LxDownloadFailure $failure) {
            throw $failure;
        } catch (Throwable) {
            throw new LxDownloadFailure('LX_DOWNLOAD_ARTWORK_NETWORK_FAILED');
        } finally {
            fclose($output);
            if (!$completed) @unlink($target);
        }
    }
}
