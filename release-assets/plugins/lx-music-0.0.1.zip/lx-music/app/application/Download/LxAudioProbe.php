<?php

declare(strict_types=1);

namespace plugin\lx_music\app\application\Download;

use JsonException;
use Symfony\Component\Process\Process;

/**
 * LxAudioProbe 使用服务端固定 FFprobe 对完整暂存文件执行媒体准入。
 *
 * 输入必须是普通非链接文件，命令通过参数数组执行且不读取浏览器参数。探测最多 30 秒、输出最多由
 * FFprobe 精简为 stream/format JSON；至少一个音频流且时长大于零才允许发布。探测失败只删除后续由
 * Worker 精确识别的任务暂存，不会修改源服务或音乐库现有媒体。
 */
final readonly class LxAudioProbe
{
    public function assertAudio(string $path): void
    {
        if (!is_file($path) || is_link($path) || filesize($path) <= 0) throw new LxDownloadFailure('LX_DOWNLOAD_MEDIA_INVALID');
        $binary = realpath((string) (getenv('VELIN_FFPROBE_PATH') ?: base_path('bin/ffprobe')));
        if (!is_string($binary) || !is_executable($binary)) throw new LxDownloadFailure('LX_DOWNLOAD_PROBE_UNAVAILABLE');
        $process = new Process([$binary, '-v', 'error', '-show_entries',
            'stream=codec_type:format=duration', '-of', 'json', $path], base_path(),
            ['PATH' => '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'], null, 30);
        $process->run();
        if (!$process->isSuccessful() || strlen($process->getOutput()) > 262_144) {
            throw new LxDownloadFailure('LX_DOWNLOAD_MEDIA_INVALID');
        }
        try {
            $payload = json_decode($process->getOutput(), true, 16, JSON_THROW_ON_ERROR);
        } catch (JsonException) {
            throw new LxDownloadFailure('LX_DOWNLOAD_MEDIA_INVALID');
        }
        $streams = is_array($payload['streams'] ?? null) ? $payload['streams'] : [];
        $hasAudio = array_filter($streams, static fn (mixed $stream): bool =>
            is_array($stream) && ($stream['codec_type'] ?? null) === 'audio') !== [];
        $duration = (float) ($payload['format']['duration'] ?? 0);
        if (!$hasAudio || !is_finite($duration) || $duration <= 0 || $duration > 86_400) {
            throw new LxDownloadFailure('LX_DOWNLOAD_MEDIA_INVALID');
        }
    }
}
