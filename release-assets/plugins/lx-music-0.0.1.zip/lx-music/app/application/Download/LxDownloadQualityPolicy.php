<?php

declare(strict_types=1);

namespace plugin\lx_music\app\application\Download;

/**
 * LxDownloadQualityPolicy 定义 LX Music 可下载音质的稳定顺序。
 *
 * 来源协议只提供离散音质标识，不能用码率字符串或文件扩展名做字典序比较。该策略是搜索展示、任务
 * 创建与 Worker 执行的唯一判定边界，确保浏览器状态、旧租约和配置并发变化都不能绕过最低质量。
 * 未知音质一律视为不满足要求并失败关闭；本类不读取数据库，也不改变任务或媒体文件。
 */
final class LxDownloadQualityPolicy
{
    /** @var array<string,int> 数值越大表示来源质量越高；顺序属于插件协议，升级时必须补契约测试。 */
    private const RANKS = ['128k' => 0, '320k' => 1, 'flac' => 2, 'flac24' => 3];

    /** @return list<string> */
    public static function qualities(): array
    {
        return array_keys(self::RANKS);
    }

    /**
     * 判断来源音质是否达到管理员配置的最低门槛。
     *
     * 两个参数都必须是本插件协议中的规范值。未知值返回 false，调用方应拒绝创建或执行任务，不能把
     * 未识别格式当作最高质量放行。该比较没有 I/O 和副作用。
     */
    public static function accepts(string $sourceQuality, string $minimumQuality): bool
    {
        return isset(self::RANKS[$sourceQuality], self::RANKS[$minimumQuality])
            && self::RANKS[$sourceQuality] >= self::RANKS[$minimumQuality];
    }
}
