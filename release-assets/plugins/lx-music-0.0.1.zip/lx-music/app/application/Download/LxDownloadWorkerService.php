<?php

declare(strict_types=1);

namespace plugin\lx_music\app\application\Download;

use app\application\Scrape\AudioMetadataRewrite;
use app\application\Scrape\FfmpegAudioMetadataWriter;
use app\application\Scrape\ScrapeMetadataCandidate;
use app\application\Scrape\ScrapePipelineFailed;
use app\application\Scan\ScanJobService;
use app\application\ResourcePlugin\PluginMediaPublicationFailed;
use app\application\ResourcePlugin\PluginMediaPublicationService;
use app\infrastructure\Audit\AuditLogger;
use plugin\lx_music\app\application\Security\LxSecretCipher;
use plugin\lx_music\app\application\Source\LxScriptRunnerClient;
use plugin\lx_music\app\application\Source\LxScriptRunnerFailure;
use plugin\lx_music\app\application\Source\LxSourceCooldownService;
use plugin\lx_music\app\application\Source\LxSourceHealthService;
use plugin\lx_music\app\application\Source\LxSourceSettingsService;
use plugin\lx_music\app\application\Source\LxSourceSuccessStatsService;
use plugin\lx_music\app\application\Source\LxSourceUnavailable;
use RuntimeException;
use stdClass;
use support\Db;
use Throwable;

/**
 * LxDownloadWorkerService 驱动解析、直链下载、媒体校验、原子发布和增量扫描状态机。
 *
 * SQLite 单消费者每次最多领取一个任务。数据库只在领取和状态提交的短事务中写入；来源请求、DNS、
 * HTTP 正文、FFprobe 和文件 rename 全在事务外。失败最多重试三轮且每轮重新解析临时 URL；权限撤销、
 * 目标库失效、媒体伪装和路径异常立即终止。发布使用确定性任务后缀，崩溃后可以识别自己已发布的普通
 * 文件并继续提交数据库，不重复覆盖。成功媒体属于核心音乐库，插件卸载不会删除。已确认异常的来源
 * 只会延后 queued/resolving 任务；已经开始正文下载或发布的任务不再依赖来源探测，必须继续按原状态机
 * 收口，避免健康状态变化造成半成品媒体或错误终态。
 */
final readonly class LxDownloadWorkerService
{
    public function __construct(
        private LxSourceSettingsService $sources = new LxSourceSettingsService(),
        private LxScriptRunnerClient $scriptRunner = new LxScriptRunnerClient(),
        private LxSecretCipher $cipher = new LxSecretCipher(),
        private LxDirectDownloader $downloader = new LxDirectDownloader(),
        private LxDownloadStorage $storage = new LxDownloadStorage(),
        private PluginMediaPublicationService $publications = new PluginMediaPublicationService(),
        private LxAudioProbe $probe = new LxAudioProbe(),
        private FfmpegAudioMetadataWriter $metadataWriter = new FfmpegAudioMetadataWriter(),
        private LxSourceSuccessStatsService $stats = new LxSourceSuccessStatsService(),
        private ScanJobService $scans = new ScanJobService(),
        private AuditLogger $audit = new AuditLogger(),
        private LxDownloadDiagnosticLogService $diagnostics = new LxDownloadDiagnosticLogService(),
        private LxSourceCooldownService $cooldowns = new LxSourceCooldownService(),
        private LxSourceHealthService $health = new LxSourceHealthService(),
    ) {
    }

    /**
     * 处理一个最旧且已过来源冷却的活动任务。
     *
     * 同一第三方 LX 源处于冷却或已达到健康失败阈值时会跳过该任务继续查找其他来源，避免单个慢源或
     * 异常源阻塞整个插件队列。两种等待都不是错误，不写失败日志、不清理暂存、不增加 attempt；只有
     * 真正取得预约后才把 queued 任务领取为 resolving。无任务或所有候选都在等待时返回 false，核心
     * Worker 会在下一轮继续检查。
     */
    public function processNext(string $workerId): bool
    {
        $rows = Db::table('lx_music_download_jobs')->whereIn('status', [
            'queued', 'resolving', 'downloading',
        ])->orderByRaw("CASE status WHEN 'downloading' THEN 0 ELSE 1 END")
            ->orderBy('updated_at')->limit(50)->get();
        $row = null;
        foreach ($rows as $candidate) {
            if (in_array($candidate->status, ['queued', 'resolving'], true)) {
                if ($this->health->state((string) $candidate->source_key)['status'] === 'unhealthy') continue;
                try {
                    $cooldownMs = (new LxSourceSettingsService())->cooldownMs((string) $candidate->source_key);
                    if ($cooldownMs > 0 && !$this->cooldowns->isReady((string) $candidate->source_key)) continue;
                } catch (LxSourceUnavailable) {
                    // 配置失效必须交给原有失败收口，不能在筛选阶段吞掉来源错误。
                }
            }
            $row = $candidate;
            break;
        }
        if (!$row instanceof stdClass) return false;
        try {
            if (in_array($row->status, ['queued', 'resolving'], true)) $this->assertMinimumQuality($row);
            if (in_array($row->status, ['queued', 'resolving'], true)) $this->resolve($row, $workerId);
            elseif ($row->status === 'downloading') $this->download($row, $workerId);
        } catch (LxSourceCooldownDeferred) {
            return true;
        } catch (LxDownloadFailure $failure) {
            $this->handleFailure($row, $failure->errorCode, $failure->diagnostic, $failure->platformKey);
        } catch (LxSourceUnavailable) {
            // 来源可在任务排队后被管理员关闭或删除；这属于可识别的实时配置变化，不应伪装成未知 Worker 故障。
            $this->handleFailure($row, 'LX_SOURCE_UNAVAILABLE');
        } catch (Throwable) {
            $this->handleFailure($row, 'LX_DOWNLOAD_OPERATION_FAILED');
        }
        return true;
    }

    /**
     * 在独立媒体 Worker 中领取 publishing 任务并发布到目标库。
     *
     * 下载阶段只把完整音频和已写标签持久化为 publishing；这里用状态 CAS 取得唯一所有权，再执行
     * 核心发布器和扫描排队。发布耗时不会阻塞来源解析，多个 Worker 也不会对同一任务重复写文件。
     */
    public function processTranscodeNext(string $workerId): bool
    {
        /** @var stdClass|null $row */
        $row = Db::table('lx_music_download_jobs')->where('status', 'publishing')->whereNull('worker_id')->orderBy('updated_at')->first();
        if (!$row instanceof stdClass) return false;
        $now = gmdate('Y-m-d\TH:i:s\Z');
        $claimed = Db::table('lx_music_download_jobs')->where('id', (string) $row->id)->where('status', 'publishing')->whereNull('worker_id')
            ->update(['worker_id' => $workerId, 'heartbeat_at' => $now, 'updated_at' => $now]);
        if ($claimed !== 1) return false;
        try {
            $this->publish($row, $workerId);
        } catch (LxDownloadFailure $failure) {
            $this->handleFailure($row, $failure->errorCode, $failure->diagnostic, $failure->platformKey);
        } catch (Throwable) {
            $this->handleFailure($row, 'LX_DOWNLOAD_OPERATION_FAILED');
        }
        return true;
    }

    /**
     * 在任何来源解析或正文下载前复验当前最低质量。
     *
     * 管理员可能在任务排队后提高门槛，因此搜索时的 `downloadable` 和创建时校验都不是最终授权。只有
     * 尚未完成地址解析的任务应用新门槛；已经进入 downloading/publishing 的历史任务继续完成，避免在
     * 有文件副作用后改变合同。拒绝使用稳定非重试错误，不创建或清理媒体文件。
     */
    private function assertMinimumQuality(stdClass $row): void
    {
        $settings = (new LxDownloadSettingsService())->snapshot();
        if (!LxDownloadQualityPolicy::accepts((string) $row->quality, $settings['minimumQuality'])) {
            throw new LxDownloadFailure('LX_DOWNLOAD_QUALITY_BELOW_MINIMUM');
        }
    }

    /**
     * 领取 queued 任务并从原解析来源重新取得短期下载上下文。
     *
     * v2 租约密文是用途标记 JSON，包含平台 source 和 Helper 产生的完整 musicInfo。脚本只返回 URL；
     * format 和预期大小来自搜索租约，后续下载器继续执行 HTTPS、DNS 固定、正文上限和 FFprobe 校验。
     * 租约与来源 Token 的明文只在本调用栈存活；包括来源配置损坏在内的所有失败都必须在 finally 清零。
     */
    private function resolve(stdClass $row, string $workerId): void
    {
        $reference = $this->cipher->decrypt('search_reference', (string) $row->reference_ciphertext);
        $connection = null;
        $platformKey = null;
        $successDetails = [];
        try {
            // 先读来源配置并预约，再解密 Token；停用来源仍需先领取任务，保持原有失败与 attempt 语义。
            $cooldownMs = (new LxSourceSettingsService())->cooldownMs((string) $row->source_key);
            if (!$this->cooldowns->reserve((string) $row->source_key, $cooldownMs)) {
                throw new LxSourceCooldownDeferred();
            }
            $now = gmdate('Y-m-d\TH:i:s\Z');
            if ($row->status === 'queued') {
                $changed = Db::table('lx_music_download_jobs')->where('id', (string) $row->id)->where('status', 'queued')->update([
                    'status' => 'resolving', 'worker_id' => $workerId, 'attempt' => Db::raw('attempt + 1'),
                    'started_at' => $row->started_at ?? $now, 'heartbeat_at' => $now, 'error_code' => null, 'updated_at' => $now,
                ]);
                if ($changed !== 1) return;
                $this->diagnostics->record((string) $row->id, (string) $row->source_key, null,
                    (string) $row->quality, 'info', 'LX_DOWNLOAD_RESOLVING', 'resolve', [
                        'attempt' => max(0, min(10, (int) $row->attempt + 1)),
                    ], (string) $row->request_id);
            }
            $connection = $this->sources->connection((string) $row->source_key);
            try {
                $context = json_decode($reference, true, 32, JSON_THROW_ON_ERROR);
                if (!is_array($context) || !is_string($context['kind'] ?? null)) {
                    throw new \JsonException('legacy reference');
                }
                if ($context['kind'] !== 'lx_script' || $connection['type'] !== 'lx_script'
                    || !is_string($context['source'] ?? null) || !is_array($context['musicInfo'] ?? null)) {
                    throw new LxDownloadFailure('LX_DOWNLOAD_CONTEXT_INVALID');
                }
                $quality = (string) $row->quality === 'flac24' ? 'flac24bit' : (string) $row->quality;
                $script = $this->scriptRunner->resolve($connection['baseUrl'], $context['source'], $quality,
                    $context['musicInfo'], $connection['token']);
                $platformKey = $context['source'];
                $successDetails['scriptSha256'] = $script['sha256'];
                $metadata = $this->basicMetadata($row);
                $assetActions = is_array($context['assetActions'] ?? null) ? $context['assetActions'] : [];
                $artworkUrl = is_string($context['artworkUrl'] ?? null) ? trim($context['artworkUrl']) : '';
                if (in_array('lyric', $assetActions, true)) {
                    try {
                        $asset = $this->scriptRunner->resolveMetadata($connection['baseUrl'], $context['source'],
                            'lyric', $context['musicInfo'], $connection['token']);
                        $metadata['lyrics'] = ['available' => true, 'embedded' => false,
                            'kind' => 'line', 'content' => $asset['lyric']];
                    } catch (LxScriptRunnerFailure $failure) {
                        $this->recordOptionalMetadataFailure($row, 'lyrics', $failure, 'resolve');
                    }
                }
                if (in_array('pic', $assetActions, true)) {
                    try {
                        $asset = $this->scriptRunner->resolveMetadata($connection['baseUrl'], $context['source'],
                            'pic', $context['musicInfo'], $connection['token']);
                        $artworkUrl = (string) $asset['url'];
                    } catch (LxScriptRunnerFailure $failure) {
                        $this->recordOptionalMetadataFailure($row, 'artwork', $failure, 'resolve');
                    }
                }
                $metadata['artwork']['available'] = $artworkUrl !== '';
                $resolved = ['url' => $script['url'], 'headers' => [], 'format' => (string) $row->format,
                    'sizeBytes' => $row->expected_size_bytes === null ? null : (int) $row->expected_size_bytes,
                    'artworkUrl' => $artworkUrl === '' ? null : $artworkUrl, 'metadata' => $metadata];
            } catch (\JsonException) {
                throw new LxDownloadFailure('LX_DOWNLOAD_CONTEXT_INVALID');
            } catch (LxScriptRunnerFailure $failure) {
                throw new LxDownloadFailure($failure->errorCode, $failure->diagnostic,
                    is_string($context['source'] ?? null) ? $context['source'] : null);
            }
        } finally {
            sodium_memzero($reference);
            if (is_array($connection) && is_string($connection['token'] ?? null) && $connection['token'] !== '') {
                sodium_memzero($connection['token']);
            }
        }
        $payload = json_encode($resolved, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
        Db::transaction(function () use ($row, $payload, $resolved, $platformKey, $successDetails): void {
            $changed = Db::table('lx_music_download_jobs')->where('id', (string) $row->id)
                ->where('status', 'resolving')->update([
                    'status' => 'downloading',
                    'resolved_ciphertext' => $this->cipher->encrypt('resolved_download', $payload),
                    'format' => $resolved['format'],
                    'metadata_json' => json_encode($resolved['metadata'], JSON_THROW_ON_ERROR
                        | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                    'total_bytes' => $resolved['sizeBytes'] ?? $row->expected_size_bytes ?? 0,
                    'worker_id' => null, 'heartbeat_at' => null, 'error_code' => null,
                    'updated_at' => gmdate('Y-m-d\TH:i:s\Z'),
                ]);
            if ($changed !== 1) return;
            $this->diagnostics->record((string) $row->id, (string) $row->source_key, $platformKey,
                (string) $row->quality, 'info', 'LX_DOWNLOAD_RESOLVED', 'resolve', $successDetails,
                (string) $row->request_id);
        });
        sodium_memzero($payload);
    }

    /** 下载完整正文到任务暂存，FFprobe 通过后进入 publishing；回调只节流更新安全进度数字。 */
    private function download(stdClass $row, string $workerId): void
    {
        $this->assertLiveAuthorization((string) $row->requested_by, (string) $row->library_id);
        $paths = $this->storage->prepare((string) $row->id);
        $plain = $this->cipher->decrypt('resolved_download', (string) $row->resolved_ciphertext);
        try {
            $resolved = json_decode($plain, true, 16, JSON_THROW_ON_ERROR);
        } finally {
            sodium_memzero($plain);
        }
        if (!is_array($resolved)) throw new LxDownloadFailure('LX_DOWNLOAD_CONTEXT_INVALID');
        $settings = (new LxDownloadSettingsService())->snapshot();
        $lastUpdate = 0;
        $this->downloader->download($resolved, $paths['partial'], $settings['maximumBytes'],
            function (int $downloaded, int $total) use ($row, &$lastUpdate): void {
                if ($downloaded - $lastUpdate < 1_048_576 && ($total <= 0 || $downloaded < $total)) return;
                $lastUpdate = $downloaded;
                $basis = $total > 0 ? min(9900, (int) floor($downloaded * 10_000 / $total)) : 0;
                Db::table('lx_music_download_jobs')->where('id', (string) $row->id)->where('status', 'downloading')->update([
                    'downloaded_bytes' => $downloaded, 'total_bytes' => max($total, 0),
                    'progress_basis_points' => $basis, 'heartbeat_at' => gmdate('Y-m-d\TH:i:s\Z'),
                    'updated_at' => gmdate('Y-m-d\TH:i:s\Z'),
                ]);
            });
        $this->probe->assertAudio($paths['partial']);
        $metadata = $this->decodeMetadata((string) ($row->metadata_json ?? '{}'));
        if ($metadata === []) $metadata = $this->basicMetadata($row);
        $metadata['written'] = $this->writeDownloadMetadata(
            $paths['partial'], (string) $row->id, $metadata, (string) $row->format,
        );
        $artworkUrl = is_string($resolved['artworkUrl'] ?? null) ? trim($resolved['artworkUrl']) : '';
        if ($artworkUrl !== '') {
            try {
                $artworkPath = $paths['directory'] . DIRECTORY_SEPARATOR . 'artwork.jpg';
                $downloadedArtwork = $this->downloader->downloadArtwork($artworkUrl, $artworkPath);
                $this->withContainerAudioPath($paths['partial'], (string) $row->format,
                    function (string $audioPath) use ($artworkPath, $downloadedArtwork, $row): void {
                        $rewrite = $this->metadataWriter->rewriteArtwork($audioPath, $artworkPath,
                            $downloadedArtwork['mime'], (string) $row->id);
                        $this->metadataWriter->commit($rewrite);
                    });
                $metadata['artwork'] = ['available' => true, 'embedded' => true,
                    'mimeType' => $downloadedArtwork['mime']];
            } catch (Throwable $failure) {
                $metadata['artwork'] = ['available' => true, 'embedded' => false, 'mimeType' => null];
                $this->recordOptionalMetadataFailure($row, 'artwork', $failure);
            }
        }
        $lyrics = is_array($metadata['lyrics'] ?? null) ? $metadata['lyrics'] : [];
        $lyrics['embedded'] = false;
        if (is_string($lyrics['content'] ?? null) && trim($lyrics['content']) !== '') {
            try {
                $this->withContainerAudioPath($paths['partial'], (string) $row->format,
                    function (string $audioPath) use ($lyrics, $row): void {
                        $rewrite = $this->metadataWriter->rewriteLyrics($audioPath, (string) $lyrics['content'],
                            'line', (string) $row->id);
                        $this->metadataWriter->commit($rewrite);
                    });
                $lyrics['embedded'] = true;
            } catch (Throwable $failure) {
                $this->recordOptionalMetadataFailure($row, 'lyrics', $failure);
            }
        }
        $metadata['lyrics'] = $lyrics;
        $metadataJson = json_encode($metadata, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $finalBytes = filesize($paths['partial']);
        if (!is_int($finalBytes) || $finalBytes <= 0) throw new LxDownloadFailure('LX_DOWNLOAD_METADATA_WRITE_FAILED');
        $metadataLog = $this->metadataLogDetails($metadata);
        Db::transaction(function () use ($row, $finalBytes, $metadataJson, $metadataLog): void {
            $changed = Db::table('lx_music_download_jobs')->where('id', (string) $row->id)
                ->where('status', 'downloading')->update([
                    'status' => 'publishing', 'downloaded_bytes' => $finalBytes, 'total_bytes' => $finalBytes,
                    'metadata_json' => $metadataJson,
                    'progress_basis_points' => 9900,
                    // publishing 交给独立 Worker，下载进程不保留租约，避免交接时被旧 worker_id 阻塞。
                    'worker_id' => null, 'heartbeat_at' => null, 'updated_at' => gmdate('Y-m-d\TH:i:s\Z'),
                ]);
            if ($changed !== 1) return;
            $this->diagnostics->record((string) $row->id, (string) $row->source_key, null,
                (string) $row->quality, 'info', 'LX_DOWNLOAD_METADATA_WRITTEN', 'download', $metadataLog,
                (string) $row->request_id);
            $this->diagnostics->record((string) $row->id, (string) $row->source_key, null,
                (string) $row->quality, 'info', 'LX_DOWNLOAD_DOWNLOADED', 'download', [
                    'downloadedBytes' => $finalBytes,
                ], (string) $row->request_id);
        });
    }

    /**
     * 在任务暂存区写入下载租约确认的标题、艺人和专辑标签。
     *
     * FFmpeg 依赖真实扩展名选择容器，因此临时把唯一 partial 改名为白名单格式，写入器使用同目录备份、
     * 无重编码重封装并复验媒体，成功后恢复存储层固定文件名。任何错误都会回滚写入并恢复 partial；若
     * 无法恢复则任务失败且禁止发布。这里只使用任务快照，不从文件名或 musicInfo 猜测额外字段。
     */
    private function writeDownloadMetadata(string $partial, string $jobId, array $metadata, string $format): bool
    {
        if (!in_array($format, ['mp3', 'flac', 'm4a', 'aac', 'ogg', 'opus', 'wav'], true)) {
            throw new LxDownloadFailure('LX_DOWNLOAD_METADATA_CONTAINER_UNSUPPORTED');
        }
        if (!is_string($metadata['title'] ?? null) || trim($metadata['title']) === ''
            || !is_array($metadata['artists'] ?? null) || $metadata['artists'] === []) {
            return false;
        }
        $tagPath = dirname($partial) . DIRECTORY_SEPARATOR . 'audio-tag.' . $format;
        if (file_exists($tagPath) || is_link($tagPath) || !rename($partial, $tagPath)) {
            throw new LxDownloadFailure('LX_DOWNLOAD_METADATA_STAGING_FAILED');
        }
        $rewrite = null;
        try {
            $candidate = new ScrapeMetadataCandidate([
                'title' => (string) ($metadata['title'] ?? ''),
                'artists' => is_array($metadata['artists'] ?? null) ? $metadata['artists'] : [],
                'albumArtists' => is_array($metadata['albumArtists'] ?? null) ? $metadata['albumArtists'] : [],
                'albumTitle' => (string) ($metadata['albumTitle'] ?? ''),
                'trackNumber' => null, 'trackTotal' => null, 'discNumber' => null, 'discTotal' => null,
                'genres' => [], 'releaseDate' => null, 'releaseYear' => null, 'composer' => null,
                'isrc' => null, 'musicbrainzTrackId' => null, 'musicbrainzArtistId' => null,
                'musicbrainzReleaseId' => null, 'musicbrainzReleaseGroupId' => null, 'durationMs' => null,
            ], 100, 'lx-music-download', ['download_task_metadata']);
            $rewrite = $this->metadataWriter->rewrite($tagPath, $candidate, $jobId);
            if (!rename($tagPath, $partial)) throw new LxDownloadFailure('LX_DOWNLOAD_METADATA_STAGING_FAILED');
            $this->metadataWriter->commit($rewrite);
            return true;
        } catch (Throwable) {
            if ($rewrite instanceof AudioMetadataRewrite) $this->metadataWriter->rollback($rewrite);
            if (is_file($tagPath) && !file_exists($partial)) @rename($tagPath, $partial);
            throw new LxDownloadFailure('LX_DOWNLOAD_METADATA_WRITE_FAILED');
        }
    }

    /**
     * 以真实容器扩展执行一次封面或歌词重封装，并恢复唯一 partial 文件名。
     *
     * 操作始终限制在当前任务目录；回调失败先恢复 partial 再原样抛出，允许调用方把可选增强降级处理。
     * 如果文件身份、格式或恢复步骤异常则失败关闭，绝不能继续发布未知容器。
     *
     * @param callable(string):void $operation
     */
    private function withContainerAudioPath(string $partial, string $format, callable $operation): void
    {
        if (!in_array($format, ['mp3', 'flac', 'm4a', 'aac', 'ogg', 'opus', 'wav'], true)
            || !is_file($partial) || is_link($partial)) {
            throw new LxDownloadFailure('LX_DOWNLOAD_METADATA_CONTAINER_UNSUPPORTED');
        }
        $containerPath = dirname($partial) . DIRECTORY_SEPARATOR . 'audio-embedded.' . $format;
        if (file_exists($containerPath) || is_link($containerPath) || !rename($partial, $containerPath)) {
            throw new LxDownloadFailure('LX_DOWNLOAD_METADATA_STAGING_FAILED');
        }
        $failure = null;
        try {
            $operation($containerPath);
        } catch (Throwable $exception) {
            $failure = $exception;
        }
        if (file_exists($partial) || is_link($partial) || !is_file($containerPath) || is_link($containerPath)
            || !rename($containerPath, $partial)) {
            throw new LxDownloadFailure('LX_DOWNLOAD_METADATA_STAGING_FAILED');
        }
        if ($failure instanceof Throwable) throw $failure;
    }

    /**
     * 记录歌词或封面的可选获取/嵌入失败，不保存 URL、歌词正文、路径或异常消息。
     *
     * 可选增强失败不改变音频任务成功语义；日志写入本身失败也不能反向丢弃已验证音频。failureCode 只
     * 接受代码自身产生的稳定 LX 错误，未知异常统一压缩，避免第三方文本进入诊断表。stage 只能是
     * resolve 或 download，分别表示脚本获取和音频嵌入，调用方不能把两种故障混在同一运行阶段。
     */
    private function recordOptionalMetadataFailure(
        stdClass $row,
        string $resource,
        Throwable $failure,
        string $stage = 'download',
    ): void
    {
        if (!in_array($stage, ['resolve', 'download'], true)) {
            throw new \LogicException('LX_DOWNLOAD_METADATA_STAGE_INVALID');
        }
        $eventCode = match ($resource) {
            'artwork' => 'LX_DOWNLOAD_ARTWORK_EMBED_FAILED',
            'lyrics' => 'LX_DOWNLOAD_LYRICS_EMBED_FAILED',
            default => throw new \LogicException('LX_DOWNLOAD_METADATA_RESOURCE_INVALID'),
        };
        $failureCode = match (true) {
            $failure instanceof LxDownloadFailure => $failure->errorCode,
            $failure instanceof LxScriptRunnerFailure => $failure->errorCode,
            $failure instanceof ScrapePipelineFailed => $failure->errorCode,
            default => 'LX_DOWNLOAD_METADATA_EMBED_FAILED',
        };
        try {
            $this->diagnostics->record((string) $row->id, (string) $row->source_key, null,
                (string) $row->quality, 'warning', $eventCode, $stage, [
                    'failureCode' => $failureCode,
                ], (string) $row->request_id);
        } catch (Throwable) {
            // 可选增强诊断不属于媒体发布事务，记录失败不能扩大为下载失败。
        }
    }

    /** @return array<string,mixed> */
    private function basicMetadata(stdClass $row): array
    {
        $artist = trim((string) $row->artist);
        return [
            'schemaVersion' => 1, 'title' => trim((string) $row->title),
            'artists' => $artist === '' ? [] : [$artist], 'albumTitle' => trim((string) $row->album),
            'albumArtists' => $artist === '' ? [] : [$artist], 'written' => false,
            'artwork' => ['available' => false, 'embedded' => false, 'mimeType' => null],
            'lyrics' => ['available' => false, 'embedded' => false, 'kind' => null, 'content' => null],
        ];
    }

    /** @return array<string,mixed> */
    private function decodeMetadata(string $json): array
    {
        try {
            $decoded = json_decode($json, true, 24, JSON_THROW_ON_ERROR);
            return is_array($decoded) && ($decoded['schemaVersion'] ?? null) === 1 ? $decoded : [];
        } catch (\JsonException) {
            return [];
        }
    }

    /**
     * 投影最终写入结果供管理员核验；歌词正文、封面 URL 和平台引用没有日志字段。
     *
     * @return array<string,mixed>
     */
    private function metadataLogDetails(array $metadata): array
    {
        $tags = [];
        if (is_string($metadata['title'] ?? null) && trim($metadata['title']) !== '') {
            $tags['title'] = trim($metadata['title']);
        }
        foreach (['artists', 'albumArtists'] as $field) {
            if (is_array($metadata[$field] ?? null) && $metadata[$field] !== []) $tags[$field] = $metadata[$field];
        }
        if (is_string($metadata['albumTitle'] ?? null) && trim($metadata['albumTitle']) !== '') {
            $tags['albumTitle'] = trim($metadata['albumTitle']);
        }
        $artwork = is_array($metadata['artwork'] ?? null) ? $metadata['artwork'] : [];
        $lyrics = is_array($metadata['lyrics'] ?? null) ? $metadata['lyrics'] : [];
        $details = ['writtenTags' => $tags, 'artworkEmbedded' => (bool) ($artwork['embedded'] ?? false),
            'lyricsEmbedded' => (bool) ($lyrics['embedded'] ?? false)];
        if (($artwork['embedded'] ?? false) === true && is_string($artwork['mimeType'] ?? null)) {
            $details['artworkMimeType'] = $artwork['mimeType'];
        }
        if (($lyrics['embedded'] ?? false) === true) $details['lyricsKind'] = 'line';
        return $details;
    }

    /**
     * 经核心统一发布器写入本地或远程库，再创建增量扫描。
     *
     * 上传发生在数据库事务外且暂存保留到任务 succeeded 提交之后；远端限流、权限或协议失败不会删除
     * 已下载正文。核心账本负责崩溃恢复、非覆盖和“艺人/专辑/歌曲”路径，插件不接触远端凭据或 URL。
     */
    private function publish(stdClass $row, string $workerId): void
    {
        $this->assertLiveAuthorization((string) $row->requested_by, (string) $row->library_id);
        try {
            $metadata = $this->publicationMetadata($this->decodeMetadata((string) $row->metadata_json));
            $this->publications->publish('lx-music', (string) $row->id, (string) $row->library_id,
                $this->storage->publicationSource((string) $row->id), 'single', (string) $row->artist,
                (string) $row->album, (string) $row->title, (string) $row->format, $metadata);
        } catch (PluginMediaPublicationFailed $failure) {
            throw new LxDownloadFailure('LX_DOWNLOAD_LIBRARY_PUBLICATION_FAILED', ['failureCode' => $failure->errorCode]);
        }
        $scanState = $this->scans->queueAutomaticJob((string) $row->library_id, 'download_import');
        $scanJobId = $scanState === 'queued' ? Db::table('library_scan_jobs')
            ->where('library_id', (string) $row->library_id)->where('status', 'queued')
            ->orderByDesc('created_at')->value('id') : null;
        $finished = gmdate('Y-m-d\TH:i:s\Z');
        Db::transaction(function () use ($row, $workerId, $scanJobId, $finished): void {
            $changed = Db::table('lx_music_download_jobs')->where('id', (string) $row->id)
                ->where('status', 'publishing')->update([
                    'status' => 'succeeded', 'progress_basis_points' => 10_000, 'imported_files' => 1,
                    'scan_job_id' => $scanJobId, 'reference_ciphertext' => null, 'resolved_ciphertext' => null,
                    'worker_id' => null, 'heartbeat_at' => null, 'error_code' => null,
                    'finished_at' => $finished, 'updated_at' => $finished,
                ]);
            if ($changed !== 1) throw new RuntimeException('LX_DOWNLOAD_STATE_CHANGED');
            $this->stats->incrementSuccess((string) $row->source_key);
            $this->audit->record($row->requested_by === null ? null : (string) $row->requested_by,
                'plugin.lx_music.download.complete', 'lx_music_download_job', (string) $row->id,
                'success', (string) $row->request_id,
                ['libraryId' => (string) $row->library_id, 'sourceKey' => (string) $row->source_key,
                    'quality' => (string) $row->quality, 'importedFiles' => 1]);
            $this->diagnostics->record((string) $row->id, (string) $row->source_key, null,
                (string) $row->quality, 'info', 'LX_DOWNLOAD_SUCCEEDED', 'publish', [
                    'attempt' => max(0, min(10, (int) $row->attempt)),
                ], (string) $row->request_id);
        });
        try {
            $this->storage->finalize((string) $row->id);
        } catch (LxDownloadFailure) {
            // 已发布媒体和 succeeded 数据库事实不能因收据清理失败回滚；残留仍受任务标记严格约束。
        }
    }

    /**
     * 只把已经写入音频的描述字段交给核心发布账本。
     *
     * 歌词正文、封面状态和任何瞬时 URL 都不属于扫描元数据，必须留在插件任务快照。返回字段由核心再次
     * 严格校验；缺失字段不猜测，基础标题/艺人/专辑仍由发布命令参数提供兼容回退。本方法无数据库、
     * 文件或网络副作用。
     *
     * @param array<string,mixed> $metadata
     * @return array<string,mixed>
     */
    private function publicationMetadata(array $metadata): array
    {
        $allowed = ['title', 'artists', 'albumTitle', 'albumArtists', 'trackNumber', 'trackTotal',
            'discNumber', 'discTotal', 'genres', 'releaseDate', 'isrc', 'durationMs'];
        return array_intersect_key($metadata, array_fill_keys($allowed, true));
    }

    /** 临时网络/来源失败最多重试三轮；安全、权限、媒体和路径错误立即终止。 */
    private function handleFailure(stdClass $row, string $errorCode, array $diagnostic = [], ?string $platformKey = null): void
    {
        $retryable = in_array($errorCode, ['LX_SOURCE_UNAVAILABLE', 'LX_SOURCE_HTTP_FAILED',
            'LX_SCRIPT_REQUEST_FAILED', 'LX_SCRIPT_REQUEST_TIMEOUT', 'LX_SCRIPT_RESOLVE_TIMEOUT',
            'LX_SCRIPT_UPSTREAM_SERVER_FAILED', 'LX_SCRIPT_UPSTREAM_RATE_LIMITED', 'LX_SCRIPT_RUNNER_TIMEOUT',
            'LX_DOWNLOAD_HTTP_FAILED', 'LX_DOWNLOAD_NETWORK_FAILED', 'LX_DOWNLOAD_HOST_UNRESOLVED'], true);
        /** @var stdClass|null $current */
        $current = Db::table('lx_music_download_jobs')->where('id', (string) $row->id)
            ->first(['status', 'attempt']);
        if (!$current instanceof stdClass) return;
        $attempt = (int) $current->attempt;
        $retryable = $retryable && $attempt < 3 && $row->status !== 'publishing';
        if ($retryable) {
            try {
                $this->storage->cleanup((string) $row->id);
            } catch (Throwable) {
                $retryable = false;
                $errorCode = 'LX_DOWNLOAD_STAGING_CLEANUP_FAILED';
            }
        }
        $now = gmdate('Y-m-d\TH:i:s\Z');
        $stage = match ((string) $current->status) {
            'downloading' => 'download',
            'publishing' => 'publish',
            default => 'resolve',
        };
        if (is_string($diagnostic['stage'] ?? null)) $diagnostic['runnerStage'] = $diagnostic['stage'];
        unset($diagnostic['stage']);
        $diagnostic['automaticRetry'] = $retryable;
        $diagnostic['attempt'] = max(0, min(10, $attempt));
        Db::transaction(function () use ($row, $retryable, $errorCode, $now, $diagnostic,
            $platformKey, $stage): void {
            $changed = Db::table('lx_music_download_jobs')->where('id', (string) $row->id)
                ->whereIn('status', ['queued', 'resolving', 'downloading', 'publishing'])->update($retryable ? [
                    'status' => 'queued', 'resolved_ciphertext' => null, 'downloaded_bytes' => 0,
                    'progress_basis_points' => 0, 'worker_id' => null, 'heartbeat_at' => null,
                    'error_code' => $errorCode, 'updated_at' => $now,
                ] : [
                    'status' => 'failed', 'worker_id' => null, 'heartbeat_at' => null,
                    'error_code' => $errorCode, 'finished_at' => $now, 'updated_at' => $now,
                ]);
            if ($changed !== 1) return;
            $this->diagnostics->record((string) $row->id, (string) $row->source_key, $platformKey,
                (string) $row->quality, $retryable ? 'warning' : 'error', $errorCode, $stage,
                $diagnostic, (string) $row->request_id);
        });
    }

    /** 实时复验账号、manage_system 与目标库 manage；撤权任务不得继续写本地或远程对象。 */
    private function assertLiveAuthorization(string $userId, string $libraryId): void
    {
        $user = Db::table('users')->where('id', $userId)->where('status', 'active')->whereNull('deleted_at')
            ->first(['id', 'is_super_admin']);
        if (!$user instanceof stdClass) throw new LxDownloadFailure('LX_DOWNLOAD_AUTHORIZATION_REVOKED');
        if (!Db::table('music_libraries')->where('id', $libraryId)->where('status', 'active')
            ->whereIn('source_type', ['local', 'webdav', 'onedrive', 'google_drive'])->exists()) {
            throw new LxDownloadFailure('LX_DOWNLOAD_LIBRARY_UNAVAILABLE');
        }
        if ((int) $user->is_super_admin === 1) return;
        $system = Db::table('user_roles')->join('role_capabilities', 'role_capabilities.role_id', '=', 'user_roles.role_id')
            ->where('user_roles.user_id', $userId)->where('role_capabilities.capability_key', 'manage_system')->exists();
        $grant = Db::table('library_user_grants')->where('user_id', $userId)->where('library_id', $libraryId)
            ->where('access_level', 'manage')->exists();
        if (!$system || !$grant) throw new LxDownloadFailure('LX_DOWNLOAD_AUTHORIZATION_REVOKED');
    }
}
