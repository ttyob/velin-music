<?php

declare(strict_types=1);

namespace plugin\lx_music\app\application\Download;

use app\application\ResourcePlugin\PhpResourcePluginWorkspaceService;
use app\application\ResourcePlugin\PhpResourcePluginWorkspaceUnavailable;

/**
 * LxDownloadStorage 管理插件媒体临时库中的任务暂存和非覆盖原子发布。
 *
 * 中间音频、收据和任务标记只能进入核心分配的 `/storage/downloads/lx-music`，不得在音乐库内创建 partial
 * 或隐藏目录。每个任务只能操作其 ULID 子目录；成功后以硬链接原子、不覆盖地发布单个完整音频到
 * `LX Music Downloads`。媒体临时库与目标库跨设备时失败关闭，绝不复制到库内临时路径。失败补偿只
 * 删除当前任务所有的普通文件、标记和空目录，不递归跟随链接，也不触碰已发布媒体。
 */
final readonly class LxDownloadStorage
{
    private const PLUGIN_KEY = 'lx-music';
    private const MARKER = '.velin-task-owner';
    private const RECEIPT = '.published.json';

    public function __construct(
        private ?PhpResourcePluginWorkspaceService $workspaces = null,
    ) {
    }

    /**
     * 为一个下载任务建立全新的插件媒体暂存目录。
     *
     * 任务 ID 必须是 ULID。已有同任务目录只会在所有权标记和内容白名单均通过后清理，避免重试复用半截
     * 正文；核心工作区不可用时转换为插件稳定错误。返回路径只供插件 Worker 内部使用，不能进入 API、
     * 日志或数据库。
     *
     * @return array{directory:string,partial:string}
     */
    public function prepare(string $jobId): array
    {
        $this->assertJobId($jobId);
        $staging = $this->workspace();
        $directory = $staging . DIRECTORY_SEPARATOR . strtolower($jobId);
        if (file_exists($directory) || is_link($directory)) $this->cleanup($jobId);
        if (!mkdir($directory, 0700)) throw new LxDownloadFailure('LX_DOWNLOAD_STAGING_UNAVAILABLE');
        $jobMarker = $directory . DIRECTORY_SEPARATOR . self::MARKER;
        if (file_put_contents($jobMarker, $jobId . "\n", LOCK_EX) === false) throw new LxDownloadFailure('LX_DOWNLOAD_STAGING_UNAVAILABLE');
        @chmod($jobMarker, 0600);
        return ['directory' => $directory, 'partial' => $directory . DIRECTORY_SEPARATOR . 'audio.partial'];
    }

    /**
     * 原子发布已完整下载的普通文件并返回最终路径的安全 basename。
     *
     * 目标名称来自已裁剪元数据，正常入库保持稳定原名；只有目标已存在时才追加当前任务短码以解决重名，
     * 且绝不覆盖已有文件。发布前比较暂存文件
     * 与目标目录的设备号，只允许 `link()` 在同一文件系统完成原子“不存在才创建”。成功后删除 partial，
     * 数据库提交后再清理收据和任务目录；清理失败不回滚已发布媒体，后续只能按同一任务标记重试。
     */
    public function publish(string $libraryRoot, string $jobId, string $artist, string $title, string $format): string
    {
        $this->assertJobId($jobId);
        $root = realpath($libraryRoot);
        $directory = $this->workspace() . DIRECTORY_SEPARATOR . strtolower($jobId);
        $partial = $directory . DIRECTORY_SEPARATOR . 'audio.partial';
        if (!is_string($root) || !is_dir($root) || !is_writable($root) || is_link($libraryRoot)
            || !in_array($format, ['mp3', 'flac', 'm4a', 'aac', 'ogg', 'opus', 'wav'], true)) {
            throw new LxDownloadFailure('LX_DOWNLOAD_STAGING_INVALID');
        }
        $collection = $root . DIRECTORY_SEPARATOR . 'LX Music Downloads';
        if (!is_dir($collection) && !mkdir($collection, 0750)) throw new LxDownloadFailure('LX_DOWNLOAD_TARGET_UNAVAILABLE');
        if (is_link($collection) || realpath($collection) !== $collection) throw new LxDownloadFailure('LX_DOWNLOAD_TARGET_INVALID');
        $label = $this->safeName(($artist !== '' ? $artist . ' - ' : '') . $title);
        $baseName = $label . '.' . $format;
        $collisionName = $label . ' [' . strtolower(substr($jobId, -8)) . '].' . $format;
        $name = $baseName;
        $target = $collection . DIRECTORY_SEPARATOR . $name;
        $receiptPath = $directory . DIRECTORY_SEPARATOR . self::RECEIPT;
        if (!file_exists($partial)) {
            $receiptFailure = null;
            foreach ([$baseName, $collisionName] as $candidateName) {
                $candidateTarget = $collection . DIRECTORY_SEPARATOR . $candidateName;
                if (!is_file($candidateTarget) || is_link($candidateTarget)) continue;
                try {
                    $this->assertReceipt($directory, $receiptPath, $candidateTarget, $candidateName, $jobId);
                    return $candidateName;
                } catch (LxDownloadFailure $failure) {
                    $receiptFailure ??= $failure;
                }
            }
            if ($receiptFailure instanceof LxDownloadFailure) throw $receiptFailure;
        }
        if (file_exists($target) || is_link($target)) {
            $name = $collisionName;
            $target = $collection . DIRECTORY_SEPARATOR . $name;
        }
        if (realpath(dirname($partial)) !== $directory || is_link($partial) || !is_file($partial)
            || @file_get_contents($directory . DIRECTORY_SEPARATOR . self::MARKER) !== $jobId . "\n") {
            throw new LxDownloadFailure('LX_DOWNLOAD_STAGING_INVALID');
        }
        $size = filesize($partial);
        $sha256 = hash_file('sha256', $partial);
        if (!is_int($size) || $size <= 0 || !is_string($sha256)) throw new LxDownloadFailure('LX_DOWNLOAD_STAGING_INVALID');
        $sourceStat = @stat($partial);
        $targetStat = @stat($collection);
        if (!is_array($sourceStat) || !is_array($targetStat)
            || (string) ($sourceStat['dev'] ?? '') !== (string) ($targetStat['dev'] ?? '')) {
            throw new LxDownloadFailure('LX_DOWNLOAD_TARGET_FILESYSTEM_MISMATCH');
        }
        $receipt = json_encode(['jobId' => $jobId, 'name' => $name, 'size' => $size, 'sha256' => $sha256], JSON_THROW_ON_ERROR);
        if (file_exists($receiptPath) || file_put_contents($receiptPath, $receipt, LOCK_EX) === false) {
            throw new LxDownloadFailure('LX_DOWNLOAD_STAGING_INVALID');
        }
        @chmod($receiptPath, 0600);
        // link 提供原子“不存在才创建”；跨设备已在上方稳定失败，不允许回退到音乐库内创建 partial。
        if (file_exists($target) || is_link($target) || !link($partial, $target)) {
            throw new LxDownloadFailure('LX_DOWNLOAD_TARGET_EXISTS');
        }
        @chmod($target, 0640);
        if (!unlink($partial)) throw new LxDownloadFailure('LX_DOWNLOAD_STAGING_CLEANUP_FAILED');
        return $name;
    }

    /** 数据库成功提交后精确清理任务标记与发布收据；已发布文件不在清理范围。 */
    public function finalize(string $jobId): void
    {
        $this->cleanup($jobId);
    }

    /**
     * 返回仍由当前任务 marker 持有的完整暂存音频，供核心统一发布器读取。
     *
     * 该方法不移动、链接或删除文件；发布器完成本地/远端非覆盖写入并提交任务后，Worker 才调用 finalize
     * 清理。路径不得进入任务、日志或 API，marker、真实父目录和普通文件任一不符都失败关闭。
     */
    public function publicationSource(string $jobId): string
    {
        $this->assertJobId($jobId);
        $directory = $this->workspace() . DIRECTORY_SEPARATOR . strtolower($jobId);
        $partial = $directory . DIRECTORY_SEPARATOR . 'audio.partial';
        if (realpath($directory) !== $directory || is_link($directory)
            || @file_get_contents($directory . DIRECTORY_SEPARATOR . self::MARKER) !== $jobId . "\n"
            || realpath($partial) !== $partial || is_link($partial) || !is_file($partial) || !is_readable($partial)) {
            throw new LxDownloadFailure('LX_DOWNLOAD_STAGING_INVALID');
        }
        return $partial;
    }

    /**
     * 仅清理插件媒体临时库中匹配任务 ULID 和所有权标记的目录。
     *
     * 允许删除的文件固定为 partial、可选封面与发布收据；未知内容、链接或标记不符会保留现场并失败关闭。空目录
     * 和不存在目录幂等返回，核心分配的插件根及其所有权标记不会由单任务清理删除。
     */
    public function cleanup(string $jobId): void
    {
        $this->assertJobId($jobId);
        $directory = $this->workspace() . DIRECTORY_SEPARATOR . strtolower($jobId);
        if (!is_dir($directory) || is_link($directory)) return;
        $marker = $directory . DIRECTORY_SEPARATOR . self::MARKER;
        if (@file_get_contents($marker) !== $jobId . "\n") throw new LxDownloadFailure('LX_DOWNLOAD_STAGING_INVALID');
        $entries = array_values(array_diff(scandir($directory) ?: [], ['.', '..', self::MARKER]));
        foreach ($entries as $entry) {
            $path = $directory . DIRECTORY_SEPARATOR . $entry;
            if (!in_array($entry, ['audio.partial', 'artwork.jpg', 'artwork.png', self::RECEIPT], true)
                || is_link($path) || !is_file($path) || !unlink($path)) {
                throw new LxDownloadFailure('LX_DOWNLOAD_STAGING_CLEANUP_FAILED');
            }
        }
        if (!unlink($marker) || !rmdir($directory)) throw new LxDownloadFailure('LX_DOWNLOAD_STAGING_CLEANUP_FAILED');
    }

    /** 将核心目录分配错误收敛为插件稳定错误，避免物理路径通过异常消息进入任务日志。 */
    private function workspace(): string
    {
        try {
            return ($this->workspaces ?? new PhpResourcePluginWorkspaceService())->mediaDirectory(self::PLUGIN_KEY);
        } catch (PhpResourcePluginWorkspaceUnavailable) {
            throw new LxDownloadFailure('LX_DOWNLOAD_MEDIA_WORKSPACE_UNAVAILABLE');
        }
    }

    /** 任务目录名只接受规范 ULID，任何其他字符串都不能参与路径拼接。 */
    private function assertJobId(string $jobId): void
    {
        if (preg_match('/^[0-9A-HJKMNP-TV-Z]{26}$/D', $jobId) !== 1) {
            throw new LxDownloadFailure('LX_DOWNLOAD_STAGING_INVALID');
        }
    }

    private function safeName(string $value): string
    {
        $name = preg_replace('/[^\pL\pN ._()\[\]-]+/u', '_', trim($value)) ?: 'download';
        $name = trim(mb_substr($name, 0, 140, 'UTF-8'), ' .');
        return $name === '' ? 'download' : $name;
    }

    /** 恢复发布必须同时匹配任务标记、收据、文件名、大小和 SHA-256，单凭目标存在不能算成功。 */
    private function assertReceipt(string $directory, string $receiptPath, string $target, string $name, string $jobId): void
    {
        if (@file_get_contents($directory . DIRECTORY_SEPARATOR . self::MARKER) !== $jobId . "\n"
            || !is_file($receiptPath) || is_link($receiptPath)) throw new LxDownloadFailure('LX_DOWNLOAD_RECEIPT_INVALID');
        try {
            $receipt = json_decode((string) file_get_contents($receiptPath), true, 8, JSON_THROW_ON_ERROR);
        } catch (\Throwable) {
            throw new LxDownloadFailure('LX_DOWNLOAD_RECEIPT_INVALID');
        }
        $size = filesize($target);
        $sha256 = hash_file('sha256', $target);
        if (!is_array($receipt) || array_keys($receipt) !== ['jobId', 'name', 'size', 'sha256']
            || $receipt['jobId'] !== $jobId || $receipt['name'] !== $name || $receipt['size'] !== $size
            || !is_string($sha256) || !is_string($receipt['sha256']) || !hash_equals($receipt['sha256'], $sha256)) {
            throw new LxDownloadFailure('LX_DOWNLOAD_RECEIPT_INVALID');
        }
    }
}
