<?php

declare(strict_types=1);

namespace plugin\lx_music\app\application\Download;

use Closure;

/**
 * LxDownloadUrlPolicy 校验来源解析出的临时音频 URL 并固定公开 DNS 地址。
 *
 * 下载只接受无认证信息的 HTTPS 443 地址，拒绝 IP 字面量、localhost、私网、保留、回环和链路本地。
 * 任一 DNS 答案非公开即整体失败，调用方把返回 IP 写入 CURLOPT_RESOLVE 并禁用重定向，从校验到 TLS
 * 请求不再重新解析，关闭 DNS rebinding 与跳转到内网的路径。查询串允许携带短期平台签名，但不持久化
 * 明文、不记录日志，也不返回浏览器。
 */
final readonly class LxDownloadUrlPolicy
{
    private ?Closure $dnsResolver;

    /**
     * @param callable(string,int):array<int,array<string,mixed>>|null $dnsResolver 仅供合同测试注入确定性 DNS；
     * 生产默认始终调用 dns_get_record，返回记录仍逐项经过公网地址校验，注入不能绕过后续安全规则。
     */
    public function __construct(?callable $dnsResolver = null)
    {
        $this->dnsResolver = $dnsResolver === null ? null : Closure::fromCallable($dnsResolver);
    }

    /** @return array{url:string,host:string,ip:string} */
    public function resolve(string $input): array
    {
        $url = trim($input);
        if ($url === '' || strlen($url) > 8192 || preg_match('/[\x00-\x20\x7F]/', $url) === 1) {
            throw new LxDownloadFailure('LX_DOWNLOAD_URL_INVALID');
        }
        $parts = parse_url($url);
        $host = is_array($parts) ? strtolower((string) ($parts['host'] ?? '')) : '';
        if (!is_array($parts) || strtolower((string) ($parts['scheme'] ?? '')) !== 'https'
            || $host === '' || $host === 'localhost' || isset($parts['user']) || isset($parts['pass'])
            || isset($parts['fragment']) || (isset($parts['port']) && (int) $parts['port'] !== 443)
            || filter_var($host, FILTER_VALIDATE_IP) !== false || preg_match('/^[a-z0-9.-]+$/D', $host) !== 1
            || str_contains($host, '..') || (string) ($parts['path'] ?? '') === '') {
            throw new LxDownloadFailure('LX_DOWNLOAD_URL_INVALID');
        }
        $records = $this->dnsResolver === null
            ? dns_get_record($host, DNS_A | DNS_AAAA)
            : ($this->dnsResolver)($host, DNS_A | DNS_AAAA);
        if (!is_array($records) || $records === []) throw new LxDownloadFailure('LX_DOWNLOAD_HOST_UNRESOLVED');
        $ips = [];
        foreach ($records as $record) {
            $ip = $record['ip'] ?? $record['ipv6'] ?? null;
            if (!is_string($ip) || filter_var($ip, FILTER_VALIDATE_IP) === false
                || filter_var($ip, FILTER_VALIDATE_IP,
                    FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false) {
                throw new LxDownloadFailure('LX_DOWNLOAD_HOST_BLOCKED');
            }
            $ips[] = $ip;
        }
        return ['url' => $url, 'host' => $host, 'ip' => $ips[0]];
    }
}
