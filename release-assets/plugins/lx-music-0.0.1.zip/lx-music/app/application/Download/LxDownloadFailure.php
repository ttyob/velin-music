<?php

declare(strict_types=1);

namespace plugin\lx_music\app\application\Download;

/**
 * LxDownloadFailure 表示可安全写入任务状态的稳定下载错误。
 *
 * errorCode 只能由插件代码选择，不包含 URL、请求头、路径、平台响应或异常正文。Worker 根据固定白名单
 * 判断是否重试；未知异常不能借此类进入浏览器或日志详情。
 */
final class LxDownloadFailure extends \RuntimeException
{
    /**
     * @param array<string,mixed> $diagnostic 只允许来自已校验 runner 协议的脱敏结构摘要
     * @param string|null $platformKey LX 固定平台键；不得传入歌曲或专辑资源 ID
     */
    public function __construct(
        public readonly string $errorCode,
        public readonly array $diagnostic = [],
        public readonly ?string $platformKey = null,
    )
    {
        parent::__construct($errorCode);
    }
}
