<?php

declare(strict_types=1);

namespace plugin\lx_music\app\application\Download;

use app\infrastructure\Audit\AuditLogger;
use stdClass;
use Symfony\Component\Uid\Ulid;
use support\Db;

/**
 * LxDownloadDiagnosticLogService 保存并投影 LX 下载链路的脱敏诊断事件。
 *
 * 本表只属于插件，不能替代核心不可变审计。写入字段采用固定白名单：允许任务阶段、稳定错误码、HTTP
 * 状态、Content-Type、响应字节数、JSON 顶层字段名和脚本 SHA-256；URL、Header 值、响应正文、平台
 * 资源 ID、musicInfo、Cookie、Token 和物理路径没有输入通道。每次写入在短事务中清理 30 天前数据并
 * 只保留最近 1000 条，避免故障循环无限扩大 SQLite。日志清理不修改任务、租约或媒体文件。
 */
final readonly class LxDownloadDiagnosticLogService
{
    private const MAX_ROWS = 1000;

    public function __construct(private AuditLogger $audit = new AuditLogger())
    {
    }

    /**
     * 写入一个经过结构约束的诊断事件。
     *
     * @param array<string,mixed> $details runner 或 Worker 生成的安全元数据，未知字段会导致失败关闭
     */
    public function record(
        ?string $jobId,
        string $sourceKey,
        ?string $platformKey,
        ?string $quality,
        string $level,
        string $eventCode,
        string $stage,
        array $details,
        ?string $requestId,
    ): void {
        if (($jobId !== null && preg_match('/^[0-9A-HJKMNP-TV-Z]{26}$/D', $jobId) !== 1)
            || preg_match('/^[a-z0-9][a-z0-9_-]{1,31}$/D', $sourceKey) !== 1
            || ($platformKey !== null && !in_array($platformKey, ['kw', 'kg', 'tx', 'wy', 'mg'], true))
            || ($quality !== null && !in_array($quality, ['128k', '320k', 'flac', 'flac24'], true))
            || !in_array($level, ['info', 'warning', 'error'], true)
            || preg_match('/^LX_[A-Z0-9_]{1,80}$/D', $eventCode) !== 1
            || !in_array($stage, ['queue', 'resolve', 'download', 'publish', 'retry', 'cleanup'], true)
            || ($requestId !== null && ($requestId === '' || strlen($requestId) > 128))) {
            throw new \InvalidArgumentException('LX_DIAGNOSTIC_LOG_INVALID');
        }
        $safeDetails = $this->details($details);
        $now = gmdate('Y-m-d\TH:i:s\Z');
        Db::transaction(static function () use ($jobId, $sourceKey, $platformKey, $quality, $level,
            $eventCode, $stage, $safeDetails, $requestId, $now): void {
            Db::table('lx_music_diagnostic_logs')->insert([
                'id' => (string) new Ulid(), 'download_job_id' => $jobId, 'source_key' => $sourceKey,
                'platform_key' => $platformKey, 'quality' => $quality, 'level' => $level,
                'event_code' => $eventCode, 'stage' => $stage,
                'details_json' => json_encode($safeDetails, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES),
                'request_id' => $requestId, 'created_at' => $now,
            ]);
            Db::table('lx_music_diagnostic_logs')->where('created_at', '<', gmdate(
                'Y-m-d\TH:i:s\Z', time() - 30 * 86400,
            ))->delete();
            Db::connection()->statement('DELETE FROM lx_music_diagnostic_logs WHERE id NOT IN '
                . '(SELECT id FROM lx_music_diagnostic_logs ORDER BY created_at DESC, id DESC LIMIT '
                . self::MAX_ROWS . ')');
        });
    }

    /** @return array{logs:list<array<string,mixed>>} */
    public function list(int $limit = 100): array
    {
        $rows = Db::table('lx_music_diagnostic_logs')->orderByDesc('created_at')->orderByDesc('id')
            ->limit(max(1, min(200, $limit)))->get()->all();
        return ['logs' => array_map(function (stdClass $row): array {
            $details = json_decode((string) $row->details_json, true, 8, JSON_THROW_ON_ERROR);
            return [
                'id' => (string) $row->id,
                'jobId' => $row->download_job_id === null ? null : (string) $row->download_job_id,
                'source' => (string) $row->source_key,
                'platform' => $row->platform_key === null ? null : (string) $row->platform_key,
                'quality' => $row->quality === null ? null : (string) $row->quality,
                'level' => (string) $row->level,
                'eventCode' => (string) $row->event_code,
                'stage' => (string) $row->stage,
                'details' => is_array($details) ? $details : [],
                'requestId' => $row->request_id === null ? null : (string) $row->request_id,
                'createdAt' => (string) $row->created_at,
            ];
        }, $rows)];
    }

    /**
     * 按时间正序返回一个下载任务自己的脱敏日志。
     *
     * taskId 必须是下载任务 ULID；调用方在进入本方法前已经完成任务和音乐库授权校验。本查询不会回退
     * 全局日志或返回 jobId 为空的来源诊断，避免歌单补全状态把其他歌曲的事件泄漏给核心。
     *
     * @return array{logs:list<array<string,mixed>>}
     */
    public function listForJob(string $jobId, int $limit = 50): array
    {
        if (preg_match('/^[0-9A-HJKMNP-TV-Z]{26}$/D', $jobId) !== 1) {
            throw new \InvalidArgumentException('LX_DIAGNOSTIC_LOG_INVALID');
        }
        $rows = Db::table('lx_music_diagnostic_logs')->where('download_job_id', $jobId)
            ->orderBy('created_at')->orderBy('id')->limit(max(1, min(100, $limit)))->get()->all();
        return ['logs' => array_map(function (stdClass $row): array {
            $details = json_decode((string) $row->details_json, true, 8, JSON_THROW_ON_ERROR);
            return [
                'id' => (string) $row->id,
                'jobId' => (string) $row->download_job_id,
                'source' => (string) $row->source_key,
                'platform' => $row->platform_key === null ? null : (string) $row->platform_key,
                'quality' => $row->quality === null ? null : (string) $row->quality,
                'level' => (string) $row->level,
                'eventCode' => (string) $row->event_code,
                'stage' => (string) $row->stage,
                'details' => is_array($details) ? $details : [],
                'requestId' => $row->request_id === null ? null : (string) $row->request_id,
                'createdAt' => (string) $row->created_at,
            ];
        }, $rows)];
    }

    /** 清空插件日志并在同一短事务写核心审计；重复调用保持幂等。 */
    public function clear(array $actor, string $requestId): array
    {
        return Db::transaction(function () use ($actor, $requestId): array {
            $deleted = Db::table('lx_music_diagnostic_logs')->delete();
            $this->audit->record((string) $actor['id'], 'plugin.lx_music.diagnostics.clear',
                'lx_music_diagnostic_log', null, 'success', $requestId, ['deletedCount' => $deleted]);
            return ['deletedCount' => $deleted];
        });
    }

    /** 精确删除一条日志并写核心审计；不存在或并发已删除时失败关闭。 */
    public function clearOne(string $logId, array $actor, string $requestId): array
    {
        if (preg_match('/^[0-9A-HJKMNP-TV-Z]{26}$/D', $logId) !== 1) throw new LxDownloadInvalid();
        return Db::transaction(function () use ($logId, $actor, $requestId): array {
            $deleted = Db::table('lx_music_diagnostic_logs')->where('id', $logId)->delete();
            if ($deleted !== 1) throw new LxDownloadConflict();
            $this->audit->record((string) $actor['id'], 'plugin.lx_music.diagnostics.delete',
                'lx_music_diagnostic_log', $logId, 'success', $requestId, ['deletedCount' => 1]);
            return ['id' => $logId, 'deleted' => true];
        });
    }

    /** @param array<string,mixed> $input @return array<string,mixed> */
    private function details(array $input): array
    {
        $allowed = ['operation', 'method', 'statusCode', 'contentType', 'responseBytes', 'bodyType',
            'topLevelKeys', 'scriptSha256', 'protocolIssue', 'urlType', 'sha256Type',
            'automaticRetry', 'attempt', 'downloadedBytes', 'upstreamCode', 'upstreamStatus',
            'upstreamError', 'upstreamMessage', 'upstreamText', 'runtimeMessage', 'runnerStage',
            'failureCode', 'writtenTags', 'artworkEmbedded', 'artworkMimeType', 'lyricsEmbedded', 'lyricsKind'];
        foreach (array_keys($input) as $key) {
            if (!is_string($key) || !in_array($key, $allowed, true)) {
                throw new \InvalidArgumentException('LX_DIAGNOSTIC_DETAILS_INVALID');
            }
        }
        $output = [];
        if (isset($input['operation'])) {
            if (!in_array($input['operation'], ['init', 'resolve', 'metadata'], true)) throw new \InvalidArgumentException('LX_DIAGNOSTIC_DETAILS_INVALID');
            $output['operation'] = $input['operation'];
        }
        if (isset($input['method'])) {
            if (!in_array($input['method'], ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD'], true)) throw new \InvalidArgumentException('LX_DIAGNOSTIC_DETAILS_INVALID');
            $output['method'] = $input['method'];
        }
        foreach (['statusCode' => 599, 'responseBytes' => 2_097_152, 'attempt' => 10] as $key => $maximum) {
            if (!array_key_exists($key, $input)) continue;
            if (!is_int($input[$key]) || $input[$key] < 0 || $input[$key] > $maximum) throw new \InvalidArgumentException('LX_DIAGNOSTIC_DETAILS_INVALID');
            $output[$key] = $input[$key];
        }
        if (array_key_exists('downloadedBytes', $input)) {
            if (!is_int($input['downloadedBytes']) || $input['downloadedBytes'] < 0
                || $input['downloadedBytes'] > 4_294_967_296) {
                throw new \InvalidArgumentException('LX_DIAGNOSTIC_DETAILS_INVALID');
            }
            $output['downloadedBytes'] = $input['downloadedBytes'];
        }
        if (isset($input['contentType'])) {
            if (!is_string($input['contentType']) || strlen($input['contentType']) > 128
                || preg_match('/^[a-z0-9!#$&^_.+\/-]+$/D', $input['contentType']) !== 1) throw new \InvalidArgumentException('LX_DIAGNOSTIC_DETAILS_INVALID');
            $output['contentType'] = $input['contentType'];
        }
        if (isset($input['bodyType'])) {
            if (!in_array($input['bodyType'], ['empty', 'text', 'object', 'array', 'number', 'boolean', 'null'], true)) throw new \InvalidArgumentException('LX_DIAGNOSTIC_DETAILS_INVALID');
            $output['bodyType'] = $input['bodyType'];
        }
        if (isset($input['topLevelKeys'])) {
            if (!is_array($input['topLevelKeys']) || !array_is_list($input['topLevelKeys']) || count($input['topLevelKeys']) > 20) throw new \InvalidArgumentException('LX_DIAGNOSTIC_DETAILS_INVALID');
            foreach ($input['topLevelKeys'] as $key) {
                if (!is_string($key) || preg_match('/^[A-Za-z0-9_.-]{1,64}$/D', $key) !== 1) throw new \InvalidArgumentException('LX_DIAGNOSTIC_DETAILS_INVALID');
            }
            $output['topLevelKeys'] = $input['topLevelKeys'];
        }
        if (isset($input['scriptSha256'])) {
            if (!is_string($input['scriptSha256']) || preg_match('/^[a-f0-9]{64}$/D', $input['scriptSha256']) !== 1) throw new \InvalidArgumentException('LX_DIAGNOSTIC_DETAILS_INVALID');
            $output['scriptSha256'] = $input['scriptSha256'];
        }
        if (isset($input['protocolIssue'])) {
            if (!in_array($input['protocolIssue'], ['empty_output', 'output_too_large', 'invalid_json',
                'invalid_envelope', 'invalid_error_diagnostic', 'invalid_success_payload'], true)) {
                throw new \InvalidArgumentException('LX_DIAGNOSTIC_DETAILS_INVALID');
            }
            $output['protocolIssue'] = $input['protocolIssue'];
        }
        foreach (['urlType', 'sha256Type'] as $key) {
            if (isset($input[$key])) {
                if (!in_array($input[$key], ['absent', 'string', 'array', 'object', 'number', 'boolean', 'null'], true)) {
                    throw new \InvalidArgumentException('LX_DIAGNOSTIC_DETAILS_INVALID');
                }
                $output[$key] = $input[$key];
            }
        }
        foreach (['upstreamCode' => 80, 'upstreamStatus' => 80, 'upstreamError' => 240,
            'upstreamMessage' => 500, 'upstreamText' => 500, 'runtimeMessage' => 500] as $key => $maximum) {
            if (!isset($input[$key])) continue;
            if (!is_string($input[$key]) || $input[$key] === '' || mb_strlen($input[$key], 'UTF-8') > $maximum
                || preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', $input[$key]) === 1
                || preg_match('/https?:\/\/|bearer\s|(?:token|cookie|signature|secret|api[_-]?key)\s*[=:]/iu',
                    $input[$key]) === 1) {
                throw new \InvalidArgumentException('LX_DIAGNOSTIC_DETAILS_INVALID');
            }
            $output[$key] = $input[$key];
        }
        if (isset($input['runnerStage'])) {
            if (!in_array($input['runnerStage'], ['script_fetch', 'upstream_request', 'runner_protocol'], true)) {
                throw new \InvalidArgumentException('LX_DIAGNOSTIC_DETAILS_INVALID');
            }
            $output['runnerStage'] = $input['runnerStage'];
        }
        if (isset($input['automaticRetry'])) {
            if (!is_bool($input['automaticRetry'])) throw new \InvalidArgumentException('LX_DIAGNOSTIC_DETAILS_INVALID');
            $output['automaticRetry'] = $input['automaticRetry'];
        }
        if (isset($input['failureCode'])) {
            if (!is_string($input['failureCode'])
                || preg_match('/^(?:LX|ARTWORK|LYRICS)_[A-Z0-9_]{1,100}$/D', $input['failureCode']) !== 1) {
                throw new \InvalidArgumentException('LX_DIAGNOSTIC_DETAILS_INVALID');
            }
            $output['failureCode'] = $input['failureCode'];
        }
        if (isset($input['writtenTags'])) {
            if (!is_array($input['writtenTags']) || array_is_list($input['writtenTags'])
                || array_diff(array_keys($input['writtenTags']), ['title', 'artists', 'albumTitle', 'albumArtists']) !== []) {
                throw new \InvalidArgumentException('LX_DIAGNOSTIC_DETAILS_INVALID');
            }
            $tags = [];
            foreach (['title', 'albumTitle'] as $field) {
                if (!isset($input['writtenTags'][$field])) continue;
                $value = $input['writtenTags'][$field];
                if (!is_string($value) || trim($value) === '' || mb_strlen($value, 'UTF-8') > 500
                    || preg_match('/[\x00-\x1F\x7F]/u', $value) === 1) {
                    throw new \InvalidArgumentException('LX_DIAGNOSTIC_DETAILS_INVALID');
                }
                $tags[$field] = trim($value);
            }
            foreach (['artists', 'albumArtists'] as $field) {
                if (!isset($input['writtenTags'][$field])) continue;
                if (!is_array($input['writtenTags'][$field]) || !array_is_list($input['writtenTags'][$field])
                    || count($input['writtenTags'][$field]) > 16) {
                    throw new \InvalidArgumentException('LX_DIAGNOSTIC_DETAILS_INVALID');
                }
                $tags[$field] = [];
                foreach ($input['writtenTags'][$field] as $value) {
                    if (!is_string($value) || trim($value) === '' || mb_strlen($value, 'UTF-8') > 500
                        || preg_match('/[\x00-\x1F\x7F]/u', $value) === 1) {
                        throw new \InvalidArgumentException('LX_DIAGNOSTIC_DETAILS_INVALID');
                    }
                    $tags[$field][] = trim($value);
                }
            }
            $output['writtenTags'] = $tags;
        }
        foreach (['artworkEmbedded', 'lyricsEmbedded'] as $field) {
            if (!array_key_exists($field, $input)) continue;
            if (!is_bool($input[$field])) throw new \InvalidArgumentException('LX_DIAGNOSTIC_DETAILS_INVALID');
            $output[$field] = $input[$field];
        }
        if (isset($input['artworkMimeType'])) {
            if (!in_array($input['artworkMimeType'], ['image/jpeg', 'image/png'], true)) {
                throw new \InvalidArgumentException('LX_DIAGNOSTIC_DETAILS_INVALID');
            }
            $output['artworkMimeType'] = $input['artworkMimeType'];
        }
        if (isset($input['lyricsKind'])) {
            if (!in_array($input['lyricsKind'], ['plain', 'line', 'word'], true)) {
                throw new \InvalidArgumentException('LX_DIAGNOSTIC_DETAILS_INVALID');
            }
            $output['lyricsKind'] = $input['lyricsKind'];
        }
        return $output;
    }
}
