<?php

declare(strict_types=1);

namespace plugin\lx_music\app\application\Download;

use app\application\ResourcePlugin\PhpResourcePluginOperationConflict;
use app\infrastructure\Audit\AuditLogger;
use JsonException;
use stdClass;
use support\Db;

/**
 * LxDownloadSettingsService 管理插件默认目标库、最低质量与单文件大小上限。
 *
 * 设置属于插件并使用核心 `system_settings` 的版本锁。响应额外投影固定的下载临时目录，便于管理员
 * 核对 Docker 挂载；下载目录和固定 `move` 入库方式都不进入数据库或更新命令，浏览器不能改变。
 * 目标库保存时必须是当前 actor 可管理的 active 本地或受支持远程库，创建任务时仍会再次授权。更新事务不访问网络
 * 或文件系统，旧表单冲突时整次失败，不静默覆盖。
 */
final readonly class LxDownloadSettingsService
{
    public const DOWNLOAD_DIRECTORY = '/storage/downloads/lx-music';
    private const KEY = 'plugin.lx_music.download';

    public function __construct(private AuditLogger $audit = new AuditLogger())
    {
    }

    /**
     * 返回下载设置和只读临时目录部署事实。
     *
     * 目录来自插件工作区协议，不读取或写入设置 JSON，也不创建目录；真正下载前仍由核心工作区服务复验
     * 所有权、链接、音乐库重叠和可写性。该路径只用于同源管理员配置页核对，不能进入任务、日志或审计。
     *
     * @return array{libraryId:?string,minimumQuality:string,maximumBytes:int,downloadDirectory:string,importMode:string,version:int,updatedAt:string}
     */
    public function snapshot(): array
    {
        return $this->setting() + ['downloadDirectory' => self::DOWNLOAD_DIRECTORY, 'importMode' => 'move'];
    }

    /** 下载器是插件内置 Worker；可用性只表示设置可读，具体来源状态由搜索探测单独表达。 */
    public function status(): array
    {
        return $this->snapshot() + ['available' => true, 'mode' => 'direct_http', 'errorCode' => null];
    }

    /**
     * 使用 CAS 原子保存默认目标库、最低质量和硬大小上限。
     *
     * 目标库必须是 actor 实时可管理的 active 本地或受支持远程库；停用库和仅 read/write 授权均拒绝。固定
     * `importMode=move` 与部署目录是响应事实，若浏览器把它们混入命令则整次拒绝。设置行和审计在同一
     * 短事务提交，不创建目录或移动文件；上限范围固定为 16 MiB 至 4 GiB。
     */
    public function update(array $payload, array $actor, string $requestId): array
    {
        $keys = array_keys($payload);
        sort($keys);
        if ($keys !== ['expectedVersion', 'libraryId', 'maximumBytes', 'minimumQuality']
            || !is_string($payload['libraryId'] ?? null) || !is_string($payload['minimumQuality'] ?? null)
            || !is_int($payload['maximumBytes'] ?? null)
            || !is_int($payload['expectedVersion'] ?? null)
            || preg_match('/^[0-9A-HJKMNP-TV-Z]{26}$/D', $payload['libraryId']) !== 1
            || !in_array($payload['minimumQuality'], LxDownloadQualityPolicy::qualities(), true)
            || $payload['maximumBytes'] < 16_777_216 || $payload['maximumBytes'] > 4_294_967_296) {
            throw new LxDownloadSettingsInvalid();
        }
        return Db::transaction(function () use ($payload, $actor, $requestId): array {
            $before = $this->setting();
            if ($before['version'] !== $payload['expectedVersion']) throw new LxDownloadSettingsConflict();
            if (!$this->manageableWritableLibraryExists($payload['libraryId'], $actor)) {
                throw new LxDownloadSettingsInvalid();
            }
            $changed = Db::table('system_settings')->where('setting_key', self::KEY)
                ->where('version', $before['version'])->update([
                    'value_json' => json_encode(['libraryId' => $payload['libraryId'],
                        'minimumQuality' => $payload['minimumQuality'],
                        'maximumBytes' => $payload['maximumBytes']], JSON_THROW_ON_ERROR),
                    'version' => Db::raw('version + 1'), 'updated_by' => (string) $actor['id'],
                    'updated_at' => gmdate('Y-m-d\TH:i:s\Z'),
                ]);
            if ($changed !== 1) throw new LxDownloadSettingsConflict();
            $this->audit->record((string) $actor['id'], 'plugin.lx_music.download.update',
                'system_setting', self::KEY, 'success', $requestId, [
                    'libraryId' => $payload['libraryId'], 'minimumQuality' => $payload['minimumQuality'],
                    'maximumBytes' => $payload['maximumBytes'], 'importMode' => 'move',
                ]);
            return $this->snapshot();
        });
    }

    /** @return array{libraryId:?string,minimumQuality:string,maximumBytes:int,version:int,updatedAt:string} */
    private function setting(): array
    {
        $row = Db::table('system_settings')->where('setting_key', self::KEY)->first();
        if (!$row instanceof stdClass) throw new LxDownloadSettingsUnavailable();
        try {
            $value = json_decode((string) $row->value_json, true, 8, JSON_THROW_ON_ERROR);
        } catch (JsonException) {
            throw new LxDownloadSettingsUnavailable();
        }
        if (!is_array($value) || array_keys($value) !== ['libraryId', 'minimumQuality', 'maximumBytes']
            || (!is_string($value['libraryId']) && $value['libraryId'] !== null)
            || (is_string($value['libraryId'])
                && preg_match('/^[0-9A-HJKMNP-TV-Z]{26}$/D', $value['libraryId']) !== 1)
            || !is_string($value['minimumQuality']) || !is_int($value['maximumBytes'])
            || !in_array($value['minimumQuality'], LxDownloadQualityPolicy::qualities(), true)
            || $value['maximumBytes'] < 16_777_216 || $value['maximumBytes'] > 4_294_967_296) {
            throw new LxDownloadSettingsUnavailable();
        }
        return $value + ['version' => (int) $row->version, 'updatedAt' => (string) $row->updated_at];
    }

    /**
     * 验证目标库及 actor 的实时 manage 边界。
     *
     * 超级管理员可管理全部支持写入的 active 库；其他管理员必须具有显式 manage grant。查询不返回物理
     * 根或远端连接事实；实际上传前核心仍会复验协议和授权，避免撤权后继续用旧配置排队。
     */
    private function manageableWritableLibraryExists(string $libraryId, array $actor): bool
    {
        $query = Db::table('music_libraries as libraries')->where('libraries.id', $libraryId)
            ->where('libraries.status', 'active')
            ->whereIn('libraries.source_type', ['local', 'webdav', 'onedrive', 'google_drive']);
        if (!($actor['isSuperAdmin'] ?? false)) {
            $query->join('library_user_grants as grant', function ($join) use ($actor): void {
                $join->on('grant.library_id', '=', 'libraries.id')
                    ->where('grant.user_id', '=', (string) $actor['id'])
                    ->where('grant.access_level', '=', 'manage');
            });
        }
        return $query->exists();
    }
}

final class LxDownloadSettingsInvalid extends \InvalidArgumentException {}
final class LxDownloadSettingsConflict extends PhpResourcePluginOperationConflict {}
final class LxDownloadSettingsUnavailable extends \RuntimeException {}
