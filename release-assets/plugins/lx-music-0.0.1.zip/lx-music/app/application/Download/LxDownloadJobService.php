<?php

declare(strict_types=1);

namespace plugin\lx_music\app\application\Download;

use app\application\ResourcePlugin\PhpResourcePluginOperationConflict;
use app\infrastructure\Audit\AuditLogger;
use Illuminate\Database\QueryException;
use stdClass;
use Symfony\Component\Uid\Ulid;
use support\Db;

/**
 * LxDownloadJobService 创建和投影 LX Music 直链下载任务。
 *
 * 创建只消费当前 actor 的未过期租约，并使用服务端配置的 active 可写库；浏览器不能覆盖目标库、音质、
 * URL、来源 ID、请求头或物理路径。同一租约由唯一索引实现并发幂等，任务和审计在一个短事务提交，
 * 网络与文件副作用留给通用 Worker。任务列表排除所有密文、Worker 标识和请求 ID。
 */
final readonly class LxDownloadJobService
{
    /** @var list<string> 只含可通过重新解析或重新下载恢复、且不会跨过安全失败边界的终态错误。 */
    private const RETRYABLE_ERRORS = [
        'LX_SOURCE_UNAVAILABLE', 'LX_SOURCE_HTTP_FAILED',
        'LX_SCRIPT_RESOLVE_EMPTY', 'LX_SCRIPT_RESOLVE_INVALID', 'LX_SCRIPT_RESOLVE_ARRAY_INVALID',
        'LX_SCRIPT_RESOLVE_OBJECT_INVALID', 'LX_SCRIPT_RESOLVE_TYPE_INVALID', 'LX_SCRIPT_RESOLVE_TOO_LONG',
        'LX_SCRIPT_UPSTREAM_RESOLVE_FAILED', 'LX_SCRIPT_PROTOCOL_INVALID', 'LX_SCRIPT_RUNNER_FAILED',
        'LX_RUNNER_FAILED',
        'LX_SCRIPT_REQUEST_FAILED', 'LX_SCRIPT_REQUEST_TIMEOUT', 'LX_SCRIPT_RESOLVE_TIMEOUT',
        'LX_SCRIPT_UPSTREAM_SERVER_FAILED', 'LX_SCRIPT_UPSTREAM_RATE_LIMITED',
        'LX_SCRIPT_UPSTREAM_RESPONSE_INVALID', 'LX_SCRIPT_RUNNER_TIMEOUT',
        'LX_DOWNLOAD_HTTP_FAILED', 'LX_DOWNLOAD_NETWORK_FAILED', 'LX_DOWNLOAD_HOST_UNRESOLVED',
    ];

    public function __construct(
        private AuditLogger $audit = new AuditLogger(),
        private LxDownloadStorage $storage = new LxDownloadStorage(),
        private LxDownloadDiagnosticLogService $diagnostics = new LxDownloadDiagnosticLogService(),
    ) {
    }

    /** @return array{libraries:list<array{id:string,name:string}>,libraryId:?string,minimumQuality:string,qualities:list<string>,mode:string,importMode:string} */
    public function options(array $actor): array
    {
        $query = Db::table('music_libraries as libraries')->where('libraries.status', 'active')
            ->whereIn('libraries.source_type', ['local', 'webdav', 'onedrive', 'google_drive']);
        if (!($actor['isSuperAdmin'] ?? false)) {
            $query->join('library_user_grants as grant', function ($join) use ($actor): void {
                $join->on('grant.library_id', '=', 'libraries.id')->where('grant.user_id', '=', (string) $actor['id'])
                    ->where('grant.access_level', '=', 'manage');
            });
        }
        $libraries = $query->orderBy('libraries.name')->get(['libraries.id', 'libraries.name'])
            ->map(static fn (stdClass $row): array => ['id' => (string) $row->id, 'name' => (string) $row->name])->all();
        $settings = (new LxDownloadSettingsService())->snapshot();
        return ['libraries' => $libraries, 'libraryId' => $settings['libraryId'],
            'minimumQuality' => $settings['minimumQuality'],
            'qualities' => LxDownloadQualityPolicy::qualities(), 'mode' => 'direct_http',
            'importMode' => 'move'];
    }

    /**
     * 创建耐久任务；插件页面命令只需包含 leaseId。
     *
     * 目标库和最低质量来自服务端配置，页面不能在下载时覆盖。为保持核心统一下载 API 的既有合同，也
     * 接受 `leaseId|libraryId`，但该 libraryId 必须与配置完全一致，不能形成第二个选择入口。租约、actor、
     * 质量和目标库在同一事务复验；并发唯一冲突读取既有任务作为幂等成功。低于门槛时不访问来源、不
     * 创建任务或文件。
     */
    public function create(array $command, array $actor, string $requestId): array
    {
        $keys = array_keys($command);
        sort($keys);
        if (!in_array($keys, [['leaseId'], ['leaseId', 'libraryId']], true)
            || !is_string($command['leaseId'] ?? null)
            || (array_key_exists('libraryId', $command) && !is_string($command['libraryId']))) {
            throw new LxDownloadInvalid();
        }
        $leaseId = $command['leaseId'];
        if (preg_match('/^[0-9A-HJKMNP-TV-Z]{26}$/D', $leaseId) !== 1) throw new LxDownloadInvalid();
        $jobId = (string) new Ulid();
        $now = gmdate('Y-m-d\TH:i:s\Z');
        try {
            return Db::transaction(function () use ($command, $leaseId, $actor, $requestId, $jobId, $now): array {
                $existing = Db::table('lx_music_download_jobs')->where('search_lease_id', $leaseId)->value('id');
                if (is_string($existing)) return $this->find($existing);
                $settings = (new LxDownloadSettingsService())->snapshot();
                $libraryId = $settings['libraryId'];
                if (!is_string($libraryId)) throw new LxDownloadConfigurationRequired();
                if (isset($command['libraryId']) && $command['libraryId'] !== $libraryId) {
                    throw new LxDownloadInvalid();
                }
                /** @var stdClass|null $lease */
                $lease = Db::table('lx_music_search_leases')->where('id', $leaseId)
                    ->where('actor_id', (string) $actor['id'])->where('expires_at', '>=', $now)->first();
                if (!$lease instanceof stdClass || !$this->manageableWritableLibraryExists($libraryId, $actor)) {
                    throw new LxDownloadNotFound();
                }
                if (!LxDownloadQualityPolicy::accepts((string) $lease->quality, $settings['minimumQuality'])) {
                    throw new LxDownloadQualityRejected();
                }
                Db::table('lx_music_download_jobs')->insert([
                    'id' => $jobId, 'search_lease_id' => $leaseId, 'requested_by' => (string) $actor['id'],
                    'library_id' => $libraryId, 'source_key' => (string) $lease->source_key,
                    'title' => (string) $lease->title, 'artist' => (string) $lease->artist,
                    'album' => (string) $lease->album, 'quality' => (string) $lease->quality,
                    'format' => (string) $lease->format, 'expected_size_bytes' => $lease->size_bytes,
                    'metadata_json' => json_encode($this->basicMetadata($lease),
                        JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                    'status' => 'queued', 'reference_ciphertext' => (string) $lease->reference_ciphertext,
                    'resolved_ciphertext' => null, 'downloaded_bytes' => 0, 'total_bytes' => 0,
                    'progress_basis_points' => 0, 'imported_files' => 0, 'scan_job_id' => null,
                    'error_code' => null, 'worker_id' => null, 'attempt' => 0, 'heartbeat_at' => null,
                    'request_id' => $requestId, 'started_at' => null, 'finished_at' => null,
                    'created_at' => $now, 'updated_at' => $now,
                ]);
                $this->audit->record((string) $actor['id'], 'plugin.lx_music.download.queue',
                    'lx_music_download_job', $jobId, 'success', $requestId,
                    ['libraryId' => $libraryId, 'sourceKey' => (string) $lease->source_key,
                        'quality' => (string) $lease->quality]);
                $this->diagnostics->record($jobId, (string) $lease->source_key, null,
                    (string) $lease->quality, 'info', 'LX_DOWNLOAD_QUEUED', 'queue', [], $requestId);
                return $this->find($jobId);
            });
        } catch (QueryException $exception) {
            if (str_contains(strtolower($exception->getMessage()), 'unique')) {
                $existing = Db::table('lx_music_download_jobs')->where('search_lease_id', $leaseId)->value('id');
                if (is_string($existing)) return $this->find($existing);
            }
            throw $exception;
        }
    }

    /** @return array{jobs:list<array<string,mixed>>} */
    public function list(int $limit = 50): array
    {
        $rows = $this->query()->orderByDesc('jobs.created_at')->limit(max(1, min(100, $limit)))
            ->get($this->columns())->all();
        return ['jobs' => array_map(fn (stdClass $row): array => $this->map($row), $rows)];
    }

    /** @return array<string,mixed> */
    public function find(string $jobId): array
    {
        $row = $this->query()->where('jobs.id', $jobId)->first($this->columns());
        if (!$row instanceof stdClass) throw new LxDownloadNotFound();
        return $this->map($row);
    }

    /**
     * 按当前管理员可管理的本地或受支持远程库范围读取一个任务。
     *
     * 补全状态端点只持有不透明 taskId，仍不能据此绕过库授权读取其他任务。任务不存在、库已停用、改为
     * 库停用、来源类型不支持或 manage 授权被撤销时统一表现为不存在；方法只读数据库，不恢复任务或访问媒体文件。
     *
     * @param array<string,mixed> $actor
     * @return array<string,mixed>
     */
    public function findForActor(string $jobId, array $actor): array
    {
        if (preg_match('/^[0-9A-HJKMNP-TV-Z]{26}$/D', $jobId) !== 1) throw new LxDownloadNotFound();
        $job = $this->find($jobId);
        $libraryId = $job['library']['id'] ?? null;
        if (!is_string($libraryId) || !$this->manageableWritableLibraryExists($libraryId, $actor)) {
            throw new LxDownloadNotFound();
        }
        return $job;
    }

    /**
     * 重新排队一个仍持有完整服务端引用的可恢复失败任务。
     *
     * 前置条件：当前 actor 仍可管理目标 active 可写库，任务处于 failed，错误属于网络、脚本解析或临时
     * 上游失败白名单，且引用密文未被成功流程清除。文件事务无法并入 SQLite，因此先按任务 ULID 和
     * 所有权标记清理自己的 staging，再在短事务中用 `status=failed` CAS 重排；清理失败时数据库完全
     * 不变。并发重试最多一个请求提交，另一个得到冲突。attempt 重置后 Worker 重新解析临时 URL，绝不
     * 复用旧 resolved 密文，也不覆盖已经发布的媒体。权限、安全、媒体伪装和发布阶段错误不可重试。
     */
    public function retry(string $jobId, array $actor, string $requestId): array
    {
        if (preg_match('/^[0-9A-HJKMNP-TV-Z]{26}$/D', $jobId) !== 1) throw new LxDownloadInvalid();
        /** @var stdClass|null $row */
        $row = Db::table('lx_music_download_jobs as jobs')
            ->join('music_libraries as libraries', 'libraries.id', '=', 'jobs.library_id')
            ->where('jobs.id', $jobId)->first([
                'jobs.id', 'jobs.status', 'jobs.error_code', 'jobs.reference_ciphertext', 'jobs.library_id',
                'jobs.source_key', 'jobs.quality',
            ]);
        if (!$row instanceof stdClass || !$this->manageableWritableLibraryExists((string) $row->library_id, $actor)) {
            throw new LxDownloadNotFound();
        }
        if ((string) $row->status !== 'failed' || !is_string($row->reference_ciphertext)
            || !self::retryableError($row->error_code)) throw new LxDownloadConflict();
        $this->storage->cleanup($jobId);
        Db::transaction(function () use ($row, $actor, $requestId): void {
            $now = gmdate('Y-m-d\TH:i:s\Z');
            $changed = Db::table('lx_music_download_jobs')->where('id', (string) $row->id)
                ->where('status', 'failed')->where('error_code', (string) $row->error_code)->update([
                    'status' => 'queued', 'resolved_ciphertext' => null, 'downloaded_bytes' => 0,
                    'total_bytes' => 0, 'progress_basis_points' => 0, 'imported_files' => 0,
                    'scan_job_id' => null, 'error_code' => null, 'worker_id' => null, 'attempt' => 0,
                    'heartbeat_at' => null, 'request_id' => $requestId, 'started_at' => null,
                    'finished_at' => null, 'updated_at' => $now,
                ]);
            if ($changed !== 1) throw new LxDownloadConflict();
            $this->audit->record((string) $actor['id'], 'plugin.lx_music.download.retry',
                'lx_music_download_job', (string) $row->id, 'success', $requestId, [
                    'libraryId' => (string) $row->library_id, 'sourceKey' => (string) $row->source_key,
                    'quality' => (string) $row->quality, 'previousErrorCode' => (string) $row->error_code,
                ]);
            $this->diagnostics->record((string) $row->id, (string) $row->source_key, null,
                (string) $row->quality, 'info', 'LX_DOWNLOAD_MANUAL_RETRY', 'retry', [
                    'automaticRetry' => false, 'attempt' => 0,
                ], $requestId);
        });
        return $this->find($jobId);
    }

    /**
     * 清理单条终态任务记录、其级联诊断和不再被引用的搜索租约。
     *
     * 前置条件是 actor 仍可管理目标 active 可写库，且任务精确处于 succeeded 或 failed。文件清理先按
     * 音乐库真实根、任务 ULID 和所有权标记执行；未知文件、链接或标记不匹配时数据库不变。随后短事务
     * 使用原终态 CAS 删除任务，由外键级联删除其诊断，再删除明确的搜索租约并写核心审计。成功发布的
     * 媒体已脱离 staging，扫描任务属于核心事实，两者都不会被本操作删除；并发状态变化整体回滚。
     */
    public function clear(string $jobId, array $actor, string $requestId): array
    {
        if (preg_match('/^[0-9A-HJKMNP-TV-Z]{26}$/D', $jobId) !== 1) throw new LxDownloadInvalid();
        /** @var stdClass|null $row */
        $row = Db::table('lx_music_download_jobs as jobs')
            ->join('music_libraries as libraries', 'libraries.id', '=', 'jobs.library_id')
            ->where('jobs.id', $jobId)->first([
                'jobs.id', 'jobs.status', 'jobs.search_lease_id', 'jobs.library_id', 'jobs.source_key',
                'jobs.quality',
            ]);
        if (!$row instanceof stdClass || !$this->manageableWritableLibraryExists((string) $row->library_id, $actor)) {
            throw new LxDownloadNotFound();
        }
        if (!in_array((string) $row->status, ['succeeded', 'failed'], true)) throw new LxDownloadConflict();

        $this->storage->cleanup($jobId);
        return Db::transaction(function () use ($row, $actor, $requestId): array {
            $deleted = Db::table('lx_music_download_jobs')->where('id', (string) $row->id)
                ->where('status', (string) $row->status)->delete();
            if ($deleted !== 1) throw new LxDownloadConflict();
            Db::table('lx_music_search_leases')->where('id', (string) $row->search_lease_id)->delete();
            $this->audit->record((string) $actor['id'], 'plugin.lx_music.download.clear',
                'lx_music_download_job', (string) $row->id, 'success', $requestId, [
                    'libraryId' => (string) $row->library_id, 'sourceKey' => (string) $row->source_key,
                    'quality' => (string) $row->quality, 'previousStatus' => (string) $row->status,
                    'publishedMediaDeleted' => false,
                ]);
            return ['id' => (string) $row->id, 'cleared' => true, 'publishedMediaDeleted' => false];
        });
    }

    /**
     * 清理当前管理员可管理的本地或受支持远程库中的全部终态下载记录。
     *
     * 查询只收集 succeeded/failed，活动任务始终保留以免 Worker 继续持有已删除事实。文件清理发生在
     * 数据库事务外，并复用同一任务存储的所有权校验；任一暂存异常都会停止且不提交数据库删除。随后
     * 短事务按原状态 CAS 删除任务、级联诊断和明确无引用的搜索租约，已发布媒体、核心扫描记录和审计
     * 永不删除；重复执行只会看到剩余任务，因而具备幂等终态语义。
     *
     * @return array{deletedCount:int,activeCount:int}
     */
    public function clearAll(array $actor, string $requestId): array
    {
        $rows = $this->query()
            ->whereIn('jobs.status', ['succeeded', 'failed'])
            ->orderBy('jobs.created_at')->get([
                'jobs.id', 'jobs.status', 'jobs.search_lease_id', 'jobs.library_id',
                'jobs.source_key', 'jobs.quality',
            ])->filter(fn (stdClass $row): bool => $this->manageableWritableLibraryExists((string) $row->library_id, $actor))
            ->values()->all();
        $activeCount = $this->query()->whereNotIn('jobs.status', ['succeeded', 'failed'])
            ->get(['jobs.id', 'jobs.library_id'])
            ->filter(fn (stdClass $row): bool => $this->manageableWritableLibraryExists((string) $row->library_id, $actor))
            ->count();

        // 暂存文件不允许在 SQLite 事务中操作；所有权校验失败时不改变任何任务行。
        foreach ($rows as $row) {
            $this->storage->cleanup((string) $row->id);
        }

        $deletedCount = Db::transaction(function () use ($rows, $actor, $requestId): int {
            $count = 0;
            foreach ($rows as $row) {
                $deleted = Db::table('lx_music_download_jobs')->where('id', (string) $row->id)
                    ->where('status', (string) $row->status)->delete();
                if ($deleted !== 1) throw new LxDownloadConflict();
                Db::table('lx_music_search_leases')->where('id', (string) $row->search_lease_id)->delete();
                $this->audit->record((string) $actor['id'], 'plugin.lx_music.download.clear',
                    'lx_music_download_job', (string) $row->id, 'success', $requestId, [
                        'libraryId' => (string) $row->library_id, 'sourceKey' => (string) $row->source_key,
                        'quality' => (string) $row->quality, 'previousStatus' => (string) $row->status,
                        'publishedMediaDeleted' => false, 'bulk' => true,
                    ]);
                $count++;
            }
            return $count;
        });

        return ['deletedCount' => $deletedCount, 'activeCount' => $activeCount];
    }

    /** 复验 active 库类型与 manage 授权；上传凭据由核心发布器在 Worker 阶段单独读取。 */
    private function manageableWritableLibraryExists(string $libraryId, array $actor): bool
    {
        $query = Db::table('music_libraries as libraries')->where('libraries.id', $libraryId)
            ->where('libraries.status', 'active')
            ->whereIn('libraries.source_type', ['local', 'webdav', 'onedrive', 'google_drive']);
        if (!($actor['isSuperAdmin'] ?? false)) {
            $query->join('library_user_grants as grant', function ($join) use ($actor): void {
                $join->on('grant.library_id', '=', 'libraries.id')->where('grant.user_id', '=', (string) $actor['id'])
                    ->where('grant.access_level', '=', 'manage');
            });
        }
        return $query->exists();
    }

    private function query()
    {
        return Db::table('lx_music_download_jobs as jobs')
            ->join('music_libraries as libraries', 'libraries.id', '=', 'jobs.library_id');
    }

    /** @return list<string> */
    private function columns(): array
    {
        return ['jobs.id', 'jobs.title', 'jobs.artist', 'jobs.album', 'jobs.source_key', 'jobs.quality',
            'jobs.format', 'jobs.status', 'jobs.downloaded_bytes', 'jobs.total_bytes', 'jobs.progress_basis_points',
            'jobs.imported_files', 'jobs.scan_job_id', 'jobs.error_code', 'jobs.created_at', 'jobs.updated_at',
            'jobs.finished_at', 'jobs.metadata_json', 'libraries.id as library_id', 'libraries.name as library_name'];
    }

    private function map(stdClass $row): array
    {
        $metadata = [];
        try {
            $decoded = json_decode((string) $row->metadata_json, true, 24, JSON_THROW_ON_ERROR);
            if (is_array($decoded)) $metadata = $decoded;
        } catch (\JsonException) {
            // 历史损坏快照不向管理页面投影猜测数据；Worker 会在发布前失败关闭或重建基础字段。
        }
        $artwork = is_array($metadata['artwork'] ?? null) ? $metadata['artwork'] : [];
        $lyrics = is_array($metadata['lyrics'] ?? null) ? $metadata['lyrics'] : [];
        return ['id' => (string) $row->id, 'title' => (string) $row->title, 'artist' => (string) $row->artist,
            'album' => (string) $row->album, 'source' => (string) $row->source_key,
            'quality' => (string) $row->quality, 'format' => (string) $row->format,
            'library' => ['id' => (string) $row->library_id, 'name' => (string) $row->library_name],
            'status' => (string) $row->status, 'progress' => (int) $row->progress_basis_points / 100,
            'downloadedBytes' => (int) $row->downloaded_bytes, 'totalBytes' => (int) $row->total_bytes,
            'importedFiles' => (int) $row->imported_files,
            'scanJobId' => $row->scan_job_id === null ? null : (string) $row->scan_job_id,
            'errorCode' => $row->error_code === null ? null : (string) $row->error_code,
            'metadata' => [
                'written' => (bool) ($metadata['written'] ?? false),
                'artworkAvailable' => (bool) ($artwork['available'] ?? false),
                'artworkEmbedded' => (bool) ($artwork['embedded'] ?? false),
                'lyricsAvailable' => (bool) ($lyrics['available'] ?? false),
                'lyricsEmbedded' => (bool) ($lyrics['embedded'] ?? false),
            ],
            'retryable' => (string) $row->status === 'failed' && self::retryableError($row->error_code),
            'createdAt' => (string) $row->created_at, 'updatedAt' => (string) $row->updated_at,
            'finishedAt' => $row->finished_at === null ? null : (string) $row->finished_at];
    }

    /**
     * 从搜索租约冻结下载任务的最小版本化元数据快照。
     *
     * 租约字段已经通过 Helper 和搜索服务校验；这里只把标题、艺人、专辑转换为标签领域结构，不读取
     * musicInfo 密文，也不请求第三方。歌词与封面初始为不可用，Worker 解析脚本动作后更新同一快照。
     * 空艺人或专辑保持空值，不能用文件名或平台名冒充元数据事实。
     */
    private function basicMetadata(stdClass $lease): array
    {
        $artist = trim((string) $lease->artist);
        return [
            'schemaVersion' => 1, 'title' => trim((string) $lease->title),
            'artists' => $artist === '' ? [] : [$artist],
            'albumTitle' => trim((string) $lease->album),
            'albumArtists' => $artist === '' ? [] : [$artist],
            'written' => false,
            'artwork' => ['available' => false, 'embedded' => false, 'mimeType' => null],
            'lyrics' => ['available' => false, 'embedded' => false, 'kind' => null, 'content' => null],
        ];
    }

    private static function retryableError(mixed $errorCode): bool
    {
        return is_string($errorCode) && in_array($errorCode, self::RETRYABLE_ERRORS, true);
    }
}

final class LxDownloadInvalid extends \InvalidArgumentException {}
final class LxDownloadConfigurationRequired extends \InvalidArgumentException {}
final class LxDownloadQualityRejected extends \InvalidArgumentException {}
final class LxDownloadNotFound extends \RuntimeException {}
final class LxDownloadConflict extends PhpResourcePluginOperationConflict {}
