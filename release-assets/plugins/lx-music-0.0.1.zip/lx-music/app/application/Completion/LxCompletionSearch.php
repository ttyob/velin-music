<?php

declare(strict_types=1);

namespace plugin\lx_music\app\application\Completion;

/**
 * LxCompletionSearch 隔离歌单补全对 LX 搜索实现的最小依赖。
 *
 * 生产实现必须返回已经签发 actor 租约、按来源权重排序并聚合同曲渠道的结果；接口只供插件内部补全
 * 服务消费，不能把候选或租约透传给主程序。搜索失败原样抛出，由补全边界压缩为稳定错误；本接口不
 * 创建下载任务、文件或日志。
 */
interface LxCompletionSearch
{
    /**
     * 使用当前 actor 搜索候选并签发短期租约。
     *
     * @return array{query:string,total:int,limited:bool,items:list<array<string,mixed>>}
     */
    public function search(string $query, int $limit, string $actorId): array;
}
