<?php

declare(strict_types=1);

namespace plugin\lx_music\app\application\Completion;

use app\application\Scrape\ChineseQueryVariantNormalizer;
use plugin\lx_music\app\application\Download\LxDownloadDiagnosticLogService;
use plugin\lx_music\app\application\Download\LxDownloadJobService;
use plugin\lx_music\app\application\Download\LxDownloadNotFound;
use plugin\lx_music\app\application\Search\LxSearchService;
use Throwable;

/**
 * LxMusicCompletionService 把核心传入的歌曲身份收敛为一个 LX 下载任务。
 *
 * 搜索候选、渠道租约和平台引用只在插件边界内使用。标题和艺人必须严格匹配，调用方提供专辑时专辑
 * 也必须匹配；随后按 LX 已确定的权重、历史成功次数和音质顺序尝试可下载渠道。accepted 只表示任务
 * 已耐久排队，只有原下载任务发布成功后 status 才返回 succeeded。该服务不建立第二套补全记录，因此
 * 重试次数、错误和日志始终归属唯一下载任务。
 */
final readonly class LxMusicCompletionService
{
    public function __construct(
        private LxCompletionSearch $search = new LxSearchService(),
        private LxDownloadJobService $downloads = new LxDownloadJobService(),
        private LxDownloadDiagnosticLogService $diagnostics = new LxDownloadDiagnosticLogService(),
        private ChineseQueryVariantNormalizer $identityNormalizer = new ChineseQueryVariantNormalizer(),
    ) {
    }

    /**
     * 严格匹配歌曲身份并创建一个插件下载任务。
     *
     * 请求只能包含 title、artist、可选 album 和目标 libraryId；actor、库和租约均使用 ULID。输入及候选
     * 会先通过主程序固定 OpenCC 转为简体，转换工具不可用时保持原文。搜索最多取 30 个聚合结果，每个
     * 候选只尝试服务端签发的租约；单渠道失效时继续同一身份的下一渠道，全部失败后返回稳定错误。方法
     * 不下载音频正文，也不向核心返回搜索列表、租约、URL、平台 ID 或脚本信息。
     *
     * @param array<string,mixed> $request
     * @param array<string,mixed> $actor
     * @return array{taskId:string,accepted:true,status:'queued'|'running',progress:int}
     */
    public function complete(array $request, array $actor, string $requestId): array
    {
        $keys = array_keys($request);
        sort($keys);
        if (!in_array($keys, [['album', 'artist', 'libraryId', 'title'], ['artist', 'libraryId', 'title']], true)
            || !$this->text($request['title'] ?? null, 1, 500)
            || !$this->text($request['artist'] ?? null, 1, 500)
            || (array_key_exists('album', $request) && $request['album'] !== null
                && !$this->text($request['album'], 1, 500))
            || !$this->ulid($request['libraryId'] ?? null)
            || !$this->ulid($actor['id'] ?? null)
            || $requestId === '' || strlen($requestId) > 128) {
            throw new LxMusicCompletionInvalid();
        }

        $title = trim((string) $request['title']);
        $artist = trim((string) $request['artist']);
        $album = isset($request['album']) && $request['album'] !== null ? trim((string) $request['album']) : null;
        $identityInput = [['title' => $title, 'artist' => $artist, 'album' => $album ?? '']];
        $convertedIdentity = $this->identityNormalizer->simplify($identityInput)[0] ?? $identityInput[0];
        $identity = is_array($convertedIdentity) ? $convertedIdentity : $identityInput[0];
        $title = is_string($identity['title'] ?? null) ? trim($identity['title']) : $title;
        $artist = is_string($identity['artist'] ?? null) ? trim($identity['artist']) : $artist;
        $album = is_string($identity['album'] ?? null) && trim($identity['album']) !== ''
            ? trim($identity['album']) : $album;

        $query = trim($title . ' ' . $artist . ($album === null ? '' : ' ' . $album));
        $result = $this->search->search($query, 30, (string) $actor['id']);
        $items = [];
        $candidateIdentities = [];
        foreach ($result['items'] ?? [] as $item) {
            if (!is_array($item)) continue;
            $items[] = $item;
            $candidateIdentities[] = [
                'title' => is_string($item['title'] ?? null) ? $item['title'] : '',
                'artist' => is_string($item['artist'] ?? null) ? $item['artist'] : '',
                'album' => is_string($item['album'] ?? null) ? $item['album'] : '',
            ];
        }
        $convertedCandidates = [];
        foreach (array_chunk($candidateIdentities, 4) as $batch) {
            $convertedCandidates = [...$convertedCandidates, ...$this->identityNormalizer->simplify($batch)];
        }

        foreach ($items as $index => $item) {
            $candidate = $convertedCandidates[$index] ?? [];
            if (!$this->same($candidate['title'] ?? null, $title)
                || !$this->same($candidate['artist'] ?? null, $artist)
                || ($album !== null && !$this->same($candidate['album'] ?? null, $album))) {
                continue;
            }
            $leases = [];
            if (is_string($item['id'] ?? null) && ($item['downloadable'] ?? false) === true) {
                $leases[] = $item['id'];
            }
            foreach ($item['channels'] ?? [] as $channel) {
                if (is_array($channel) && ($channel['downloadable'] ?? false) === true
                    && is_string($channel['leaseId'] ?? null)) {
                    $leases[] = $channel['leaseId'];
                }
            }
            foreach (array_values(array_unique($leases)) as $leaseId) {
                try {
                    $job = $this->downloads->create([
                        'leaseId' => $leaseId,
                        'libraryId' => (string) $request['libraryId'],
                    ], $actor, $requestId);
                    $taskId = $job['id'] ?? null;
                    if (!$this->ulid($taskId)) continue;
                    return ['taskId' => $taskId, 'accepted' => true, 'status' => 'queued', 'progress' => 0];
                } catch (Throwable) {
                    // 同一严格身份的单渠道失效不泄漏具体原因，继续尝试下一条服务端租约。
                }
            }
        }
        throw new LxMusicCompletionFailed('LX_COMPLETION_NO_EXACT_MATCH');
    }

    /**
     * 返回唯一下载任务的最终一致状态和该任务自己的脱敏日志。
     *
     * 只有下载表 succeeded 才表示歌曲已经发布；排队、解析、下载和发布中统一映射为 running。任务不存在
     * 或无权读取时返回稳定 failed，不泄漏其他任务是否存在；查询不修改任务、日志或媒体文件。
     *
     * @param array<string,mixed> $actor
     * @return array{taskId:string,status:'queued'|'running'|'succeeded'|'failed',progress:int,errorCode:?string,logs:list<array<string,mixed>>}
     */
    public function status(string $taskId, array $actor): array
    {
        if (!$this->ulid($taskId) || !$this->ulid($actor['id'] ?? null)) {
            throw new LxMusicCompletionInvalid();
        }
        try {
            $job = $this->downloads->findForActor($taskId, $actor);
        } catch (LxDownloadNotFound) {
            return ['taskId' => $taskId, 'status' => 'failed', 'progress' => 0,
                'errorCode' => 'LX_COMPLETION_TASK_NOT_FOUND', 'logs' => []];
        }
        $state = match ((string) ($job['status'] ?? '')) {
            'succeeded' => 'succeeded',
            'failed' => 'failed',
            default => 'running',
        };
        return [
            'taskId' => $taskId,
            'status' => $state,
            'progress' => max(0, min(100, (int) ($job['progress'] ?? 0))),
            'errorCode' => $state === 'failed' ? ($job['errorCode'] ?? 'LX_COMPLETION_FAILED') : null,
            'logs' => $this->diagnostics->listForJob($taskId, 50)['logs'],
        ];
    }

    private function same(mixed $left, string $right): bool
    {
        return is_string($left) && $this->normalize($left) !== ''
            && $this->normalize($left) === $this->normalize($right);
    }

    private function normalize(string $value): string
    {
        $value = trim($value);
        if (class_exists('Normalizer')) $value = \Normalizer::normalize($value, \Normalizer::FORM_KC) ?: $value;
        $value = mb_strtolower($value, 'UTF-8');
        return preg_replace('/\s+/u', ' ', $value) ?? $value;
    }

    private function text(mixed $value, int $minimum, int $maximum): bool
    {
        return is_string($value) && mb_check_encoding($value, 'UTF-8')
            && mb_strlen(trim($value), 'UTF-8') >= $minimum
            && mb_strlen(trim($value), 'UTF-8') <= $maximum
            && preg_match('/[\x00-\x1F\x7F]/u', $value) !== 1;
    }

    private function ulid(mixed $value): bool
    {
        return is_string($value) && preg_match('/^[0-9A-HJKMNP-TV-Z]{26}$/D', $value) === 1;
    }
}

final class LxMusicCompletionInvalid extends \InvalidArgumentException {}
final class LxMusicCompletionFailed extends \RuntimeException {}
