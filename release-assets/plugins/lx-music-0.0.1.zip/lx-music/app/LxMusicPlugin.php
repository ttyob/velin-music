<?php

declare(strict_types=1);

namespace plugin\lx_music\app;

use app\application\ResourcePlugin\Contract\ExternalMusicCompletionHook;
use app\application\ResourcePlugin\Contract\BulkDownloadCleanupHook;
use app\application\ResourcePlugin\Contract\TypedExternalMusicSearchHook;
use app\application\ResourcePlugin\Contract\PluginDatabaseLifecycle;
use app\application\ResourcePlugin\Contract\PluginDatabaseBaselineCollapse;
use app\application\ResourcePlugin\Contract\PluginWorkerHook;
use app\application\ResourcePlugin\Contract\PluginTranscodeWorkerHook;
use app\application\ResourcePlugin\Contract\RetryableExternalDownloadHook;
use plugin\lx_music\app\application\Completion\LxMusicCompletionService;
use plugin\lx_music\app\application\Download\LxDownloadJobService;
use plugin\lx_music\app\application\Download\LxDownloadDiagnosticLogService;
use plugin\lx_music\app\application\Download\LxDownloadSettingsService;
use plugin\lx_music\app\application\Download\LxDownloadWorkerService;
use plugin\lx_music\app\application\Search\LxSearchService;
use plugin\lx_music\app\application\Source\LxSourceSettingsService;
use support\Db;

/**
 * LxMusicPlugin 是 LX Music 0.0.1 基线包，装配插件自有聚合搜索、歌单补全、渠道租约和本地/远程受控入库。
 *
 * 搜索由插件包自带 Helper 的固定平台适配器完成并输出 LX musicInfo，不依赖主程序 Helper；管理员配置的
 * LX API v2 脚本只在独立 Node runner 中解析 musicUrl。搜索结果先转为 actor 绑定的加密租约，浏览器不能
 * 获得平台 ID、完整 musicInfo、音频 URL或脚本响应。Worker 下载到核心分配的插件媒体临时库，完成校验
 * 后非覆盖原子发布到目标库并触发增量扫描。卸载删除插件配置、租约和任务，但不删除已发布媒体或核心
 * 扫描历史。
 * 历史包版本已经折叠；以后升级只依赖 databaseVersion 账本和本类中的幂等迁移，不依赖旧 PHP 入口类。
 */
final readonly class LxMusicPlugin implements TypedExternalMusicSearchHook, ExternalMusicCompletionHook, BulkDownloadCleanupHook, PluginWorkerHook, PluginTranscodeWorkerHook, PluginDatabaseBaselineCollapse
{
    public function descriptor(): array
    {
        return [
            'key' => 'lx-music',
            'name' => 'LX Music',
            'version' => '0.0.1',
            'capabilities' => ['admin_page_search', 'admin_page_download', 'external_music_completion',
                'worker', 'transcode_worker', 'database_lifecycle'],
            'description' => '通过插件自带 Helper 搜索平台，由 LX API v2 脚本解析地址并安全下载入库。',
        ];
    }

    public function probe(): array
    {
        $status = $this->searchStatus();
        return ['available' => ($status['available'] ?? false) === true,
            'errorCode' => $status['errorCode'] ?? null];
    }

    public function searchStatus(): array { return (new LxSearchService())->status(); }

    public function searchConfiguration(): array { return (new LxSourceSettingsService())->snapshot(); }

    public function updateSearchConfiguration(array $payload, array $actor, string $requestId): array
    {
        return (new LxSourceSettingsService())->update($payload, (string) $actor['id'], $requestId);
    }

    public function search(string $query, int $limit, string $actorId): array
    {
        return (new LxSearchService())->search($query, $limit, $actorId);
    }

    /** LX 平台适配器只返回可单曲解析和下载的 musicInfo，不把专辑页面伪装成可下载专辑资源。 */
    public function searchTypes(): array { return ['track']; }

    /**
     * 接受核心已经授权的歌曲身份并在插件内部创建唯一下载任务。
     *
     * 核心不会获得搜索候选、渠道租约或平台引用；返回 accepted 只代表排队，媒体是否发布必须继续读取
     * completionStatus。目标库和调用者权限仍由下载任务服务实时复验。
     */
    public function completeMusic(array $request, array $actor, string $requestId): array
    {
        return (new LxMusicCompletionService())->complete($request, $actor, $requestId);
    }

    /** 返回补全所复用下载任务的终态和该任务自己的脱敏日志，只有 succeeded 表示真正入库。 */
    public function completionStatus(string $taskId, array $actor): array
    {
        return (new LxMusicCompletionService())->status($taskId, $actor);
    }

    /**
     * 执行明确的单曲搜索。
     *
     * 专辑请求在任何上游访问和租约写入前失败关闭；核心正常情况下已按 searchTypes 过滤，这里重复校验
     * 以保护插件自有调用方。结果逐条标注 track，不能由标题或 album 文本改变资源语义。
     */
    public function searchTyped(string $resourceType, string $query, int $limit, string $actorId): array
    {
        if ($resourceType !== 'track') throw new \InvalidArgumentException('LX_SEARCH_TYPE_UNSUPPORTED');
        $result = $this->search($query, $limit, $actorId);
        $result['resourceType'] = 'track';
        $result['items'] = array_map(static fn (array $item): array => $item + ['resourceType' => 'track'], $result['items']);
        return $result;
    }

    public function downloadStatus(): array { return (new LxDownloadSettingsService())->status(); }

    public function downloadConfiguration(): array { return (new LxDownloadSettingsService())->snapshot(); }

    public function updateDownloadConfiguration(array $payload, array $actor, string $requestId): array
    {
        return (new LxDownloadSettingsService())->update($payload, $actor, $requestId);
    }

    public function downloadOptions(array $actor): array { return (new LxDownloadJobService())->options($actor); }

    public function createDownload(array $command, array $actor, string $requestId): array
    {
        return (new LxDownloadJobService())->create($command, $actor, $requestId);
    }

    public function downloadJobs(int $limit = 50): array { return (new LxDownloadJobService())->list($limit); }

    /**
     * 复用插件保存的服务器端引用重试一个明确可恢复的失败任务。
     *
     * 核心已经验证 Session、系统管理权限和 CSRF；任务服务仍会复验目标库 manage 权限、失败分类及
     * 暂存所有权。浏览器只能提供任务 ID，不能替换 URL、音质、目标库或搜索证据。
     */
    public function retryDownload(string $jobId, array $actor, string $requestId): array
    {
        return (new LxDownloadJobService())->retry($jobId, $actor, $requestId);
    }

    public function downloadDiagnosticLogs(int $limit = 100): array
    {
        return (new LxDownloadDiagnosticLogService())->list($limit);
    }

    public function clearDownloadDiagnosticLogs(array $actor, string $requestId): array
    {
        return (new LxDownloadDiagnosticLogService())->clear($actor, $requestId);
    }

    public function clearDownloadDiagnosticLog(string $logId, array $actor, string $requestId): array
    {
        return (new LxDownloadDiagnosticLogService())->clearOne($logId, $actor, $requestId);
    }

    public function clearDownloadJob(string $jobId, array $actor, string $requestId): array
    {
        return (new LxDownloadJobService())->clear($jobId, $actor, $requestId);
    }

    /**
     * 清理当前管理员可管理的本地或受支持远程库中的全部终态下载记录。
     *
     * 核心只负责校验管理员 Session 和空请求体；插件服务继续复验每个库的 manage 权限、任务终态及
     * 暂存所有权。活动任务、已发布媒体、扫描记录和审计不属于下载记录清理范围，任何暂存校验或并发
     * 状态冲突都必须让数据库删除事务回滚，不能为了批量操作扩大文件删除边界。
     */
    public function clearDownloadJobs(array $actor, string $requestId): array
    {
        return (new LxDownloadJobService())->clearAll($actor, $requestId);
    }

    /**
     * 让核心资源 Worker 依次消费到期的来源健康检查和下载任务。
     *
     * 先以本地账本判断是否有到期源，只有到期时才让批量 init 检测占用本轮单步配额，避免持续下载队列
     * 让健康检查饥饿。健康检测只写插件自己的状态表，不改变下载任务、扫描任务或主程序的失败语义。
     * 即使检测抛出来源网络异常，也应由健康服务收敛为状态，不能让核心 Worker 误判插件进程故障。
     */
    public function processNext(string $workerId): bool
    {
        $health = new \plugin\lx_music\app\application\Source\LxSourceHealthService();
        if ($health->hasDue()) return $health->processDue();
        return (new LxDownloadWorkerService())->processNext($workerId);
    }

    /** 将已完成下载交给独立发布/转码 Worker，避免来源轮询被媒体发布阻塞。 */
    public function processTranscodeNext(string $workerId): bool
    {
        return (new LxDownloadWorkerService())->processTranscodeNext($workerId);
    }

    public function databaseVersion(): int { return 1; }

    /** 历史 1-8 账本都已验证可由最终基线幂等接管；未来账本必须继续失败关闭。 */
    public function supportsLegacyDatabaseVersion(int $fromVersion): bool
    {
        return $fromVersion >= 0 && $fromVersion <= 8;
    }

    /**
     * 创建 LX Music 插件的独占 schema 和默认关闭配置。
     *
     * 方法仅在核心开启的短 DDL 事务中执行，不访问网络和文件系统。fromVersion 只能为 0 或当前版本；
     * 重复安装依赖核心账本幂等返回，不覆盖管理员已保存的来源、令牌密文或下载策略。
     */
    public function installDatabase(int $fromVersion): void
    {
        if (!$this->supportsLegacyDatabaseVersion($fromVersion)) {
            throw new \RuntimeException('LX_MUSIC_DATABASE_VERSION_INVALID');
        }
        Db::connection()->statement(<<<'SQL'
CREATE TABLE IF NOT EXISTS lx_music_search_leases (
    id TEXT PRIMARY KEY NOT NULL,
    actor_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    source_key TEXT NOT NULL,
    title TEXT NOT NULL,
    artist TEXT NOT NULL,
    album TEXT NOT NULL,
    duration_ms INTEGER NULL CHECK (duration_ms IS NULL OR duration_ms >= 0),
    quality TEXT NOT NULL,
    format TEXT NOT NULL,
    size_bytes INTEGER NULL CHECK (size_bytes IS NULL OR size_bytes >= 0),
    reference_ciphertext TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    created_at TEXT NOT NULL
)
SQL);
        Db::connection()->statement('CREATE INDEX IF NOT EXISTS idx_lx_music_leases_expiry ON lx_music_search_leases(expires_at)');
        Db::connection()->statement(<<<'SQL'
CREATE TABLE IF NOT EXISTS lx_music_download_jobs (
    id TEXT PRIMARY KEY NOT NULL,
    search_lease_id TEXT NOT NULL UNIQUE REFERENCES lx_music_search_leases(id) ON DELETE RESTRICT,
    requested_by TEXT NULL REFERENCES users(id) ON DELETE SET NULL,
    library_id TEXT NOT NULL REFERENCES music_libraries(id) ON DELETE RESTRICT,
    source_key TEXT NOT NULL,
    title TEXT NOT NULL,
    artist TEXT NOT NULL,
    album TEXT NOT NULL,
    quality TEXT NOT NULL,
    format TEXT NOT NULL,
    expected_size_bytes INTEGER NULL CHECK (expected_size_bytes IS NULL OR expected_size_bytes >= 0),
    metadata_json TEXT NOT NULL DEFAULT '{}',
    status TEXT NOT NULL CHECK (status IN ('queued', 'resolving', 'downloading', 'publishing', 'succeeded', 'failed')),
    reference_ciphertext TEXT NULL,
    resolved_ciphertext TEXT NULL,
    downloaded_bytes INTEGER NOT NULL DEFAULT 0 CHECK (downloaded_bytes >= 0),
    total_bytes INTEGER NOT NULL DEFAULT 0 CHECK (total_bytes >= 0),
    progress_basis_points INTEGER NOT NULL DEFAULT 0 CHECK (progress_basis_points BETWEEN 0 AND 10000),
    imported_files INTEGER NOT NULL DEFAULT 0 CHECK (imported_files >= 0),
    scan_job_id TEXT NULL REFERENCES library_scan_jobs(id) ON DELETE SET NULL,
    error_code TEXT NULL,
    worker_id TEXT NULL,
    attempt INTEGER NOT NULL DEFAULT 0 CHECK (attempt BETWEEN 0 AND 10),
    heartbeat_at TEXT NULL,
    request_id TEXT NOT NULL,
    started_at TEXT NULL,
    finished_at TEXT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
)
SQL);
        Db::connection()->statement('CREATE INDEX IF NOT EXISTS idx_lx_music_jobs_queue ON lx_music_download_jobs(status, updated_at)');
        Db::connection()->statement(<<<'SQL'
CREATE TABLE IF NOT EXISTS lx_music_source_success_stats (
    source_key TEXT PRIMARY KEY NOT NULL,
    success_weight INTEGER NOT NULL DEFAULT 0 CHECK (success_weight >= 0),
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
)
SQL);
        Db::connection()->statement(<<<'SQL'
CREATE TABLE IF NOT EXISTS lx_music_source_cooldowns (
    source_key TEXT PRIMARY KEY NOT NULL,
    next_allowed_at_ms INTEGER NOT NULL CHECK (next_allowed_at_ms >= 0),
    updated_at_ms INTEGER NOT NULL CHECK (updated_at_ms >= 0)
)
SQL);
        Db::connection()->statement(<<<'SQL'
CREATE TABLE IF NOT EXISTS lx_music_source_health (
    source_key TEXT PRIMARY KEY NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('unknown', 'healthy', 'degraded', 'unhealthy')),
    consecutive_failures INTEGER NOT NULL DEFAULT 0 CHECK (consecutive_failures BETWEEN 0 AND 3),
    last_error_code TEXT NULL,
    last_checked_at_ms INTEGER NULL CHECK (last_checked_at_ms IS NULL OR last_checked_at_ms >= 0),
    next_check_at_ms INTEGER NOT NULL CHECK (next_check_at_ms >= 0),
    updated_at_ms INTEGER NOT NULL CHECK (updated_at_ms >= 0)
)
SQL);
        Db::connection()->statement(<<<'SQL'
CREATE TABLE IF NOT EXISTS lx_music_diagnostic_logs (
    id TEXT PRIMARY KEY NOT NULL,
    download_job_id TEXT NULL REFERENCES lx_music_download_jobs(id) ON DELETE CASCADE,
    source_key TEXT NOT NULL,
    platform_key TEXT NULL,
    quality TEXT NULL,
    level TEXT NOT NULL CHECK (level IN ('info', 'warning', 'error')),
    event_code TEXT NOT NULL,
    stage TEXT NOT NULL CHECK (stage IN ('queue', 'resolve', 'download', 'publish', 'retry', 'cleanup')),
    details_json TEXT NOT NULL,
    request_id TEXT NULL,
    created_at TEXT NOT NULL
)
SQL);
        Db::connection()->statement('CREATE INDEX IF NOT EXISTS idx_lx_music_logs_created ON lx_music_diagnostic_logs(created_at)');
        Db::connection()->statement('CREATE INDEX IF NOT EXISTS idx_lx_music_logs_job ON lx_music_diagnostic_logs(download_job_id)');

        $now = gmdate('Y-m-d\TH:i:s\Z');
        if (!Db::table('system_settings')->where('setting_key', 'plugin.lx_music.sources')->exists()) {
            Db::table('system_settings')->insert([
                'setting_key' => 'plugin.lx_music.sources',
                'value_json' => '{"sources":[]}', 'version' => 1, 'updated_by' => null, 'updated_at' => $now,
            ]);
        }
        if (!Db::table('system_settings')->where('setting_key', 'plugin.lx_music.download')->exists()) {
            Db::table('system_settings')->insert([
                'setting_key' => 'plugin.lx_music.download',
                'value_json' => '{"libraryId":null,"minimumQuality":"320k","maximumBytes":1073741824}',
                'version' => 1, 'updated_by' => null, 'updated_at' => $now,
            ]);
        }
        // 基线安装也会识别少数历史 JSON 形状；转换只在字段确实缺失时发生，完整配置和密文保持原样。
        $sourceRow = Db::table('system_settings')->where('setting_key', 'plugin.lx_music.sources')->first();
        if ($sourceRow instanceof \stdClass) {
            $sourceValue = json_decode((string) $sourceRow->value_json, true, 16, JSON_THROW_ON_ERROR);
            $sources = is_array($sourceValue) && is_array($sourceValue['sources'] ?? null) ? $sourceValue['sources'] : [];
            if ($sources !== [] && isset($sources[0]) && is_array($sources[0]) && !array_key_exists('type', $sources[0])) {
                $this->migrateSourceTypes();
            }
            $this->migrateRemovedHttpSourcesIfNeeded();
            $this->migrateSourceCooldownsIfNeeded();
        }
        $downloadRow = Db::table('system_settings')->where('setting_key', 'plugin.lx_music.download')->first();
        if ($downloadRow instanceof \stdClass) {
            $downloadValue = json_decode((string) $downloadRow->value_json, true, 8, JSON_THROW_ON_ERROR);
            if (is_array($downloadValue) && array_key_exists('defaultQuality', $downloadValue)) {
                $this->migrateDownloadSettings();
            }
        }
        // 旧表可能缺少最终基线中的快照列；SQLite 不支持 ADD COLUMN IF NOT EXISTS，因此仅补缺列。
        $columns = Db::connection()->select("PRAGMA table_info('lx_music_download_jobs')");
        if (!array_filter($columns, static fn (object $column): bool => (string) ($column->name ?? '') === 'metadata_json')) {
            Db::connection()->statement("ALTER TABLE lx_music_download_jobs ADD COLUMN metadata_json TEXT NOT NULL DEFAULT '{}'");
        }
    }

    /**
     * 为旧 LX 下载任务增加版本化元数据快照列。
     *
     * 升级只修改插件任务表，不读取媒体文件或外部来源；已有任务以空对象开始，Worker 会在下一次下载
     * 阶段根据任务已冻结的标题、艺人和专辑补齐基础快照。SQLite 不支持通用 IF NOT EXISTS ADD COLUMN，
     * 因此先读取 table_info 再执行 DDL；列已存在时幂等返回。迁移在核心插件生命周期事务内运行，失败会
     * 回滚版本账本，不能留下“版本已升级但任务结构缺列”的状态。
     */
    private function migrateMetadataSnapshotColumn(): void
    {
        $columns = Db::connection()->select('PRAGMA table_info(lx_music_download_jobs)');
        foreach ($columns as $column) {
            if (($column->name ?? null) === 'metadata_json') return;
        }
        Db::connection()->statement("ALTER TABLE lx_music_download_jobs ADD COLUMN metadata_json TEXT NOT NULL DEFAULT '{}'");
    }

    /**
     * 为旧来源目录补充第三方 LX 源下载冷却字段。
     *
     * 迁移只修改插件自己的来源 JSON，并为每个已有来源写入 0 毫秒默认值；不改变 URL、Token、启用状态或
     * 权重，也不主动预约任何冷却窗口。未知结构直接失败并回滚插件版本账本，避免旧代码把不完整配置当成
     * 可用来源；重复执行看到字段后保持幂等。
     */
    private function migrateSourceCooldowns(): void
    {
        $row = Db::table('system_settings')->where('setting_key', 'plugin.lx_music.sources')->first();
        if (!$row instanceof \stdClass) throw new \RuntimeException('LX_MUSIC_SOURCE_SETTINGS_MISSING');
        $value = json_decode((string) $row->value_json, true, 16, JSON_THROW_ON_ERROR);
        if (!is_array($value) || array_keys($value) !== ['sources'] || !is_array($value['sources'])
            || !array_is_list($value['sources'])) {
            throw new \RuntimeException('LX_MUSIC_SOURCE_SETTINGS_INVALID');
        }
        $changed = false;
        foreach ($value['sources'] as &$source) {
            if (!is_array($source)) throw new \RuntimeException('LX_MUSIC_SOURCE_SETTINGS_INVALID');
            if (!array_key_exists('cooldownMs', $source)) {
                $source['cooldownMs'] = 0;
                $changed = true;
            }
        }
        unset($source);
        if (!$changed) return;
        Db::table('system_settings')->where('setting_key', 'plugin.lx_music.sources')->update([
            'value_json' => json_encode($value, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'version' => Db::raw('version + 1'), 'updated_at' => gmdate('Y-m-d\TH:i:s\Z'),
        ]);
    }

    /**
     * 为已有安装补充 LX 来源健康账本。
     *
     * 健康行是按来源首次被 Worker 看到时惰性创建的，因此升级只需要确保表存在，不会主动访问第三方
     * URL、改变来源启停状态或制造失败计数。表已由幂等 CREATE 建立后重复升级没有数据副作用；DDL 仍
     * 位于核心生命周期事务内，失败会回滚迁移账本。
     */
    private function migrateSourceHealth(): void
    {
        if (!Db::connection()->getSchemaBuilder()->hasTable('lx_music_source_health')) {
            throw new \RuntimeException('LX_MUSIC_SOURCE_HEALTH_SCHEMA_MISSING');
        }
    }

    /**
     * 把 v1-v3 的默认音质设置升级为 v4 的默认目标库与最低质量策略。
     *
     * 旧 `defaultQuality` 数值原样作为最低门槛，避免升级后自动接受更低质量；目标库没有可靠的历史业务
     * 事实可推断，因此固定补为 null，要求管理员明确选择，绝不能擅自选择第一个库。迁移仅改插件自己的
     * 单行 JSON 并递增设置版本，不访问文件或网络；未知结构失败并回滚核心安装事务。已是 v4 结构时
     * 原样返回，使开发期重复执行保持幂等。
     */
    private function migrateDownloadSettings(): void
    {
        $row = Db::table('system_settings')->where('setting_key', 'plugin.lx_music.download')->first();
        if (!$row instanceof \stdClass) throw new \RuntimeException('LX_MUSIC_DOWNLOAD_SETTINGS_MISSING');
        $value = json_decode((string) $row->value_json, true, 8, JSON_THROW_ON_ERROR);
        if (is_array($value) && array_keys($value) === ['libraryId', 'minimumQuality', 'maximumBytes']) return;
        if (!is_array($value) || array_keys($value) !== ['defaultQuality', 'maximumBytes']
            || !is_string($value['defaultQuality']) || !is_int($value['maximumBytes'])
            || !in_array($value['defaultQuality'], ['128k', '320k', 'flac', 'flac24'], true)) {
            throw new \RuntimeException('LX_MUSIC_DOWNLOAD_SETTINGS_INVALID');
        }
        Db::table('system_settings')->where('setting_key', 'plugin.lx_music.download')->update([
            'value_json' => json_encode([
                'libraryId' => null,
                'minimumQuality' => $value['defaultQuality'],
                'maximumBytes' => $value['maximumBytes'],
            ], JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES),
            'version' => Db::raw('version + 1'),
            'updated_at' => gmdate('Y-m-d\TH:i:s\Z'),
        ]);
    }

    /**
     * 把 v1 来源目录升级为显式来源类型。
     *
     * 迁移只读取插件自己的 JSON 设置，不访问来源 URL。路径以 `.js` 结尾的 HTTP/HTTPS 地址确定为 LX
     * 脚本并清除旧 Token 密文；其他旧地址暂标为待删除的历史 HTTP 服务，随后由 v5 迁移移除。未知结构
     * 失败并回滚核心迁移事务，禁止为了完成升级重置管理员配置。重复执行看到 type 后保持原值，因此操作幂等。
     */
    private function migrateSourceTypes(): void
    {
        $row = Db::table('system_settings')->where('setting_key', 'plugin.lx_music.sources')->first();
        if (!$row instanceof \stdClass) throw new \RuntimeException('LX_MUSIC_SOURCE_SETTINGS_MISSING');
        $value = json_decode((string) $row->value_json, true, 16, JSON_THROW_ON_ERROR);
        if (!is_array($value) || array_keys($value) !== ['sources'] || !is_array($value['sources'])
            || !array_is_list($value['sources'])) throw new \RuntimeException('LX_MUSIC_SOURCE_SETTINGS_INVALID');
        $sources = [];
        foreach ($value['sources'] as $source) {
            if (!is_array($source) || !is_string($source['baseUrl'] ?? null)) {
                throw new \RuntimeException('LX_MUSIC_SOURCE_SETTINGS_INVALID');
            }
            $type = $source['type'] ?? null;
            if ($type === null) {
                $path = parse_url($source['baseUrl'], PHP_URL_PATH);
                $type = is_string($path) && str_ends_with(strtolower($path), '.js') ? 'lx_script' : 'http_service';
            }
            if (!in_array($type, ['lx_script', 'http_service'], true)) {
                throw new \RuntimeException('LX_MUSIC_SOURCE_SETTINGS_INVALID');
            }
            $sources[] = ['key' => $source['key'], 'name' => $source['name'], 'type' => $type,
                'enabled' => $source['enabled'], 'baseUrl' => $source['baseUrl'],
                'tokenCiphertext' => $type === 'lx_script' ? null : ($source['tokenCiphertext'] ?? null)];
        }
        Db::table('system_settings')->where('setting_key', 'plugin.lx_music.sources')->update([
            'value_json' => json_encode(['sources' => $sources], JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'version' => Db::raw('version + 1'), 'updated_at' => gmdate('Y-m-d\TH:i:s\Z'),
        ]);
    }

    /**
     * 删除不再支持的 HTTP v1 来源及其密文配置。
     *
     * v5 起 LX Music 只执行 LX API v2 脚本；旧 HTTP 来源没有可安全转换为脚本的协议语义，因此升级时
     * 只保留已经声明为 `lx_script` 的条目，并丢弃其余来源和令牌密文。该操作只影响插件自己的来源设置，
     * 不访问网络、不删除媒体或下载任务；若 JSON 结构异常则整次安装失败，避免半目录状态。重复执行时
     * 没有待删除条目不递增设置版本，保证迁移幂等。
     */
    private function migrateRemovedHttpSources(): void
    {
        $row = Db::table('system_settings')->where('setting_key', 'plugin.lx_music.sources')->first();
        if (!$row instanceof \stdClass) throw new \RuntimeException('LX_MUSIC_SOURCE_SETTINGS_MISSING');
        $value = json_decode((string) $row->value_json, true, 16, JSON_THROW_ON_ERROR);
        if (!is_array($value) || array_keys($value) !== ['sources'] || !is_array($value['sources'])
            || !array_is_list($value['sources'])) throw new \RuntimeException('LX_MUSIC_SOURCE_SETTINGS_INVALID');
        $sources = [];
        $removed = false;
        foreach ($value['sources'] as $source) {
            if (!is_array($source) || !is_string($source['key'] ?? null) || !is_string($source['name'] ?? null)
                || !is_string($source['type'] ?? null) || !is_bool($source['enabled'] ?? null)
                || !is_string($source['baseUrl'] ?? null)) throw new \RuntimeException('LX_MUSIC_SOURCE_SETTINGS_INVALID');
            if ($source['type'] !== 'lx_script') {
                $removed = true;
                continue;
            }
            $sources[] = ['key' => $source['key'], 'name' => $source['name'], 'type' => 'lx_script',
                'enabled' => $source['enabled'], 'baseUrl' => $source['baseUrl'],
                'tokenCiphertext' => $source['tokenCiphertext'] ?? null];
        }
        if (!$removed) return;
        Db::table('system_settings')->where('setting_key', 'plugin.lx_music.sources')->update([
            'value_json' => json_encode(['sources' => $sources], JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'version' => Db::raw('version + 1'), 'updated_at' => gmdate('Y-m-d\TH:i:s\Z'),
        ]);
    }

    private function migrateRemovedHttpSourcesIfNeeded(): void
    {
        $row = Db::table('system_settings')->where('setting_key', 'plugin.lx_music.sources')->first();
        if (!$row instanceof \stdClass) return;
        $value = json_decode((string) $row->value_json, true, 16, JSON_THROW_ON_ERROR);
        foreach (($value['sources'] ?? []) as $source) {
            if (is_array($source) && ($source['type'] ?? null) !== 'lx_script') {
                $this->migrateRemovedHttpSources();
                return;
            }
        }
    }

    private function migrateSourceCooldownsIfNeeded(): void
    {
        $row = Db::table('system_settings')->where('setting_key', 'plugin.lx_music.sources')->first();
        if (!$row instanceof \stdClass) return;
        $value = json_decode((string) $row->value_json, true, 16, JSON_THROW_ON_ERROR);
        foreach (($value['sources'] ?? []) as $source) {
            if (is_array($source) && !array_key_exists('cooldownMs', $source)) {
                $this->migrateSourceCooldowns();
                return;
            }
        }
    }

    /**
     * 删除插件拥有的配置、租约、任务、索引和表。
     *
     * 任务先于租约删除以满足外键限制；核心迁移账本由生命周期服务随后删除。成功入库的歌曲和扫描任务
     * 属于核心业务事实，不在本事务删除；进行中的隐藏暂存文件无法由 SQLite 回滚，停服卸载后可由同一
     * 任务标记的后续维护流程清理，绝不能扫描或删除任意隐藏目录。
     */
    public function uninstallDatabase(): void
    {
        Db::table('system_settings')->whereIn('setting_key', [
            'plugin.lx_music.sources', 'plugin.lx_music.download',
        ])->delete();
        Db::connection()->statement('DROP INDEX IF EXISTS idx_lx_music_logs_job');
        Db::connection()->statement('DROP INDEX IF EXISTS idx_lx_music_logs_created');
        Db::connection()->statement('DROP INDEX IF EXISTS idx_lx_music_jobs_queue');
        Db::connection()->statement('DROP INDEX IF EXISTS idx_lx_music_leases_expiry');
        Db::connection()->statement('DROP TABLE IF EXISTS lx_music_diagnostic_logs');
        Db::connection()->statement('DROP TABLE IF EXISTS lx_music_download_jobs');
        Db::connection()->statement('DROP TABLE IF EXISTS lx_music_search_leases');
        Db::connection()->statement('DROP TABLE IF EXISTS lx_music_source_cooldowns');
        Db::connection()->statement('DROP TABLE IF EXISTS lx_music_source_health');
        Db::connection()->statement('DROP TABLE IF EXISTS lx_music_source_success_stats');
    }
}
