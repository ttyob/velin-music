'use strict'

const vm = require('node:vm')
const http = require('node:http')
const https = require('node:https')
const crypto = require('node:crypto')
const zlib = require('node:zlib')
const { URL, URLSearchParams } = require('node:url')
const { TextEncoder, TextDecoder } = require('node:util')

const MAX_SCRIPT_BYTES = 1024 * 1024
const MAX_RESPONSE_BYTES = 2 * 1024 * 1024
const EVENT_NAMES = Object.freeze({ request: 'request', inited: 'inited', updateAlert: 'updateAlert' })
let activeDiagnostic = null
let activeOperation = null
let activeScriptSha256 = null
let activeScriptOrigin = null
let activeSourceToken = null

function fail(code) {
  const error = new Error(code)
  error.code = code
  throw error
}

/**
 * 把不受信脚本和 Node 网络栈抛出的异常收敛为稳定诊断码。
 *
 * runner 不返回 error.message、stack、请求 URL 或第三方正文，避免脚本密钥和临时播放地址越过进程边界；
 * 已由 Velin 主动抛出的 LX_* 代码保持原义，其余异常只按 Node code 或内建错误类型分类。新增分类只提升
 * 可诊断性，不改变重试授权，也不能绕过下载阶段独立执行的地址、大小及媒体探测校验。
 */
function classifyError(error) {
  if (error && typeof error.code === 'string' && /^LX_[A-Z0-9_]{1,80}$/.test(error.code)) return error.code
  const scriptMessageCodes = new Map([
    ['block ip', 'LX_SCRIPT_UPSTREAM_IP_BLOCKED'],
    ['get music url failed', 'LX_SCRIPT_UPSTREAM_RESOLVE_FAILED'],
    ['internal server error', 'LX_SCRIPT_UPSTREAM_SERVER_FAILED'],
    ['too many requests', 'LX_SCRIPT_UPSTREAM_RATE_LIMITED'],
    ['param error', 'LX_SCRIPT_UPSTREAM_PARAMETER_INVALID'],
    ['unknow error', 'LX_SCRIPT_UPSTREAM_RESPONSE_INVALID'],
    ['unknown error', 'LX_SCRIPT_UPSTREAM_RESPONSE_INVALID'],
    ['404 Not Found', 'LX_SCRIPT_UPSTREAM_NOT_FOUND'],
    ['illegal name change', 'LX_SCRIPT_INTEGRITY_REJECTED'],
  ])
  if (error && typeof error.message === 'string' && scriptMessageCodes.has(error.message)) {
    return scriptMessageCodes.get(error.message)
  }
  if (error && typeof error.message === 'string') {
    const message = error.message.toLowerCase()
    if (/参数|param(?:eter)?|invalid argument/.test(message)) return 'LX_SCRIPT_UPSTREAM_PARAMETER_INVALID'
    if (/频繁|限流|too many|rate.?limit/.test(message)) return 'LX_SCRIPT_UPSTREAM_RATE_LIMITED'
    if (/封禁|block(?:ed)? ip|forbidden/.test(message)) return 'LX_SCRIPT_UPSTREAM_IP_BLOCKED'
    if (/未找到|not found|404/.test(message)) return 'LX_SCRIPT_UPSTREAM_NOT_FOUND'
    if (/返回.*(?:无效|异常)|invalid response|unknown error|unknow error/.test(message)) return 'LX_SCRIPT_UPSTREAM_RESPONSE_INVALID'
    if (/解析|获取|下载|播放|music url|resolve/.test(message)) return 'LX_SCRIPT_UPSTREAM_RESOLVE_FAILED'
  }
  const networkCodes = new Set(['ECONNABORTED', 'ECONNREFUSED', 'ECONNRESET', 'EHOSTUNREACH', 'ENETUNREACH',
    'ENOTFOUND', 'EPIPE', 'ETIMEDOUT', 'ERR_TLS_CERT_ALTNAME_INVALID', 'UNABLE_TO_VERIFY_LEAF_SIGNATURE'])
  if (error && typeof error.code === 'string' && networkCodes.has(error.code)) return 'LX_SCRIPT_REQUEST_FAILED'
  // vm context 与宿主拥有不同原型链，不能使用 instanceof；只接受标准内建 name 白名单。
  if (error?.name === 'SyntaxError') return 'LX_SCRIPT_SYNTAX_ERROR'
  if (error?.name === 'ReferenceError') return 'LX_SCRIPT_RUNTIME_REFERENCE_ERROR'
  if (error?.name === 'TypeError') return 'LX_SCRIPT_RUNTIME_TYPE_ERROR'
  if (error?.name === 'RangeError') return 'LX_SCRIPT_RUNTIME_RANGE_ERROR'
  return 'LX_SCRIPT_RUNTIME_FAILED'
}

function requestBody(options) {
  if (options.body != null) {
    if (Buffer.isBuffer(options.body) || typeof options.body === 'string') return options.body
    return JSON.stringify(options.body)
  }
  if (options.form && typeof options.form === 'object') return new URLSearchParams(options.form).toString()
  if (options.formData && typeof options.formData === 'object') return new URLSearchParams(options.formData).toString()
  return null
}

function responseBodyType(raw, body) {
  if (!raw.length) return 'empty'
  if (Array.isArray(body)) return 'array'
  if (body === null) return 'null'
  if (typeof body === 'object') return 'object'
  if (typeof body === 'number') return 'number'
  if (typeof body === 'boolean') return 'boolean'
  return 'text'
}

/**
 * 从上游错误字段生成可打印文本，同时删除临时 URL、凭证参数、Bearer 和长标识符。
 *
 * 该函数不遍历任意 data 对象，也不接受数组或对象值，只处理少量错误语义标量。替换发生在 stdout 前，
 * PHP 还会再次拒绝 URL 和凭证形状，因此页面只能看到错误码和人类可读原因，不能借日志恢复资源引用。
 */
function safeUpstreamText(value, maximum) {
  if (!['string', 'number', 'boolean'].includes(typeof value)) return null
  let valueText = String(value).replace(/[\u0000-\u001f\u007f]+/g, ' ').trim()
  if (!valueText) return null
  valueText = valueText
    .replace(/<[^>]{1,200}>/gu, ' ')
    .replace(/https?:\/\/[^\s"'<>]+/giu, '[URL已隐藏]')
    .replace(/bearer\s+[a-z0-9._~+\/-]+/giu, '[凭证已隐藏]')
    .replace(/\b(token|cookie|signature|secret|api[_-]?key)\s*[=:]\s*[^\s,;]+/giu, '[凭证已隐藏]')
    .replace(/(["']?(?:id|songmid|copyrightid|mid|hash|url)["']?\s*[:=]\s*)["']?[^\s,;}]+/giu,
      '$1[资源标识已隐藏]')
    .replace(/\b[A-Za-z0-9_-]{24,}\b/g, '[标识已隐藏]')
    .replace(/\s+/gu, ' ')
  return [...valueText].slice(0, maximum).join('')
}

function upstreamDiagnosticFields(body, stage) {
  if (stage !== 'upstream_request' || body === null || body === undefined) return {}
  if (typeof body === 'string') {
    const text = safeUpstreamText(body, 500)
    return text ? { upstreamText: text } : {}
  }
  if (typeof body !== 'object' || Array.isArray(body)) return {}
  const entries = new Map(Object.entries(body).map(([key, value]) => [key.toLowerCase(), value]))
  const first = (names, maximum) => {
    for (const name of names) {
      const value = safeUpstreamText(entries.get(name.toLowerCase()), maximum)
      if (value) return value
    }
    return null
  }
  const code = first(['errorCode', 'code'], 80)
  const status = first(['status', 'statusCode'], 80)
  const error = first(['error'], 240)
  const message = first(['message', 'msg', 'reason', 'detail'], 500)
  return { ...(code ? { upstreamCode: code } : {}), ...(status ? { upstreamStatus: status } : {}),
    ...(error ? { upstreamError: error } : {}), ...(message ? { upstreamMessage: message } : {}) }
}

function failureDiagnostic(error) {
  const runtimeMessage = safeUpstreamText(error?.message, 500)
  return { ...(activeDiagnostic || {}), ...(runtimeMessage ? { runtimeMessage } : {}) }
}

/**
 * 校验受信脚本可访问的 HTTP(S) 目标并返回标准 URL。
 *
 * 管理员已经明确要求脚本可以连接回环、私网、保留地址和公开地址，因此这里不执行 DNS 分类或协议升级；
 * 仍拒绝非 HTTP(S)、内嵌账号密码与片段，避免把放宽网络范围误解为允许读取本地文件或混入 URL 凭证。
 * 返回对象只供单次请求使用，不缓存 DNS 结果，也不改变重定向、Header、正文、响应大小及超时限制。
 */
function requestTarget(input) {
  let target
  try { target = new URL(input) } catch { fail('LX_SCRIPT_URL_INVALID') }
  if (!['http:', 'https:'].includes(target.protocol) || target.username || target.password || target.hash) {
    fail('LX_SCRIPT_URL_INVALID')
  }
  return target
}

/**
 * 只对脚本同源 API 请求附加插件保存的来源 Token。
 *
 * Token 由管理员配置并经 PHP 密文解密后通过单次 stdin 传入；脚本本身看不到该值。仅在上游请求目标与
 * 脚本 URL 的 origin 完全一致、且脚本没有自行提供 Authorization 时注入，防止受信脚本访问其他平台
 * 域名时意外携带来源凭据。脚本下载不附加 Bearer，带 Web Basic 保护的脚本仍应通过专门代理发布。
 */
function withSourceAuthorization(headers, target, stage, scriptOrigin, sourceToken) {
  if (stage !== 'upstream_request' || !sourceToken || target.origin !== scriptOrigin ||
    Object.keys(headers).some((name) => name.toLowerCase() === 'authorization')) return headers
  return { ...headers, Authorization: `Bearer ${sourceToken}` }
}

/**
 * 生成允许跨越 runner 边界的响应结构摘要。
 *
 * 摘要刻意不接收 URL、请求/响应 Header 值或正文值。Content-Type 只保留标准媒体类型，JSON 对象只
 * 保留有界字段名，用于区分“上游返回 HTML”“字段形状变化”等故障；字段值、数组元素和平台资源 ID
 * 永不进入 stdout。脚本摘要只用于确认管理员配置脚本是否在线变化，不包含脚本正文。
 */
function responseDiagnostic(response, method, stage) {
  const contentTypeValue = Array.isArray(response.headers?.['content-type'])
    ? response.headers['content-type'][0] : response.headers?.['content-type']
  const contentType = typeof contentTypeValue === 'string'
    ? contentTypeValue.split(';', 1)[0].trim().toLowerCase() : ''
  const topLevelKeys = response.body && typeof response.body === 'object' && !Array.isArray(response.body)
    ? Object.keys(response.body).filter((key) => /^[A-Za-z0-9_.-]{1,64}$/.test(key)).sort().slice(0, 20) : []
  return {
    operation: activeOperation,
    method,
    statusCode: Number.isInteger(response.statusCode) ? Math.max(0, Math.min(599, response.statusCode)) : 0,
    ...(contentType && /^[a-z0-9!#$&^_.+\/-]{1,128}$/.test(contentType) ? { contentType } : {}),
    responseBytes: Math.max(0, Math.min(MAX_RESPONSE_BYTES, response.bytes || 0)),
    bodyType: responseBodyType(response.raw, response.body),
    ...(topLevelKeys.length ? { topLevelKeys } : {}),
    ...upstreamDiagnosticFields(response.body, stage),
    ...(activeScriptSha256 ? { scriptSha256: activeScriptSha256 } : {}),
    stage,
  }
}

async function safeRequest(input, options = {}, maximum = MAX_RESPONSE_BYTES, stage = 'upstream_request') {
  const target = requestTarget(input)
  const method = String(options.method || 'GET').toUpperCase()
  if (!['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD'].includes(method)) fail('LX_SCRIPT_METHOD_INVALID')
  activeDiagnostic = { operation: activeOperation, method, stage,
    ...(activeScriptSha256 ? { scriptSha256: activeScriptSha256 } : {}) }
  const headers = {}
  for (const [name, value] of Object.entries(options.headers || {})) {
    const lower = name.toLowerCase()
    if (!/^[a-z0-9-]{1,64}$/.test(lower) || ['host', 'connection', 'content-length', 'proxy-authorization'].includes(lower) ||
      typeof value !== 'string' || value.length > 4096 || /[\0\r\n]/.test(value)) fail('LX_SCRIPT_HEADERS_INVALID')
    headers[name] = value
  }
  const authorizedHeaders = withSourceAuthorization(headers, target, stage, activeScriptOrigin, activeSourceToken)
  const body = requestBody(options)
  if (body != null && Buffer.byteLength(body) > MAX_RESPONSE_BYTES) fail('LX_SCRIPT_BODY_TOO_LARGE')
  const transport = target.protocol === 'https:' ? https : http
  return await new Promise((resolve, reject) => {
    const request = transport.request(target, {
      method, headers: authorizedHeaders, agent: false,
      timeout: Math.min(Math.max(Number(options.timeout) || 12000, 1000), 60000),
    }, (response) => {
      if (response.statusCode >= 300 && response.statusCode < 400) {
        response.destroy(); reject(Object.assign(new Error('LX_SCRIPT_REDIRECT_BLOCKED'), { code: 'LX_SCRIPT_REDIRECT_BLOCKED' })); return
      }
      const chunks = []; let size = 0
      response.on('data', (chunk) => {
        size += chunk.length
        if (size > maximum) response.destroy(Object.assign(new Error('LX_SCRIPT_RESPONSE_TOO_LARGE'), { code: 'LX_SCRIPT_RESPONSE_TOO_LARGE' }))
        else chunks.push(chunk)
      })
      response.on('end', () => {
        const raw = Buffer.concat(chunks)
        let parsed = raw.toString('utf8')
        try { parsed = JSON.parse(parsed) } catch {}
        const result = { statusCode: response.statusCode, statusMessage: response.statusMessage, headers: response.headers,
          bytes: raw.length, raw, body: parsed }
        activeDiagnostic = responseDiagnostic(result, method, stage)
        resolve(result)
      })
    })
    request.on('error', reject)
    request.on('timeout', () => request.destroy(Object.assign(new Error('LX_SCRIPT_REQUEST_TIMEOUT'), { code: 'LX_SCRIPT_REQUEST_TIMEOUT' })))
    if (body != null) request.write(body)
    request.end()
  })
}

function withTimeout(promise, milliseconds, code) {
  return Promise.race([promise, new Promise((_, reject) => setTimeout(() => reject(Object.assign(new Error(code), { code })), milliseconds))])
}

/**
 * 把 LX 脚本常见的明文 CDN 地址升级为 HTTPS，再交给 PHP 下载安全策略复验。
 *
 * 这里只允许标准 HTTP(S)、无认证信息和无片段的绝对 URL；HTTP 仅改写 scheme，不发起探测、不跟随
 * 跳转，也不放宽 PHP 对 443、公网 DNS 固定和 TLS 的要求。不支持 HTTPS 的上游会在下载阶段安全失败。
 */
function normalizeResolvedUrl(value) {
  if (value === undefined || value === null || value === '') fail('LX_SCRIPT_RESOLVE_EMPTY')
  if (typeof value !== 'string') fail(Array.isArray(value)
    ? 'LX_SCRIPT_RESOLVE_ARRAY_INVALID'
    : (typeof value === 'object' ? 'LX_SCRIPT_RESOLVE_OBJECT_INVALID' : 'LX_SCRIPT_RESOLVE_TYPE_INVALID'))
  if (value.length > 8192) fail('LX_SCRIPT_RESOLVE_TOO_LONG')
  let target
  try { target = new URL(value) } catch { fail('LX_SCRIPT_RESOLVE_INVALID') }
  if (!['http:', 'https:'].includes(target.protocol) || target.username || target.password || target.hash || !target.hostname) {
    fail('LX_SCRIPT_RESOLVE_INVALID')
  }
  if (target.protocol === 'http:') target.protocol = 'https:'
  return target.toString()
}

/**
 * 校验歌词动作返回的主歌词正文。
 *
 * LX 脚本可能同时返回翻译或逐字歌词；当前下载标签只写主 lyric，避免把多种时轴格式无规则拼接。正文
 * 必须是有效非空字符串、没有 NUL 且 UTF-8 不超过 50 KiB。校验失败只让本次可选资源动作失败，不会
 * 影响此前独立完成的 musicUrl 解析；正文只通过单次 stdout 返回 PHP，不写 runner 日志或缓存。
 */
function normalizeLyrics(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value) || typeof value.lyric !== 'string') {
    fail('LX_SCRIPT_LYRICS_INVALID')
  }
  const lyric = value.lyric.trim()
  if (!lyric || lyric.includes('\0') || Buffer.byteLength(lyric, 'utf8') > 50 * 1024) {
    fail('LX_SCRIPT_LYRICS_INVALID')
  }
  return lyric
}

/**
 * 创建与 Chromium 常用 Console 方法兼容的静默对象。
 *
 * LX 脚本会在解析分支调用 group/groupEnd；服务端保留调用形状但不产生任何输出，避免 musicInfo、
 * 第三方响应和临时 URL 进入 stdout/stderr。返回对象冻结，脚本不能把后续日志调用替换成外带函数。
 */
function createSilentConsole() {
  const noop = () => {}
  return Object.freeze({
    assert: noop, clear: noop, count: noop, countReset: noop, debug: noop, dir: noop, dirxml: noop,
    error: noop, group: noop, groupCollapsed: noop, groupEnd: noop, info: noop, log: noop, table: noop,
    time: noop, timeEnd: noop, timeLog: noop, trace: noop, warn: noop,
  })
}

async function loadScript(scriptUrl) {
  const response = await safeRequest(scriptUrl, { method: 'GET', headers: { Accept: 'application/javascript,text/javascript,*/*' } }, MAX_SCRIPT_BYTES, 'script_fetch')
  if (response.statusCode !== 200 || !Buffer.isBuffer(response.raw) || response.raw.length === 0) fail('LX_SCRIPT_FETCH_FAILED')
  return response.raw.toString('utf8')
}

function metadata(script, scriptUrl) {
  const field = (name) => script.match(new RegExp(`@${name}\\s+([^\\r\\n*]+)`, 'i'))?.[1]?.trim() || ''
  return { name: field('name') || 'LX JS Source', description: field('description'), version: field('version'),
    author: field('author'), homepage: field('homepage') || scriptUrl, rawScript: script }
}

async function run(input) {
  if (!input || input.version !== 1 || !['init', 'resolve', 'metadata'].includes(input.operation) || typeof input.scriptUrl !== 'string') fail('LX_RUNNER_INPUT_INVALID')
  if (input.sourceToken !== undefined && input.sourceToken !== null &&
    (typeof input.sourceToken !== 'string' || input.sourceToken.length > 4096 || /[\u0000-\u001f\u007f]/u.test(input.sourceToken))) {
    fail('LX_RUNNER_INPUT_INVALID')
  }
  activeOperation = input.operation
  activeScriptSha256 = null
  activeDiagnostic = null
  activeScriptOrigin = requestTarget(input.scriptUrl).origin
  activeSourceToken = input.sourceToken || null
  const script = await loadScript(input.scriptUrl)
  const currentScriptInfo = metadata(script, input.scriptUrl)
  let requestHandler = null
  let initialized = null
  const lx = {
    EVENT_NAMES,
    version: '2.0.0', env: 'desktop', currentScriptInfo,
    on: async (event, handler) => {
      if (event !== EVENT_NAMES.request || typeof handler !== 'function') fail('LX_SCRIPT_EVENT_INVALID')
      requestHandler = handler
    },
    send: async (event, data) => {
      if (event === EVENT_NAMES.inited) { initialized = data; return }
      if (event === EVENT_NAMES.updateAlert) return
      fail('LX_SCRIPT_EVENT_INVALID')
    },
    request: (url, options, callback) => {
      let cancelled = false
      // 成功回调自身抛错时不能再被同一 Promise 的 catch 当成网络失败回调第二次；重复回调会让来源脚本
      // 的 Promise 状态失真，并可能形成未处理拒绝导致 runner 空输出退出。使用 then 的双分支只处理一次
      // 网络结果，回调异常继续交给下方进程级失败包络，仍只输出稳定错误码和脱敏结构摘要。
      safeRequest(url, options, MAX_RESPONSE_BYTES, 'upstream_request').then(
        (response) => { if (!cancelled) callback(null, response, response.body) },
        (error) => { if (!cancelled) callback(error, null, null) },
      )
      return () => { cancelled = true }
    },
    utils: {
      crypto: {
        aesEncrypt: (buffer, mode, key, iv) => {
          const cipher = crypto.createCipheriv(mode, key, iv)
          return Buffer.concat([cipher.update(buffer), cipher.final()])
        },
        rsaEncrypt: (buffer, key) => crypto.publicEncrypt({ key, padding: crypto.constants.RSA_NO_PADDING }, Buffer.concat([Buffer.alloc(128 - buffer.length), buffer])),
        randomBytes: (size) => crypto.randomBytes(size), md5: (value) => crypto.createHash('md5').update(value).digest('hex'),
      },
      buffer: { from: (...args) => Buffer.from(...args), bufToString: (buf, format) => Buffer.from(buf, 'binary').toString(format) },
      zlib: {
        inflate: (buf) => new Promise((resolve, reject) => zlib.inflate(buf, (error, data) => error ? reject(error) : resolve(data))),
        deflate: (data) => new Promise((resolve, reject) => zlib.deflate(data, (error, data) => error ? reject(error) : resolve(data))),
      },
    },
  }
  Object.freeze(lx.EVENT_NAMES); Object.freeze(lx.utils.crypto); Object.freeze(lx.utils.buffer); Object.freeze(lx.utils.zlib); Object.freeze(lx.utils)
  const silentConsole = createSilentConsole()
  const context = vm.createContext({ window: null, self: null, lx, console: silentConsole, Buffer, URL, URLSearchParams,
    TextEncoder, TextDecoder, setTimeout, clearTimeout, setInterval, clearInterval, atob: (value) => Buffer.from(value, 'base64').toString('binary'),
    btoa: (value) => Buffer.from(value, 'binary').toString('base64') }, { codeGeneration: { strings: true, wasm: false } })
  context.window = context; context.self = context; context.window.lx = lx
  new vm.Script(script, { filename: 'administrator-lx-source.js' }).runInContext(context, { timeout: 3000 })
  await withTimeout((async () => { while (initialized === null) await new Promise((resolve) => setTimeout(resolve, 10)) })(), 5000, 'LX_SCRIPT_INIT_TIMEOUT')
  if (!initialized || typeof initialized !== 'object' || !initialized.sources || typeof initialized.sources !== 'object' || typeof requestHandler !== 'function') fail('LX_SCRIPT_INIT_INVALID')
  const sources = {}
  const actions = {}
  for (const key of ['kw', 'kg', 'tx', 'wy', 'mg']) {
    const item = initialized.sources[key]
    if (!item || item.type !== 'music' || !Array.isArray(item.actions) || !item.actions.includes('musicUrl') || !Array.isArray(item.qualitys)) continue
    sources[key] = item.qualitys.filter((quality) => ['128k', '320k', 'flac', 'flac24bit'].includes(quality))
    actions[key] = item.actions.filter((action) => ['musicUrl', 'lyric', 'pic'].includes(action))
  }
  const digest = crypto.createHash('sha256').update(script).digest('hex')
  activeScriptSha256 = digest
  if (activeDiagnostic) activeDiagnostic.scriptSha256 = digest
  if (input.operation === 'init') return { version: 1, script: { ...currentScriptInfo, rawScript: undefined, sha256: digest }, sources, actions }
  if (!['kw', 'kg', 'tx', 'wy', 'mg'].includes(input.source) ||
    !input.musicInfo || typeof input.musicInfo !== 'object' || Array.isArray(input.musicInfo) || input.musicInfo.source !== input.source) fail('LX_RUNNER_INPUT_INVALID')
  if (input.operation === 'resolve') {
    if (!['128k', '320k', 'flac', 'flac24bit'].includes(input.quality) || !sources[input.source]?.includes(input.quality)) {
      fail('LX_SCRIPT_QUALITY_UNSUPPORTED')
    }
    const value = await withTimeout(Promise.resolve(requestHandler({ source: input.source, action: 'musicUrl',
      info: { type: input.quality, musicInfo: input.musicInfo } })), 15000, 'LX_SCRIPT_RESOLVE_TIMEOUT')
    return { version: 1, url: normalizeResolvedUrl(value), sha256: digest }
  }
  if (!['lyric', 'pic'].includes(input.action) || !actions[input.source]?.includes(input.action)) {
    fail('LX_SCRIPT_ACTION_UNSUPPORTED')
  }
  const value = await withTimeout(Promise.resolve(requestHandler({ source: input.source, action: input.action,
    info: { musicInfo: input.musicInfo } })), 15000, 'LX_SCRIPT_METADATA_TIMEOUT')
  return input.action === 'lyric'
    ? { version: 1, action: 'lyric', lyric: normalizeLyrics(value), sha256: digest }
    : { version: 1, action: 'pic', url: normalizeResolvedUrl(value), sha256: digest }
}

let bytes = ''
if (require.main === module) {
  let finished = false
  const finish = (payload, exitCode) => {
    if (finished) return
    finished = true
    process.stdout.write(`${JSON.stringify(payload)}\n`, () => process.exit(exitCode))
  }
  // 第三方脚本可能在 requestHandler 已返回后从回调或定时器抛错。进程级兜底只负责保证 JSON 协议完整，
  // 不把 message/stack 写入 stdout；正常主流程与异步兜底由 finished 保证至多一个结果。
  process.once('uncaughtException', (error) => finish({ version: 1, errorCode: classifyError(error),
    diagnostic: failureDiagnostic(error) }, 2))
  process.once('unhandledRejection', (error) => finish({ version: 1, errorCode: classifyError(error),
    diagnostic: failureDiagnostic(error) }, 2))
  process.stdin.setEncoding('utf8')
  process.stdin.on('data', (chunk) => { bytes += chunk; if (bytes.length > 128 * 1024) process.exit(2) })
  process.stdin.on('end', async () => {
    try { finish(await run(JSON.parse(bytes)), 0) }
    catch (error) { finish({ version: 1, errorCode: classifyError(error),
      diagnostic: failureDiagnostic(error) }, 2) }
  })
}

module.exports = { classifyError, createSilentConsole, normalizeLyrics, normalizeResolvedUrl, requestTarget, safeRequest, safeUpstreamText,
  upstreamDiagnosticFields, failureDiagnostic, withSourceAuthorization }
