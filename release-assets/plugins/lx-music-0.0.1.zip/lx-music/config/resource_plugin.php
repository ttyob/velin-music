<?php

declare(strict_types=1);

use plugin\lx_music\app\LxMusicPlugin;

/**
 * LX Music PHP 插件 manifest。
 *
 * 核心只按本声明装配固定搜索、下载、Worker 与数据库钩子；具体来源、令牌和音质都由插件自有页面
 * 管理。版本或任务语义变化时必须同步数据库版本与契约测试，禁止旧 Worker 猜测新任务字段。
 */
return [
    'key' => 'lx-music',
    'name' => 'LX Music',
    'version' => '0.0.1',
    'protocolVersion' => 1,
    'capabilities' => ['admin_page_search', 'admin_page_download', 'external_music_completion',
        'worker', 'transcode_worker', 'database_lifecycle'],
    'adminPage' => [
        'path' => '/admin/plugins/lx-music',
        'title' => 'LX Music',
        'description' => '多源音乐搜索与下载入库',
        'entry' => 'public/plugin-pages/lx-music.html',
        'capability' => 'manage_system',
    ],
    'class' => LxMusicPlugin::class,
];
