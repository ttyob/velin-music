<?php

declare(strict_types=1);

/**
 * LX Music 插件活动标记。
 *
 * 安装器完成包校验和数据库初始化后才原子创建标记。首次安装由核心固定 API 与通用 Worker 热发现，
 * 本文件不注册额外进程或路由；卸载开始后标记移除，后续调用立即失败关闭。
 */
return ['enable' => is_file(dirname(__DIR__) . '/.velin-installed')
    && !is_link(dirname(__DIR__) . '/.velin-installed')];
