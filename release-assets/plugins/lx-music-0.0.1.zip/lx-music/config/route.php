<?php

declare(strict_types=1);

/**
 * LX Music 只使用核心固定动态插件 API。
 *
 * 不在这里注册来源专用地址，使后台上传安装后无需重启路由进程；Session、CSRF、能力和插件活动状态
 * 均由核心路由逐请求复验。
 */
return;
