<?php

declare(strict_types=1);

/**
 * LX Music 不注册私有 Workerman 进程。
 *
 * 核心 ResourcePluginWorker 每轮动态发现并单步调用插件任务，保证首次安装无需重启且 SQLite 只有一个
 * 消费者。空配置只保留 Webman 插件目录兼容，不产生第二消费者。
 */
return [];
